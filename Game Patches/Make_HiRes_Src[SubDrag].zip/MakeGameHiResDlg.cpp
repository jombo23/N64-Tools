
// MakeGameHiResDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MakeGameHiRes.h"
#include "MakeGameHiResDlg.h"

#include "GECompression.h"
#include <vector>
#include <algorithm>
#include <map>
#include "rnc_deco.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMakeGameHiResDlg dialog




CMakeGameHiResDlg::CMakeGameHiResDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMakeGameHiResDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMakeGameHiResDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMakeGameHiResDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTONBK11, &CMakeGameHiResDlg::OnBnClickedButtonbk11)
	ON_BN_CLICKED(IDC_BUTTONBK12, &CMakeGameHiResDlg::OnBnClickedButtonbk12)
	ON_BN_CLICKED(IDC_BUTTONBK13, &CMakeGameHiResDlg::OnBnClickedButtonbk13)
	ON_BN_CLICKED(IDC_BUTTONBK14, &CMakeGameHiResDlg::OnBnClickedButtonbk14)
	ON_BN_CLICKED(IDC_BUTTONBK15, &CMakeGameHiResDlg::OnBnClickedButtonbk15)
	ON_BN_CLICKED(IDC_BUTTONBK16, &CMakeGameHiResDlg::OnBnClickedButtonbk16)
	ON_BN_CLICKED(IDC_BUTTONBK17, &CMakeGameHiResDlg::OnBnClickedButtonbk17)
	ON_BN_CLICKED(IDC_BUTTONBK18, &CMakeGameHiResDlg::OnBnClickedButtonbk18)
	ON_BN_CLICKED(IDC_BUTTONBK19, &CMakeGameHiResDlg::OnBnClickedButtonbk19)
	ON_BN_CLICKED(IDC_BUTTONBK20, &CMakeGameHiResDlg::OnBnClickedButtonbk20)
END_MESSAGE_MAP()


// CMakeGameHiResDlg message handlers

BOOL CMakeGameHiResDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMakeGameHiResDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMakeGameHiResDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMakeGameHiResDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


unsigned char* DecompressFile(unsigned char* ROM, unsigned long address, int compressedSize, int& sizeUncompressed)
{
	GECompression compressed;
	compressed.SetGame(BANJOKAZOOIE);

	compressed.SetCompressedBuffer(&ROM[address], compressedSize);
	
	unsigned char* outputDecompressed = compressed.OutputDecompressedBuffer(sizeUncompressed, compressedSize);

	if (sizeUncompressed < 0x20)
	{
		delete [] outputDecompressed;
		return NULL;
	}

	if (outputDecompressed == NULL)
	{
		return NULL;
	}

	return outputDecompressed;
}

int GetSizeFile(CString filename)
{
	FILE* inFile = fopen(filename, "rb");
	
	if (inFile == 0)
		return 0;

	fseek(inFile, 0, SEEK_END);
	int fileSize = ftell(inFile);
	fclose(inFile);
	return fileSize;
}

unsigned char* CompressFile(unsigned char* buffer, int size, int& compressedSize)
{
	GECompression compressed;
	compressed.SetGame(BANJOKAZOOIE);

	FILE* outFile = fopen("C:\\temp\\a2q3.bin", "wb");
	fwrite(buffer, 1, size, outFile);
	fclose(outFile);

	compressed.SetPath("C:\\GoldeneyeStuff\\GE Editor Source\\");
	compressed.CompressGZipFileNoPad("C:\\temp\\a2q3.bin", "C:\\temp\\b12312s.bin", false);

	compressedSize = GetSizeFile("C:\\temp\\b12312s.bin");

	FILE* inFile = fopen("C:\\temp\\b12312s.bin", "rb");
	unsigned char* output = new unsigned char[compressedSize];
	fread(output, 1, compressedSize, inFile);
	fclose(inFile);

	return output;
}

void WriteLongToBuffer(unsigned char* Buffer, unsigned long address, unsigned long data)
{
	Buffer[address] = ((data >> 24) & 0xFF);
	Buffer[address+1] = ((data >> 16) & 0xFF);
	Buffer[address+2] = ((data >> 8) & 0xFF);
	Buffer[address+3] = ((data) & 0xFF);
}

void WriteShortToBuffer(unsigned char* Buffer, unsigned long address, unsigned short data)
{
	Buffer[address] = ((data >> 8) & 0xFF);
	Buffer[address+1] = ((data) & 0xFF);	
}

void WriteOriAddress(unsigned char* GEROM, unsigned long address, unsigned long upperLocation, unsigned long lowerLocation)
{
	unsigned short upper = ((address >> 16) & 0xFFFF);
	unsigned short lower = (address & 0xFFFF);

	WriteShortToBuffer(GEROM, (upperLocation+2), upper);
	WriteShortToBuffer(GEROM, (lowerLocation+2), lower);
}

void WriteAddiuAddress(unsigned char* GEROM, unsigned long address, unsigned long upperLocation, unsigned long lowerLocation)
{
	unsigned short upper = ((address >> 16) & 0xFFFF);
	unsigned short lower = (address & 0xFFFF);

	if (lower > 0x7FFF)
	{
		upper += 1;
	}

	WriteShortToBuffer(GEROM, (upperLocation+2), upper);
	WriteShortToBuffer(GEROM, (lowerLocation+2), lower);
}

bool hiddenExec (PTSTR pCmdLine, CString currentDirectory, int& errorCode, int waitTime)
{
	errorCode = 0;
	::SetCurrentDirectory(currentDirectory);
   STARTUPINFO si;
   PROCESS_INFORMATION processInfo;
   ZeroMemory(&si, sizeof(si));
   si.cb           = sizeof(si);
   si.dwFlags      = STARTF_USESHOWWINDOW;
   si.wShowWindow  = SW_HIDE;
   ZeroMemory(&processInfo, sizeof(processInfo));


   if (currentDirectory.ReverseFind('\\') == (currentDirectory.GetLength()-1))
   {
		currentDirectory = currentDirectory.Mid(0, (currentDirectory.GetLength()-1));
   }

   /*return */CreateProcess(0, pCmdLine, 0, 0, FALSE, 0, 0, currentDirectory, &si, &processInfo);
   WaitForSingleObject(processInfo.hProcess, waitTime);
   DWORD exitCode;
   if (GetExitCodeProcess(processInfo.hProcess, &exitCode))
   {
	   errorCode = exitCode;
		if (exitCode == STILL_ACTIVE)
		{
			MessageBox(NULL, "For some reason Process Failed", "Error", NULL);
			TerminateProcess(processInfo.hProcess, exitCode);

			CloseHandle(processInfo.hProcess);
			CloseHandle(processInfo.hThread);
			return false;
		}
   }   
   CloseHandle(processInfo.hProcess);
   CloseHandle(processInfo.hThread);
   return true;
}

bool hiddenExec (PTSTR pCmdLine, CString currentDirectory, int& errorCode)
{
	return hiddenExec(pCmdLine, currentDirectory, errorCode, 60000);
}

bool hiddenExec (PTSTR pCmdLine, CString currentDirectory)
{
	int errorCode;
	return hiddenExec(pCmdLine, currentDirectory, errorCode);
};

unsigned long CharArrayToLong(unsigned char* currentSpot)
{
	return ((((((currentSpot[0] << 8) | currentSpot[1]) << 8) | currentSpot[2]) << 8) | currentSpot[3]);
}

unsigned short CharArrayToShort(unsigned char* currentSpot)
{
	return ((currentSpot[0] << 8) | currentSpot[1]);
}

void CMakeGameHiResDlg::OnBnClickedButtonbk11()
{
	int romSize = 0x1000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Banjo-Kazooie (U) (V1.1) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	int sizeUncompressedF1C830 = 0;
	unsigned char* fileF1C830 = DecompressFile(ROM, 0xF1C830, (0xF391BB - 0xF1C830), sizeUncompressedF1C830);

	int sizeUncompressedF391BB = 0;
	unsigned char* fileF391BB = DecompressFile(ROM, 0xF391BB, (0xF3ADB0 - 0xF391BB), sizeUncompressedF391BB);

	int sizeUncompressedF3ADB0 = 0;
	unsigned char* fileF3ADB0 = DecompressFile(ROM, 0xF3ADB0, (0xF9FA9E - 0xF3ADB0), sizeUncompressedF3ADB0);

	int sizeUncompressedFC77E0 = 0;
	unsigned char* fileFC77E0 = DecompressFile(ROM, 0xFC77E0, (0xFC9BDF - 0xFC77E0), sizeUncompressedFC77E0);

	int sizeUncompressedFC9BDF = 0;
	unsigned char* fileFC9BDF = DecompressFile(ROM, 0xFC9BDF, (0xFC9EF0 - 0xFC9BDF), sizeUncompressedFC9BDF);

	//FILE* outASMB = fopen("C:\\temp\\FC77E0.bin", "wb");
	//fwrite(fileFC77E0, 1, sizeUncompressedFC77E0, outASMB);
	//fclose(outASMB);

	int sizeF9FA9E = 0xFA6F80 - 0xF9FA9E;
	unsigned char* extraFileF9FA9E = new unsigned char[sizeF9FA9E];
	memcpy(extraFileF9FA9E, &ROM[0xF9FA9E], sizeF9FA9E);

	//FILE* outASM = fopen("C:\\temp\\F1C830.bin", "wb");
	//fwrite(fileF1C830, 1, sizeUncompressedF1C830, outASM);
	//fclose(outASM);

	// Remove SM ASM Tamper to lose moves protection
	WriteLongToBuffer(fileFC77E0, (0x803857E4 - 0x80385610), 0x10000003);

	WriteLongToBuffer(fileFC77E0, (0x8038591C - 0x80385610), 0x00000000);
	WriteLongToBuffer(fileFC77E0, (0x80385920 - 0x80385610), 0x00000000);

	WriteLongToBuffer(fileFC77E0, (0x8038593C - 0x80385610), 0x00000000);
	WriteLongToBuffer(fileFC77E0, (0x80385940 - 0x80385610), 0x00000000);

	WriteLongToBuffer(fileFC77E0, (0x8038595C - 0x80385610), 0x00000000);
	WriteLongToBuffer(fileFC77E0, (0x80385960 - 0x80385610), 0x00000000);

	WriteLongToBuffer(fileFC77E0, (0x80385978 - 0x80385610), 0x00000000);
	WriteLongToBuffer(fileFC77E0, (0x8038597C - 0x80385610), 0x00000000);

	// Not 100% sure this is necessary
	WriteLongToBuffer(fileFC77E0, (0x80385730 - 0x80385610), 0x10000008);
	


	unsigned long newFrameBufferLocation = 0x80400000;
	unsigned long newFrameBufferSizeEach = 0x96000;

	int newWidth = 0x280; //124
	int newHeight = 0x1E0; //D8
	
	WriteShortToBuffer(fileF1C830, (0x802530A4 - 0x8023D680) + 2, newWidth);
	WriteShortToBuffer(fileF1C830, (0x802530B0 - 0x8023D680) + 2, newHeight);
	

	/*WriteLongToBuffer(fileF1C830, (0x8024B184 - 0x8023D680), 0x240F0000 | newHeight);
	WriteLongToBuffer(fileF1C830, (0x8024B1E0 - 0x8023D680), 0x24080000 | newHeight);

	
	WriteLongToBuffer(fileF1C830, (0x8024B17C - 0x8023D680), 0x240E0000 | newWidth);
	WriteLongToBuffer(fileF1C830, (0x8024B1D8 - 0x8023D680), 0x24190000 | newWidth);
	

	// This actually stretches screen
	WriteLongToBuffer(fileF1C830, (0x8024B9B4 - 0x8023D680), 0x24180000 | newHeight);
	WriteLongToBuffer(fileF1C830, (0x8024B9B8 - 0x8023D680), 0x240E0000 | newWidth);

	WriteLongToBuffer(fileF1C830, (0x8024CC68 - 0x8023D680), 0x240F0000 | newHeight);
	WriteLongToBuffer(fileF1C830, (0x8024CC88 - 0x8023D680), 0x24180000 | newWidth);*/

	//WriteLongToBuffer(fileF1C830, (0x8025211C - 0x8023D680), 0x240F0000 | 0x124);

	// These next two crash it without moving buffer
	// This is depth buffer
	// Rerouted to 80600000
	WriteLongToBuffer(fileF1C830, (0x8025217C - 0x8023D680), 0x3C0E8060);
	WriteLongToBuffer(fileF1C830, (0x80252180 - 0x8023D680), 0x25CE0000);
	WriteLongToBuffer(fileF1C830, (0x80251E24 - 0x8023D680), 0x3C048060);
	WriteLongToBuffer(fileF1C830, (0x80251E34 - 0x8023D680), 0x24840000);

	// This causes jigsaw crash...ack
	//WriteLongToBuffer(fileF391BB, (0x802748DC - 0x80274570), 0x80600000);

	


	//WriteLongToBuffer(fileF1C830, (0x80251FDC - 0x8023D680), 0x24190000 | 0x124);

	//WriteLongToBuffer(fileF1C830, (0x80252594 - 0x8023D680), 0x240D0000 | 0xD8);
	//WriteLongToBuffer(fileF1C830, (0x8025259C - 0x8023D680), 0x24070000 | 0x124);


	/*WriteLongToBuffer(fileF1C830, (0x802525C4 - 0x8023D680), 0x24180000 | newWidth);

	
	WriteLongToBuffer(fileF3ADB0, (0x802BD8D8 - 0x80285DD0), 0x240F0000 | newHeight);
	WriteLongToBuffer(fileF3ADB0, (0x802BD8DC - 0x80285DD0), 0x240E0000 | newWidth);

	WriteLongToBuffer(fileF3ADB0, (0x802ED4C4 - 0x80285DD0), 0x240B0000 | newWidth);
	
	WriteLongToBuffer(fileF3ADB0, (0x8030A274 - 0x80285DD0), 0x24190000 | newHeight);
	WriteLongToBuffer(fileF3ADB0, (0x8030A27C - 0x80285DD0), 0x240F0000 | newWidth);

	WriteLongToBuffer(fileF3ADB0, (0x8030A364 - 0x80285DD0), 0x240E0000 | newHeight);
	WriteLongToBuffer(fileF3ADB0, (0x8030A36C - 0x80285DD0), 0x240C0000 | newWidth);

	WriteLongToBuffer(fileF3ADB0, (0x8034FAD8 - 0x80285DD0), 0x240F0000 | newWidth);
	WriteLongToBuffer(fileF3ADB0, (0x8034FB44 - 0x80285DD0), 0x24180000 | newHeight);

	WriteLongToBuffer(fileF3ADB0, (0x8034FBC8 - 0x80285DD0), 0x24190000 | newHeight);

	WriteLongToBuffer(fileF3ADB0, (0x8034FE40 - 0x80285DD0), 0x240E0000 | newWidth);*/
	
	// Disable slowdown of walking
	WriteLongToBuffer(fileF1C830, (0x8024D18C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024D1A0 - 0x8023D680), 0x10000002);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	
	unsigned long newVIOffset = 0x80274A84;
	for (int x = 0; x < 0x4C; x++)
	{
		fileF391BB[newVIOffset - 0x80274570 + x] = rawData[x];
	}

	// Disable overwrite no-AA
	WriteLongToBuffer(fileF1C830, (0x80264FFC - 0x8023D680), 0x2401FFFF);
	


	//00000480
	//8023DB00:	3C15803A	LUI     $s5, 0x803A	#
	//8023DB0C:	26B55D00	ADDIU   $s5, $s5, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8023DB00 - 0x8023D680), (0x8023DB0C - 0x8023D680));

	WriteLongToBuffer(fileF1C830, (0x80247350 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247354 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247358 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x8024735C - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80247360 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247364 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247368 - 0x8023D680), 0x00000000);
	//00009CF0
	//80247370:	3C18803A	LUI     $t8, 0x803A	#
	//8024738C:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80247370 - 0x8023D680), (0x8024738C - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80247374 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247388 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x80247648 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8024764C - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247650 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80247654 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80247658 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024765C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247660 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247664 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247668 - 0x8023D680), 0x00000000);
	//00009FC0
	//80247640:	3C18803A	LUI     $t8, 0x803A	#
	//80247644:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80247640 - 0x8023D680), (0x80247644 - 0x8023D680));

	WriteLongToBuffer(fileF1C830, (0x802478C0 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802478C4 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802478C8 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x802478CC - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x802478D0 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802478D4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802478D8 - 0x8023D680), 0x00000000);
	//0000A260
	//802478E0:	3C18803A	LUI     $t8, 0x803A	#
	//802478FC:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x802478E0 - 0x8023D680), (0x802478FC - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x802478E4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802478F8 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x80247AC0 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247AC4 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247AC8 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80247ACC - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80247AD0 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247AD4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247AD8 - 0x8023D680), 0x00000000);
	//0000A460
	//80247AE0:	3C18803A	LUI     $t8, 0x803A	#
	//80247AFC:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80247AE0 - 0x8023D680), (0x80247AFC - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80247AE4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247AF8 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x80247D1C - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247D20 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247D24 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80247D28 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80247D2C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247D30 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247D34 - 0x8023D680), 0x00000000);
	//80247D3C:	3C18803A	LUI     $t8, 0x803A	#
	//80247D58:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80247D3C - 0x8023D680), (0x80247D58 - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80247D40 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247D54 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x80247F90 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247F94 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80247F98 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80247F9C - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80247FA0 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247FA4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247FA8 - 0x8023D680), 0x00000000);
	//80247FB0:	3C18803A	LUI     $t8, 0x803A	#
	//80247FCC:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80247FB0 - 0x8023D680), (0x80247FCC - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80247FB4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80247FC8 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x802481A8 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802481AC - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802481B0 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x802481B4 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x802481B8 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802481BC - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802481C0 - 0x8023D680), 0x00000000);
	//802481C8:	3C18803A	LUI     $t8, 0x803A	#
	//802481E4:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x802481C8 - 0x8023D680), (0x802481E4 - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x802481CC - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802481E0 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x802483C4 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802483C8 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802483CC - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x802483D0 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x802483D4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802483D8 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802483DC - 0x8023D680), 0x00000000);
	//802483E4:	3C18803A	LUI     $t8, 0x803A	#
	//80248400:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x802483E4 - 0x8023D680), (0x80248400 - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x802483E8 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x802483FC - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x8024876C - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248770 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248774 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80248778 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x8024877C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248780 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248784 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248788 - 0x8023D680), 0x00000000);
	//802487A8:	3C0F803A	LUI     $t7, 0x803A	#
	//802487AC:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x802487A8 - 0x8023D680), (0x802487AC - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80248790 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x80248BCC - 0x8023D680), 0x3C0D0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248BD0 - 0x8023D680), 0x35AD0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248BD4 - 0x8023D680), 0x01B90019);
	WriteLongToBuffer(fileF1C830, (0x80248BD8 - 0x8023D680), 0x00006812);
	WriteLongToBuffer(fileF1C830, (0x80248BDC - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248BE0 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248BE4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248BE8 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248BF0 - 0x8023D680), 0x00000000);
	//80248C04:	3C0F803A	LUI     $t7, 0x803A	#
	//80248C08:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80248C04 - 0x8023D680), (0x80248C08 - 0x8023D680));

	WriteLongToBuffer(fileF1C830, (0x80248D08 - 0x8023D680), 0x3C0E0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248D0C - 0x8023D680), 0x35CE0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80248D18 - 0x8023D680), 0x01D90019);
	WriteLongToBuffer(fileF1C830, (0x80248D1C - 0x8023D680), 0x00007012);
	WriteLongToBuffer(fileF1C830, (0x80248D24 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248D28 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248D2C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248D30 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80248D34 - 0x8023D680), 0x00000000);
	//80248D50:	3C0E803A	LUI     $t6, 0x803A	#
	//80248D54:	25CE5D00	ADDIU   $t6, $t6, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80248D50 - 0x8023D680), (0x80248D54 - 0x8023D680));

	WriteLongToBuffer(fileF1C830, (0x802492EC - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802492F0 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x802492F4 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x802492F8 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x802492FC - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80249300 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80249304 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80249308 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024930C - 0x8023D680), 0x00000000);
	//80249340:	3C0E803A	LUI     $t6, 0x803A	#
	//80249348:	25CE5D00	ADDIU   $t6, $t6, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80249340 - 0x8023D680), (0x80249348 - 0x8023D680));

	//; Real one
	//8024AC0C:	3C04803A	LUI     $a0, 0x803A	#
	//8024AC14:	24845D00	ADDIU   $a0, $a0, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024AC0C - 0x8023D680), (0x8024AC14 - 0x8023D680));

	//Added to first frame buffer, set next one here 8024AE40 (V0 first or second buffer), write at 8024AE74

	//lui $t5, 0x0009
	//ori $t5, $t5, 0x6000
	//multu $v0, $t5
	//mflo $t5
	WriteLongToBuffer(fileF1C830, (0x8024AE40 - 0x8023D680), 0x3C0D0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8024AE44 - 0x8023D680), 0x35AD0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8024AE48 - 0x8023D680), 0x01A20019);
	WriteLongToBuffer(fileF1C830, (0x8024AE4C - 0x8023D680), 0x00006812);
	WriteLongToBuffer(fileF1C830, (0x8024AE50 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024AE54 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024AE58 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024AE5C - 0x8023D680), 0x00000000);
	//8024AE64:	3C0F803A	LUI     $t7, 0x803A	#
	//8024AE68:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024AE64 - 0x8023D680), (0x8024AE68 - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x8024AE70 - 0x8023D680), 0x00000000);

	WriteLongToBuffer(fileF1C830, (0x8024B024 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8024B028 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8024B02C - 0x8023D680), 0x01E40019);
	WriteLongToBuffer(fileF1C830, (0x8024B030 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x8024B034 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024B038 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024B040 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8024B04C - 0x8023D680), 0x00000000);
	//8024B050:	3C18803A	LUI     $t8, 0x803A	#
	//8024B05C:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024B050 - 0x8023D680), (0x8024B05C - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x8024B060 - 0x8023D680), 0x00000000);

	//8024B1A4:	3C04803A	LUI     $a0, 0x803A	#
	//8024B1B0:	24845D00	ADDIU   $a0, $a0, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024B1A4 - 0x8023D680), (0x8024B1B0 - 0x8023D680));

	//8024B1F8:	3C04803A	LUI     $a0, 0x803A	#
	//8024B1FC:	24845D00	ADDIU   $a0, $a0, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024B1F8 - 0x8023D680), (0x8024B1FC - 0x8023D680));

	//8024FEEC:	3C0E803A	LUI     $t6, 0x803A	#
	//8024FEF8:	25CE5D00	ADDIU   $t6, $t6, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x8024FEEC - 0x8023D680), (0x8024FEF8 - 0x8023D680));

	WriteLongToBuffer(fileF1C830, (0x80251EF0 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80251EF4 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80251EF8 - 0x8023D680), 0x01E20019);
	WriteLongToBuffer(fileF1C830, (0x80251EFC - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80251F00 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80251F04 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80251F08 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80251F0C - 0x8023D680), 0x00000000);
	//80251F14:	3C18803A	LUI     $t8, 0x803A	#
	//80251F1C:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80251F14 - 0x8023D680), (0x80251F1C - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80251F20 - 0x8023D680), 0x00000000);

	//80252760:	3C18803A	LUI     $t8, 0x803A	#
	//80252764:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80252760 - 0x8023D680), (0x80252764 - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80252768 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x8025276C - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80252770 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80252774 - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80252778 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x8025277C - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252780 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252784 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252788 - 0x8023D680), 0x00000000);

	//80252AC8:	3C18803A	LUI     $t8, 0x803A	#
	//80252ACC:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF1C830, newFrameBufferLocation, (0x80252AC8 - 0x8023D680), (0x80252ACC - 0x8023D680));
	WriteLongToBuffer(fileF1C830, (0x80252AD0 - 0x8023D680), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80252AD4 - 0x8023D680), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF1C830, (0x80252AD8 - 0x8023D680), 0x01EE0019);
	WriteLongToBuffer(fileF1C830, (0x80252ADC - 0x8023D680), 0x00007812);
	WriteLongToBuffer(fileF1C830, (0x80252AE0 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252AE4 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252AE8 - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252AEC - 0x8023D680), 0x00000000);
	WriteLongToBuffer(fileF1C830, (0x80252AF0 - 0x8023D680), 0x00000000);






	







	//FILE* outASM = fopen("C:\\temp\\F3ADB0.bin", "wb");
	//fwrite(fileF3ADB0, 1, sizeUncompressedF3ADB0, outASM);
	//fclose(outASM);

	//00058A60
	//802DE830:	3C08803A	LUI     $t0, 0x803A	#
	//802DE834:	25085D00	ADDIU   $t0, $t0, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802DE830 - 0x80285DD0), (0x802DE834 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802DE810 - 0x80285DD0), 0x3C190000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802DE814 - 0x80285DD0), 0x37390000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802DE818 - 0x80285DD0), 0x03220019);
	WriteLongToBuffer(fileF3ADB0, (0x802DE81C - 0x80285DD0), 0x0000C812);
	WriteLongToBuffer(fileF3ADB0, (0x802DE820 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802DE824 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802DE828 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802DE82C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802DE838 - 0x80285DD0), 0x00000000);

	//802E2280:	3C18803A	LUI     $t8, 0x803A	#
	//802E2284:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802E2280 - 0x80285DD0), (0x802E2284 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802E2288 - 0x80285DD0), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802E2290 - 0x80285DD0), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802E2294 - 0x80285DD0), 0x01EE0019);
	WriteLongToBuffer(fileF3ADB0, (0x802E2298 - 0x80285DD0), 0x00007812);
	WriteLongToBuffer(fileF3ADB0, (0x802E229C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802E22A0 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802E22A4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802E22A8 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802E22AC - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802E22B0 - 0x80285DD0), 0x00000000);

	//802F09A4:	3C0C803A	LUI     $t4, 0x803A	#
	//802F09DC:	258C5D00	ADDIU   $t4, $t4, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802F09A4 - 0x80285DD0), (0x802F09DC - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802F09E4 - 0x80285DD0), 0x3C0B0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802F09E8 - 0x80285DD0), 0x356B0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802F09EC - 0x80285DD0), 0x016A0019);
	WriteLongToBuffer(fileF3ADB0, (0x802F09F0 - 0x80285DD0), 0x00005812);
	WriteLongToBuffer(fileF3ADB0, (0x802F09F4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F09F8 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F09FC - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F0A00 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F0A04 - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x802F12D0 - 0x80285DD0), 0x3C0E0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802F12D4 - 0x80285DD0), 0x35CE0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802F12DC - 0x80285DD0), 0x01C20019);
	WriteLongToBuffer(fileF3ADB0, (0x802F12E0 - 0x80285DD0), 0x00007012);
	WriteLongToBuffer(fileF3ADB0, (0x802F12E4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F12E8 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F12F0 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F12F4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802F12F8 - 0x80285DD0), 0x00000000);
	//802F1328:	3C0F803A	LUI     $t7, 0x803A	#
	//802F132C:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802F1328 - 0x80285DD0), (0x802F132C - 0x80285DD0));

	WriteLongToBuffer(fileF3ADB0, (0x802FDF20 - 0x80285DD0), 0x3C0C0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FDF24 - 0x80285DD0), 0x358C0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FDF28 - 0x80285DD0), 0x01820019);
	WriteLongToBuffer(fileF3ADB0, (0x802FDF2C - 0x80285DD0), 0x00007012);
	WriteLongToBuffer(fileF3ADB0, (0x802FDF30 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FDF34 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FDF3C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FDF40 - 0x80285DD0), 0x00000000);
	//802FDF44:	3C0D803A	LUI     $t5, 0x803A	#
	//802FDF48:	25AD5D00	ADDIU   $t5, $t5, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802FDF44 - 0x80285DD0), (0x802FDF48 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802FDF4C - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x802FE0A8 - 0x80285DD0), 0x3C0E0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FE0AC - 0x80285DD0), 0x35CE0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FE0B0 - 0x80285DD0), 0x01C20019);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0B4 - 0x80285DD0), 0x00007012);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0B8 - 0x80285DD0), 0x03190019);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0BC - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0C0 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0C4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FE0C8 - 0x80285DD0), 0x00000000);
	//802FE0CC:	3C0F803A	LUI     $t7, 0x803A	#
	//802FE0D0:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802FE0CC - 0x80285DD0), (0x802FE0D0 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802FE0D4 - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x802FFC04 - 0x80285DD0), 0x3C0A0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FFC0C - 0x80285DD0), 0x354A0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x802FFC10 - 0x80285DD0), 0x01420019);
	WriteLongToBuffer(fileF3ADB0, (0x802FFC1C - 0x80285DD0), 0x00005012);
	WriteLongToBuffer(fileF3ADB0, (0x802FFC20 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FFC28 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FFC2C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x802FFC34 - 0x80285DD0), 0x00000000);
	//802FFC38:	3C0B803A	LUI     $t3, 0x803A	#
	//802FFC40:	256B5D00	ADDIU   $t3, $t3, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x802FFC38 - 0x80285DD0), (0x802FFC40 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x802FFC44 - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x8030B454 - 0x80285DD0), 0x3C0E0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x8030B458 - 0x80285DD0), 0x35CE0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x8030B45C - 0x80285DD0), 0x01C20019);
	WriteLongToBuffer(fileF3ADB0, (0x8030B460 - 0x80285DD0), 0x00007012);
	WriteLongToBuffer(fileF3ADB0, (0x8030B464 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x8030B468 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x8030B46C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x8030B470 - 0x80285DD0), 0x00000000);
	//8030B474:	3C0F803A	LUI     $t7, 0x803A	#
	//8030B478:	25EF5D00	ADDIU   $t7, $t7, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x8030B474 - 0x80285DD0), (0x8030B478 - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x8030B47C - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x803141A8 - 0x80285DD0), 0x3C0E0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x803141AC - 0x80285DD0), 0x35CE0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x803141B0 - 0x80285DD0), 0x01C20019);
	WriteLongToBuffer(fileF3ADB0, (0x803141B4 - 0x80285DD0), 0x00007012);
	WriteLongToBuffer(fileF3ADB0, (0x803141B8 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x803141BC - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x803141C0 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x803141C4 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x803141C8 - 0x80285DD0), 0x00000000);
	//803141D0:	3C19803A	LUI     $t9, 0x803A	#
	//803141D4:	27395D00	ADDIU   $t9, $t9, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x803141D0 - 0x80285DD0), (0x803141D4 - 0x80285DD0));

	WriteLongToBuffer(fileF3ADB0, (0x80314248 - 0x80285DD0), 0x3C0F0000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x8031424C - 0x80285DD0), 0x35EF0000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x80314250 - 0x80285DD0), 0x01E20019);
	WriteLongToBuffer(fileF3ADB0, (0x80314254 - 0x80285DD0), 0x00007812);
	WriteLongToBuffer(fileF3ADB0, (0x80314258 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x8031425C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x80314260 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x80314264 - 0x80285DD0), 0x00000000);	
	//80314268:	3C18803A	LUI     $t8, 0x803A	#
	//8031426C:	27185D00	ADDIU   $t8, $t8, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x80314268 - 0x80285DD0), (0x8031426C - 0x80285DD0));
	WriteLongToBuffer(fileF3ADB0, (0x80314270 - 0x80285DD0), 0x00000000);

	WriteLongToBuffer(fileF3ADB0, (0x80314314 - 0x80285DD0), 0x3C180000 | ((newFrameBufferSizeEach >> 16) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x80314318 - 0x80285DD0), 0x37180000 | ((newFrameBufferSizeEach) & 0xFFFF));
	WriteLongToBuffer(fileF3ADB0, (0x8031431C - 0x80285DD0), 0x030F0019);
	WriteLongToBuffer(fileF3ADB0, (0x80314320 - 0x80285DD0), 0x0000C012);
	WriteLongToBuffer(fileF3ADB0, (0x80314324 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x80314328 - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x8031432C - 0x80285DD0), 0x00000000);
	WriteLongToBuffer(fileF3ADB0, (0x80314330 - 0x80285DD0), 0x00000000);	
	WriteLongToBuffer(fileF3ADB0, (0x80314334 - 0x80285DD0), 0x00000000);	
	//8031430C:	3C19803A	LUI     $t9, 0x803A	#
	//80314310:	27395D00	ADDIU   $t9, $t9, 0x5D00	#(*CONSTANT) 803A5D00
	WriteAddiuAddress(fileF3ADB0, newFrameBufferLocation, (0x8031430C - 0x80285DD0), (0x80314310 - 0x80285DD0));

	int compressedSizeRecompressedF1C830 = -1;
	unsigned char* recompressedF1C830 = CompressFile(fileF1C830, sizeUncompressedF1C830, compressedSizeRecompressedF1C830);

	if (compressedSizeRecompressedF1C830 > (0xF391BB - 0xF1C830))
	{
		MessageBox("Too big F1C830");
		return;
	}

	int compressedSizeRecompressedF391BB = -1;
	unsigned char* recompressedF391BB = CompressFile(fileF391BB, sizeUncompressedF391BB, compressedSizeRecompressedF391BB);

	if (compressedSizeRecompressedF391BB > (0xF3ADB0 - 0xF391BB))
	{
		MessageBox("Too big F391BB");
		return;
	}




	memcpy(&ROM[0xF1C830], recompressedF1C830, compressedSizeRecompressedF1C830);
	memcpy(&ROM[0xF1C830 + compressedSizeRecompressedF1C830], recompressedF391BB, compressedSizeRecompressedF391BB);
	for (int x = (0xF1C830 + compressedSizeRecompressedF1C830 + compressedSizeRecompressedF391BB); x < 0xF3ADB0; x++)
		ROM[x] = 0x00;






	int compressedSizeRecompressedF3ADB0 = -1;
	unsigned char* recompressedF3ADB0 = CompressFile(fileF3ADB0, sizeUncompressedF3ADB0, compressedSizeRecompressedF3ADB0);

	if (compressedSizeRecompressedF3ADB0 > (0xF9FA9E - 0xF3ADB0))
	{
		MessageBox("Too big F3ADB0");
		return;
	}
	
	memcpy(&ROM[0xF3ADB0], recompressedF3ADB0, compressedSizeRecompressedF3ADB0);
	memcpy(&ROM[0xF3ADB0 + compressedSizeRecompressedF3ADB0], extraFileF9FA9E, sizeF9FA9E);
	for (int x = (0xF3ADB0 + compressedSizeRecompressedF3ADB0 + sizeF9FA9E); x < 0xFA6F80; x++)
		ROM[x] = 0x00;







	int compressedSizeRecompressedFC77E0 = -1;
	unsigned char* recompressedFC77E0 = CompressFile(fileFC77E0, sizeUncompressedFC77E0, compressedSizeRecompressedFC77E0);

	if (compressedSizeRecompressedFC77E0 > (0xFC9BDF - 0xFC77E0))
	{
		MessageBox("Too big FC77E0");
		return;
	}

	int compressedSizeRecompressedFC9BDF = -1;
	unsigned char* recompressedFC9BDF = CompressFile(fileFC9BDF, sizeUncompressedFC9BDF, compressedSizeRecompressedFC9BDF);

	if (compressedSizeRecompressedFC9BDF > (0xFC9EF0 - 0xFC9BDF))
	{
		MessageBox("Too big FC9BDF");
		return;
	}

	memcpy(&ROM[0xFC77E0], recompressedFC77E0, compressedSizeRecompressedFC77E0);
	memcpy(&ROM[0xFC77E0 + compressedSizeRecompressedFC77E0], recompressedFC9BDF, compressedSizeRecompressedFC9BDF);
	for (int x = (0xFC77E0 + compressedSizeRecompressedFC77E0 + compressedSizeRecompressedFC9BDF); x < 0xFC9EF0; x++)
		ROM[x] = 0x00;



	FILE* outFile = fopen("C:\\temp\\bkhires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\bkhires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] fileF1C830;
	delete [] fileF3ADB0;

	delete [] ROM;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk12()
{
	int romSize = 0x800000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Super Mario 64 (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1NoAA;
	for (int x = 0; x < 0x4C; x++)
	{
		//803350B0
		ROM[0xF00B0 + x + 4] = rawData[x];
	}

	//Disable overwrite of AA
	//803234DC
	WriteLongToBuffer(ROM, 0x000DE4DC, 0x2401FFFF);
	

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;

	unsigned long newFrameBufferLocation = 0x80400000;
	unsigned long newFrameBufferLocation1 = newFrameBufferLocation + newSize;
	unsigned long newFrameBufferLocation2 = newFrameBufferLocation + newSize + newSize;
	
	//802489C4:	3C188039	LUI     $t8, 0x8039	#
	//802489D0:	2718F800	ADDIU   $t8, $t8, 0xF800	#(*CONSTANT) 8038F800
	WriteAddiuAddress(ROM, newFrameBufferLocation, 0x000039C4, 0x000039D0); 

	//8037ED94:	3C048039	LUI     $a0, 0x8039	#
	//8037EDA4:	2484F800	ADDIU   $a0, $a0, 0xF800	#(*CONSTANT) 8038F800
	WriteAddiuAddress(ROM, newFrameBufferLocation, 0x000FBB14, 0x000FBB24); 

	//802489E4:	3C09803B	LUI     $t1, 0x803B	#
	//802489F0:	25295000	ADDIU   $t1, $t1, 0x5000	#(*CONSTANT) 803B5000
	WriteAddiuAddress(ROM, newFrameBufferLocation + newSize, 0x000039E4, 0x000039F0); 

	//80248A04:	3C0C803E	LUI     $t4, 0x803E	#
	//80248A10:	258CA800	ADDIU   $t4, $t4, 0xA800	#(*CONSTANT) 803DA800
	WriteAddiuAddress(ROM, newFrameBufferLocation + newSize + newSize, 0x00003A04, 0x00003A10); 

	// Depth Buffer?
	//802489A8:	3C0E8000	LUI     $t6, 0x8000	#
	//802489B4:	25CE0400	ADDIU   $t6, $t6, 0x0400	#(*CONSTANT) 80000400
	WriteLongToBuffer(ROM, 0x000039A8, 0x3C0E8060);
	WriteLongToBuffer(ROM, 0x000039B4, 0x25CE0000);

	//8037ED80:	3C048000	LUI     $a0, 0x8000	#
	//8037ED90:	24840400	ADDIU   $a0, $a0, 0x0400	#(*CONSTANT) 80000400
	WriteLongToBuffer(ROM, 0x000FBB00, 0x3C048060);
	WriteLongToBuffer(ROM, 0x000FBB10, 0x24840000);

	//8037ED84:	3C050002	LUI     $a1, 0x0002	#
	//8037ED88:	34A55800	ORI     $a1, $a1, 0x5800	#(*CONSTANT) 00025800
	WriteLongToBuffer(ROM, 0x000FBB04, 0x3C050000 | (((newSize) >> 16) & 0xFFFF));
	WriteLongToBuffer(ROM, 0x000FBB08, 0x34A50800 | (((newSize)) & 0xFFFF));

	//8037ED98:	3C050007	LUI     $a1, 0x0007	#
	//8037ED9C:	34A50800	ORI     $a1, $a1, 0x0800	#(*CONSTANT) 00070800
	WriteLongToBuffer(ROM, 0x000FBB18, 0x3C050000 | (((newSize * 3) >> 16) & 0xFFFF));
	WriteLongToBuffer(ROM, 0x000FBB1C, 0x34A50800 | (((newSize * 3)) & 0xFFFF));

	//8037ED70:	3C05000E	LUI     $a1, 0x000E	#
	//8037ED74:	34A51000	ORI     $a1, $a1, 0x1000	#(*CONSTANT) 000E1000
	WriteLongToBuffer(ROM, 0x000FBAF0, 0x3C050000 | (((newSize * 6) >> 16) & 0xFFFF));
	WriteLongToBuffer(ROM, 0x000FBAF4, 0x34A50800 | (((newSize * 6)) & 0xFFFF));

	
	//802CB944:	24060140	ADDIU   $a2, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00086944 + 2, newWidth);

	//802CB988:	24060140	ADDIU   $a2, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00086988 + 2, newWidth);
	//802CB98C:	240700F0	ADDIU   $a3, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0008698C + 2, newHeight);

	//802CB9D0:	240700F0	ADDIU   $a3, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000869D0 + 2, newHeight);

	//802CCEB0:	24060140	ADDIU   $a2, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00087EB0 + 2, newWidth);
	//802CCEB4:	240700F0	ADDIU   $a3, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00087EB4 + 2, newHeight);

	//Boot
	//801A58B8:	240C0140	ADDIU   $t4, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00255D78 + 2, newWidth);
	//801A58BC:	240D00F0	ADDIU   $t5, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00255D7C + 2, newHeight);

	//801A81F0/4
	WriteLongToBuffer(ROM, 0x002586B0, newWidth);
	WriteLongToBuffer(ROM, 0x002586B4, newHeight);

	// Changing FF10013F
	//80247338:	358C013F	ORI     $t4, $t4, 0x013F	#(*CONSTANT) FF10013F
	WriteLongToBuffer(ROM, 0x00002338, 0x358C027F);

	//80247448:	3718013F	ORI     $t8, $t8, 0x013F	#(*CONSTANT) FF10013F
	WriteLongToBuffer(ROM, 0x00002448, 0x3718027F);

	// Double size of all text
	//8032DB34
	// Otherwise messes up text drawn unfortunately though
	// First one is one that does the main thing
	WriteLongToBuffer(ROM, 0x000E8B30, 0x050003C0);
	WriteLongToBuffer(ROM, 0x000E8B38, 0x050003C0);
	WriteLongToBuffer(ROM, 0x000E8E60, 0x050003C0);
	WriteLongToBuffer(ROM, 0x000E8E68, 0x050003C0);
	
	//00A0007800A00078
	// to
	//014000F0014000F0

	for (int x = 0; x < romSize; x += 4)
	{
		if (CharArrayToLong(&ROM[x]) == 0x00A00078)
		{
			WriteLongToBuffer(ROM, x, 0x014000F0);
		}
	}

	//1 First screen 0026A174
	//2 Bg Head 0026A200
	//6 Main Menu 002A64A4

	//8027B28C:	240900A0	ADDIU   $t1, $zero, 0x00A0	#
	WriteShortToBuffer(ROM, 0x0003628C + 2, newWidth / 2);
	//8027B298:	240A0078	ADDIU   $t2, $zero, 0x0078	#
	WriteShortToBuffer(ROM, 0x00036298 + 2, newHeight / 2);
	//8027B2A4:	240B00A0	ADDIU   $t3, $zero, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000362A4 + 2, newWidth / 2);
	//8027B2B0:	240C0078	ADDIU   $t4, $zero, 0x0078	#
	WriteShortToBuffer(ROM, 0x000362B0 + 2, newHeight / 2);
	//8027B2D4:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000362D4 + 2, newWidth);

	WriteShortToBuffer(ROM, 0x0022C948 + 2, newWidth / 2);
	WriteShortToBuffer(ROM, 0x0022CA68 + 2, newHeight / 2);

	//8019C60C:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	//8019C610:	240F00F0	ADDIU   $t7, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0024CACC + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0024CAD0 + 2, newHeight);

	//801A5E6C:	24180140	ADDIU   $t8, $zero, 0x0140	#
	//801A5E70:	241900F0	ADDIU   $t9, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0025632C + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00256330 + 2, newHeight);

	// Maybe
	//801A607C:	240D0140	ADDIU   $t5, $zero, 0x0140	#
	//801A6080:	240E00C8	ADDIU   $t6, $zero, 0x00C8	#




	//Fixed scale...but viewport still wrong

	//8024749C:	3C180050	LUI     $t8, 0x0050	#
	//802474A0:	371803A0	ORI     $t8, $t8, 0x03A0	#(*CONSTANT) 005003A0
	WriteLongToBuffer(ROM, 0x0000249C, 0x3C1800A0);
	WriteLongToBuffer(ROM, 0x000024A0, 0x37180740);

	//8027B478:	3C080050	LUI     $t0, 0x0050	#
	//8027B47C:	350803A0	ORI     $t0, $t0, 0x03A0	#(*CONSTANT) 005003A0
	WriteLongToBuffer(ROM, 0x00036478, 0x3C0800A0);
	WriteLongToBuffer(ROM, 0x0003647C, 0x35080740);

	//8027B504:	3C0A0050	LUI     $t2, 0x0050	#
	//8027B508:	354A03A0	ORI     $t2, $t2, 0x03A0	#(*CONSTANT) 005003A0
	WriteLongToBuffer(ROM, 0x00036504, 0x3C0A00A0);
	WriteLongToBuffer(ROM, 0x00036508, 0x354A0740);

	//8027B590:	3C090050	LUI     $t1, 0x0050	#
	//8027B594:	352903A0	ORI     $t1, $t1, 0x03A0	#(*CONSTANT) 005003A0
	WriteLongToBuffer(ROM, 0x00036590, 0x3C0900A0);
	WriteLongToBuffer(ROM, 0x00036594, 0x35290740);

	//80246EFC:	3C090050	LUI     $t1, 0x0050	#
	//80246F00:	352903C0	ORI     $t1, $t1, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00001EFC, 0x3C0900A0);
	WriteLongToBuffer(ROM, 0x00001F00, 0x35290780);

	//802478A4:	3C0D0050	LUI     $t5, 0x0050	#
	//802478A8:	35AD03C0	ORI     $t5, $t5, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x000028A4, 0x3C0D00A0);
	WriteLongToBuffer(ROM, 0x000028A8, 0x35AD0780);

	//8027B4B4:	3C0E0050	LUI     $t6, 0x0050	#
	//8027B4B8:	35CE03C0	ORI     $t6, $t6, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x000364B4, 0x3C0E00A0);
	WriteLongToBuffer(ROM, 0x000364B8, 0x35CE0780);


	//80247964:	3C0EF64F	LUI     $t6, 0xF64F	#
	//80247968:	35CEC01C	ORI     $t6, $t6, 0xC01C	#(*CONSTANT) F64FC01C
	WriteLongToBuffer(ROM, 0x00002964, 0x3C0EF69F);
	WriteLongToBuffer(ROM, 0x00002968, 0x35CEC038);

	// Move black bar down
	//80247994:	3C09F64F	LUI     $t1, 0xF64F	#
	//80247998:	3529C3BC	ORI     $t1, $t1, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00002994, 0x3C09F69F);
	WriteLongToBuffer(ROM, 0x00002998, 0x35298778);

	//802479A4:	240B03A0	ADDIU   $t3, $zero, 0x03A0	#
	WriteLongToBuffer(ROM, 0x000029A4, 0x240B0740);

	//802473A0:	3C0EF64F	LUI     $t6, 0xF64F	#
	//802473A4:	35CEC39C	ORI     $t6, $t6, 0xC39C	#(*CONSTANT) F64FC39C
	WriteLongToBuffer(ROM, 0x000023A0, 0x3C0EF69F);
	WriteLongToBuffer(ROM, 0x000023A4, 0x35CEC77C);

	// These 2 crash, don't know why
	//8024759C:	3C08F64F	LUI     $t0, 0xF64F	#
	//802475A0:	3508C39C	ORI     $t0, $t0, 0xC39C	#(*CONSTANT) F64FC39C
	//WriteLongToBuffer(ROM, 0x0000259C, 0x3C0EF69F);
	//WriteLongToBuffer(ROM, 0x000025A0, 0x35CEC77C);

	//8027C998:	3C08F64F	LUI     $t0, 0xF64F	#
	//8027C99C:	3508C39C	ORI     $t0, $t0, 0xC39C	#(*CONSTANT) F64FC39C
	//WriteLongToBuffer(ROM, 0x00037998, 0x3C0EF69F);
	//WriteLongToBuffer(ROM, 0x0003799C, 0x35CEC77C);

	FILE* outFile = fopen("C:\\temp\\mariohires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\mariohires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk13()
{
	int romSize = 0x2800000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Paper Mario (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1NoAA;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x6FB40 + x + 4] = rawData[x];
		ROM[0x70C20 + x + 4] = rawData[x];
	}

	//80066EA0 AND FFF7
	//80066EE0 AND FFFB
	//80066F10 OR 10
	//80066F54 AND FCFF AA

	WriteLongToBuffer(ROM, 0x00042354, 0x2403FFFF);

	// Triple Buffered
	//8038F800
	//803B5000
	//803DA800

	unsigned short newWidth = 0x280;
	unsigned long newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;
	unsigned long newFrameBuffer = 0x80600000;
	unsigned long newFrameBuffer2 = newFrameBuffer + newSize;
	unsigned long newFrameBuffer3 = newFrameBuffer + newSize + newSize;
	WriteLongToBuffer(ROM, 0x00052CA0, newFrameBuffer);
	WriteLongToBuffer(ROM, 0x00052CA4, newFrameBuffer2);
	WriteLongToBuffer(ROM, 0x00052CA8, newFrameBuffer3);

	WriteLongToBuffer(ROM, 0x00052D50, newFrameBuffer);
	WriteLongToBuffer(ROM, 0x00052D54, newFrameBuffer2);
	WriteLongToBuffer(ROM, 0x00052D58, newFrameBuffer3);

	WriteLongToBuffer(ROM, 0x00052D80, newFrameBuffer);
	WriteLongToBuffer(ROM, 0x00052D84, newFrameBuffer2);
	WriteLongToBuffer(ROM, 0x00052D88, newFrameBuffer3);
	
	WriteLongToBuffer(ROM, 0x0006EFA8, newFrameBuffer);
	WriteLongToBuffer(ROM, 0x0006EFAC, newFrameBuffer2);
	WriteLongToBuffer(ROM, 0x0006EFB0, newFrameBuffer3);

	//8002ACA8:	3C050002	LUI     $a1, 0x0002	#
	//8002ACB8:	34A55800	ORI     $a1, $a1, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x000060A8 + 2, ((newSize >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x000060B8 + 2, ((newSize) & 0xFFFF));

	//8002ACAC:	3C04803E	LUI     $a0, 0x803E	#
	//8002ACB0:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800

	//8002AD00:	3C04803E	LUI     $a0, 0x803E	#
	//8002AD04:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800

	//8002AD58:	3C04803E	LUI     $a0, 0x803E	#
	//8002AD5C:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800

	//8002ADD8:	3C04803E	LUI     $a0, 0x803E	#
	//8002ADDC:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800

	//8002AE0C:	3C04803E	LUI     $a0, 0x803E	#
	//8002AE10:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800

	WriteAddiuAddress(ROM, newFrameBuffer3, 0x000060AC, 0x000060B0);
	WriteAddiuAddress(ROM, newFrameBuffer3, 0x00006100, 0x00006104);
	WriteAddiuAddress(ROM, newFrameBuffer3, 0x00006158, 0x0000615C);
	WriteAddiuAddress(ROM, newFrameBuffer3, 0x000061D8, 0x000061DC);
	WriteAddiuAddress(ROM, newFrameBuffer3, 0x0000620C, 0x00006210);
	WriteAddiuAddress(ROM, newFrameBuffer3, 0x00316EF0, 0x00316EF4);


	//80026DA0:	24050140	ADDIU   $a1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000021A0 + 2, newWidth);
	//80026DA4:	240600F0	ADDIU   $a2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000021A4 + 2, newHeight);

	//80028534:	2A020140	SLTI    $v0, $s0, 0x0140	#
	WriteShortToBuffer(ROM, 0x00003934 + 2, newWidth);
	//8002853C:	2410013F	ADDIU   $s0, $zero, 0x013F	#
	WriteShortToBuffer(ROM, 0x0000393C + 2, newWidth - 1);
	//80028540:	2A2200F0	SLTI    $v0, $s1, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00003940 + 2, newHeight);
	//80028548:	241100EF	ADDIU   $s1, $zero, 0x00EF	#
	WriteShortToBuffer(ROM, 0x00003948 + 2, newHeight - 1);
	//8002854C:	2A820141	SLTI    $v0, $s4, 0x0141	#
	WriteShortToBuffer(ROM, 0x0000394C + 2, newWidth + 1);
	//80028554:	24140140	ADDIU   $s4, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00003954 + 2, newWidth);
	//80028558:	2A4200F1	SLTI    $v0, $s2, 0x00F1	#
	WriteShortToBuffer(ROM, 0x00003958 + 2, newHeight + 1);
	//80028560:	241200F0	ADDIU   $s2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00003960 + 2, newHeight);

	//8002D8F8:	2B020140	SLTI    $v0, $t8, 0x0140	#
	WriteShortToBuffer(ROM, 0x00008CF8 + 2, newWidth);
	//8002D900:	2418013F	ADDIU   $t8, $zero, 0x013F	#
	WriteShortToBuffer(ROM, 0x00008D00 + 2, newWidth - 1);
	//8002D904:	2B2200F0	SLTI    $v0, $t9, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00008D04 + 2, newHeight);
	//8002D90C:	241900EF	ADDIU   $t9, $zero, 0x00EF	#
	WriteShortToBuffer(ROM, 0x00008D0C + 2, newHeight - 1);
	//8002D910:	2BC20141	SLTI    $v0, $s8, 0x0141	#
	WriteShortToBuffer(ROM, 0x00008D10 + 2, newWidth + 1);
	//8002D918:	241E0140	ADDIU   $s8, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00008D18 + 2, newWidth);
	//8002D91C:	2A8200F1	SLTI    $v0, $s4, 0x00F1	#
	WriteShortToBuffer(ROM, 0x00008D1C + 2, newHeight + 1);
	//8002D924:	241400F0	ADDIU   $s4, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00008D24 + 2, newHeight);

	//80033798:	2406013F	ADDIU   $a2, $zero, 0x013F	#
	//8003379C:	240700EF	ADDIU   $a3, $zero, 0x00EF	#
	WriteShortToBuffer(ROM, 0x0000EB9C + 2, newHeight - 1);
	WriteShortToBuffer(ROM, 0x0000EB98 + 2, newWidth - 1);

	WriteShortToBuffer(ROM, 0x000CE378 + 2, newHeight - 1);
	WriteShortToBuffer(ROM, 0x000CE380 + 2, newWidth - 1);

	WriteShortToBuffer(ROM, 0x000CF51C + 2, newHeight - 1);
	WriteShortToBuffer(ROM, 0x000CF520 + 2, newWidth);

	WriteShortToBuffer(ROM, 0x001410FC + 2, newHeight - 1);
	WriteShortToBuffer(ROM, 0x00141100 + 2, newWidth - 1);
	WriteShortToBuffer(ROM, 0x001410F4 + 2, newHeight - 1);
	WriteShortToBuffer(ROM, 0x00141108 + 2, newWidth - 1);

	// Didn't do this one, don't know if if need
	//8002C0B8:	24020280	ADDIU   $v0, $zero, 0x0280	#

	//80041D60:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//80041D68:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//80041DF4:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//80041DFC:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//80041E98:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//80041EA0:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//800E863C:	24110140	ADDIU   $s1, $zero, 0x0140	#
	//800E8644:	241000F0	ADDIU   $s0, $zero, 0x00F0	#

	//80127D20:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//80127D28:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//801299F4:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//801299FC:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//8012C1D4:	24020140	ADDIU   $v0, $zero, 0x0140	#
	//8012C1DC:	240200F0	ADDIU   $v0, $zero, 0x00F0	#

	//80139F78:	240B0140	ADDIU   $t3, $zero, 0x0140	#
	//80139F7C:	240C00F0	ADDIU   $t4, $zero, 0x00F0	#

	//80147984:	24080140	ADDIU   $t0, $zero, 0x0140	#
	//80147994:	240300F0	ADDIU   $v1, $zero, 0x00F0	#

	WriteShortToBuffer(ROM, 0x0001D160 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0001D168 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0001D1F4 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0001D1FC + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0001D298 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0001D2A0 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x000BE420 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x000BE428 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x000C00F4 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x000C00FC + 2, newHeight);

	WriteShortToBuffer(ROM, 0x000C28D4 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x000C28DC + 2, newHeight);

	WriteShortToBuffer(ROM, 0x001393BC + 2, newWidth);
	WriteShortToBuffer(ROM, 0x001393C4 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013ADBC + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013ADC4 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013BC50 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013BC58 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013BD28 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013BD30 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013BF90 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013BF98 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013C028 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013C030 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013CDA8 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013CDB0 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013D548 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013D550 + 2, newHeight);

	WriteShortToBuffer(ROM, 0x0013D620 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0013D628 + 2, newHeight);	

	WriteShortToBuffer(ROM, 0x0016F188 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0016F190 + 2, newHeight);	

	WriteShortToBuffer(ROM, 0x0072C83C + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0072C844 + 2, newHeight);	

	WriteShortToBuffer(ROM, 0x0073158C + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00731594 + 2, newHeight);	

	WriteShortToBuffer(ROM, 0x00908A84 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00908A8C + 2, newHeight);	

	WriteShortToBuffer(ROM, 0x00E129D0 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00E129D8 + 2, newHeight);	

	//800261F8:	3C06FF10	LUI     $a2, 0xFF10	#
	//800261FC:	34C6013F	ORI     $a2, $a2, 0x013F	#(*CONSTANT) FF10013F
	WriteLongToBuffer(ROM, 0x00002338, 0x358C027F);

	//80027BB8:	3C07FF10	LUI     $a3, 0xFF10	#
	//80027BBC:	34E7013F	ORI     $a3, $a3, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x000015FC + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x00353748 + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x003B93FC + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x003B995C + 2, 0x27F);

	//80028060:	3C08FF10	LUI     $t0, 0xFF10	#
	//80028064:	3508013F	ORI     $t0, $t0, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00003464 + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x00003788 + 2, 0x27F);

	//8002833C:	3C05FF10	LUI     $a1, 0xFF10	#
	//80028340:	34A5013F	ORI     $a1, $a1, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00003740 + 2, 0x27F);

	//80028384:	3C08FF10	LUI     $t0, 0xFF10	#
	//80028388:	3508013F	ORI     $t0, $t0, 0x013F	#(*CONSTANT) FF10013F

	//8002BB58:	3C03FF10	LUI     $v1, 0xFF10	#
	//8002BB5C:	3463013F	ORI     $v1, $v1, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00006F5C + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x00009238 + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x00012B1C + 2, 0x27F);

	//8002DE34:	3C03FF10	LUI     $v1, 0xFF10	#
	//8002DE38:	3463013F	ORI     $v1, $v1, 0x013F	#(*CONSTANT) FF10013F

	//80037718:	3C03FF10	LUI     $v1, 0xFF10	#
	//8003771C:	3463013F	ORI     $v1, $v1, 0x013F	#(*CONSTANT) FF10013F

	//800F75AC:	3C09FF10	LUI     $t1, 0xFF10	#
	//800F75B0:	3529013F	ORI     $t1, $t1, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00090A60 + 2, 0x27F);

	//8011CB20:	3C18FF10	LUI     $t8, 0xFF10	#
	//8011CB24:	3718013F	ORI     $t8, $t8, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x000B3224 + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x000B3988 + 2, 0x27F);

	//8011D284:	3C18FF10	LUI     $t8, 0xFF10	#
	//8011D288:	3718013F	ORI     $t8, $t8, 0x013F	#(*CONSTANT) FF10013F

	//801397BC:	3C07FF10	LUI     $a3, 0xFF10	#
	//801397C4:	34E7013F	ORI     $a3, $a3, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00002FBC + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x000CFEC4 + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x003B9200 + 2, 0x27F);

	//80143D28:	3C15FF10	LUI     $s5, 0xFF10	#
	//80143D2C:	36B5013F	ORI     $s5, $s5, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x000DA42C + 2, 0x27F);

	//80147B88:	3C12FF10	LUI     $s2, 0xFF10	#
	//80147B8C:	3652013F	ORI     $s2, $s2, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x000DE28C + 2, 0x27F);
	WriteShortToBuffer(ROM, 0x008010EC + 2, 0x27F);

	//80148D38:	3C0DFF10	LUI     $t5, 0xFF10	#
	//80148D3C:	35AD013F	ORI     $t5, $t5, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x000DF43C + 2, 0x27F);

	//80243D14:	3C05FF10	LUI     $a1, 0xFF10	#
	//80243D20:	34A5013F	ORI     $a1, $a1, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00A2DF60 + 2, 0x27F);


	//80026240:	3C050050	LUI     $a1, 0x0050	#
	//80026244:	34A503C0	ORI     $a1, $a1, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00001640 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00001644 + 2, 0x0780);

	//80027E14:	3C040050	LUI     $a0, 0x0050	#
	//80027E20:	348403C0	ORI     $a0, $a0, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00003214 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00003220 + 2, 0x0780);

	//80028040:	3C060050	LUI     $a2, 0x0050	#
	//8002804C:	34C603C0	ORI     $a2, $a2, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00003440 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x0000344C + 2, 0x0780);

	//8003775C:	3C060050	LUI     $a2, 0x0050	#
	//80037760:	34C603C0	ORI     $a2, $a2, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00012B5C + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00012B60 + 2, 0x0780);

	//800F1030:	3C090050	LUI     $t1, 0x0050	#
	//800F1034:	352903C0	ORI     $t1, $t1, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x0008A4E0 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x0008A4E4 + 2, 0x0780);

	//800F576C:	3C020050	LUI     $v0, 0x0050	#
	//800F5770:	344203C0	ORI     $v0, $v0, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x0008EC1C + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x0008EC20 + 2, 0x0780);

	//800F75B4:	3C0A0050	LUI     $t2, 0x0050	#
	//800F75B8:	354A03C0	ORI     $t2, $t2, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00090A64 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00090A68 + 2, 0x0780);

	//80136CC4:	3C060050	LUI     $a2, 0x0050	#
	//80136CC8:	34C603C0	ORI     $a2, $a2, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x000CD3C4 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x000CD3C8 + 2, 0x0780);

	//80136E74:	3C040050	LUI     $a0, 0x0050	#
	//80136E78:	348403C0	ORI     $a0, $a0, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x000CD574 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x000CD578 + 2, 0x0780);

	//8013981C:	3C040050	LUI     $a0, 0x0050	#
	//80139820:	348403C0	ORI     $a0, $a0, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x000CFF1C + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x000CFF20 + 2, 0x0780);

	WriteShortToBuffer(ROM, 0x00136A9C + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00136AA0 + 2, 0x0780);

	//802433B0:	3C050050	LUI     $a1, 0x0050	#
	//802433B4:	34A503C0	ORI     $a1, $a1, 0x03C0	#(*CONSTANT) 005003C0
	WriteShortToBuffer(ROM, 0x00A2D5F0 + 2, 0x00A0);
	WriteShortToBuffer(ROM, 0x00A2D5F4 + 2, 0x0780);

	WriteLongToBuffer(ROM, 0x0005150C, 0x00A00780);
	WriteLongToBuffer(ROM, 0x00052ED4, 0x00A00780);
	WriteLongToBuffer(ROM, 0x0006F00C, 0x00A00780);
	WriteLongToBuffer(ROM, 0x00072B24, 0x00A00780);
	WriteLongToBuffer(ROM, 0x000E577C, 0x00A00780);
	WriteLongToBuffer(ROM, 0x000E57A4, 0x00A00780);
	WriteLongToBuffer(ROM, 0x003B9FAC, 0x00A00780);


	//80028070:	3C0AF64F	LUI     $t2, 0xF64F	#
	//80028074:	354AC3BC	ORI     $t2, $t2, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x00003470 + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x00003474 + 2, 0x8778);

	//80028394:	3C0AF64F	LUI     $t2, 0xF64F	#
	//80028398:	354AC3BC	ORI     $t2, $t2, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x00003794 + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x00003798 + 2, 0x8778);

	//80028758:	3C02F64F	LUI     $v0, 0xF64F	#
	//80028760:	3442C3BC	ORI     $v0, $v0, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x00003B58 + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x00003B60 + 2, 0x8778);

	//800343D0:	3C0BF64F	LUI     $t3, 0xF64F	#
	//800343DC:	356BC3BC	ORI     $t3, $t3, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x0000F7D0 + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x0000F7DC + 2, 0x8778);

	//80136CCC:	3C07F64F	LUI     $a3, 0xF64F	#
	//80136CD0:	34E7C3BC	ORI     $a3, $a3, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x000CD3CC + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x000CD3D0 + 2, 0x8778);

	WriteLongToBuffer(ROM, 0x003BA010, 0xF69F8778);


	// Stretch screen
	//8002DF50:	241100A0	ADDIU   $s1, $zero, 0x00A0	#
	//8002DF54:	24100078	ADDIU   $s0, $zero, 0x0078	#
	WriteShortToBuffer(ROM, 0x00009350 + 2, newWidth / 2);
	WriteShortToBuffer(ROM, 0x00009354 + 2, newHeight / 2);

	//8002E084:	241100A0	ADDIU   $s1, $zero, 0x00A0	#
	//8002E088:	24100078	ADDIU   $s0, $zero, 0x0078	#
	WriteShortToBuffer(ROM, 0x00009484 + 2, newWidth / 2);
	WriteShortToBuffer(ROM, 0x00009488 + 2, newHeight / 2);

	for (int x = 0; x < romSize; x += 4)
	{
		if ((CharArrayToLong(&ROM[x]) == 0x028001E0) && (CharArrayToLong(&ROM[x + 4]) == 0x01FF0000))
		{
			WriteLongToBuffer(ROM, x, 0x050003C0);
		}
	}

	WriteLongToBuffer(ROM, 0x000E5558, 0x050003C0);
	WriteLongToBuffer(ROM, 0x001024D8, 0x050003C0);

	//80033DC8:	24040128	ADDIU   $a0, $zero, 0x0128	#
	//80033DDC:	240500C8	ADDIU   $a1, $zero, 0x00C8	#
	WriteShortToBuffer(ROM, 0x0000F1C8 + 2, 0x128 * 2);
	WriteShortToBuffer(ROM, 0x0000F1DC + 2, 0xC8 * 2);

	//80034E70:	24040128	ADDIU   $a0, $zero, 0x0128	#
	//80034E84:	240500C8	ADDIU   $a1, $zero, 0x00C8	#
	WriteShortToBuffer(ROM, 0x00010270 + 2, 0x128 * 2);
	WriteShortToBuffer(ROM, 0x00010284 + 2, 0xC8 * 2);

	//800359B4:	24040128	ADDIU   $a0, $zero, 0x0128	#
	//800359C8:	240500C8	ADDIU   $a1, $zero, 0x00C8	#
	WriteShortToBuffer(ROM, 0x00010DB4 + 2, 0x128 * 2);
	WriteShortToBuffer(ROM, 0x00010DC8 + 2, 0xC8 * 2);

	//8005AAC4:	24040128	ADDIU   $a0, $zero, 0x0128	#
	//8005AAD8:	240500C8	ADDIU   $a1, $zero, 0x00C8	#
	WriteShortToBuffer(ROM, 0x00035EC4 + 2, 0x128 * 2);
	WriteShortToBuffer(ROM, 0x00035ED8 + 2, 0xC8 * 2);

	//8005AB3C:	240200A2	ADDIU   $v0, $zero, 0x00A2	#
	WriteShortToBuffer(ROM, 0x00035F3C + 2, 0xA2 * 2);
	//8005AB40:	240200C8	ADDIU   $v0, $zero, 0x00C8	#
	WriteShortToBuffer(ROM, 0x00035F40 + 2, 0xC8 * 2);

	//8005AB58:	24070128	ADDIU   $a3, $zero, 0x0128	#
	//8005AB6C:	24070106	ADDIU   $a3, $zero, 0x0106	#
	WriteShortToBuffer(ROM, 0x00035F58 + 2, 0x128 * 2);
	WriteShortToBuffer(ROM, 0x00035F6C + 2, 0x106 * 2);

	//801413FC:	240200EF	ADDIU   $v0, $zero, 0x00EF	#
	//8014140C:	2407013F	ADDIU   $a3, $zero, 0x013F	#
	WriteShortToBuffer(ROM, 0x000D7AFC + 2, 0xEF * 2);
	WriteShortToBuffer(ROM, 0x000D7AFC + 2, 0x13F * 2);

	// Depth Buffer
	//8005F580:	3C028000	LUI     $v0, 0x8000	#
	//8005F584:	34420400	ORI     $v0, $v0, 0x0400	#(*CONSTANT) 80000400
	WriteShortToBuffer(ROM, 0x0003A980 + 2, 0x8040);
	WriteShortToBuffer(ROM, 0x0003A984 + 2, 0x0000);

	FILE* outFile = fopen("C:\\temp\\paperhires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\paperhires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk14()
{
	int romSize = 0xC00000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Quake II (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x01, 0x30, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x01, 0x33, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x0006CD40 + x + 4] = rawData[x];
		ROM[0x0006CD90 + x + 4] = rawData[x];
		ROM[0x0006CDE0 + x + 4] = rawData[x];
		ROM[0x0006CE30 + x + 4] = rawData[x];
		ROM[0x0006CE80 + x + 4] = rawData[x];
		ROM[0x0006CDE0 + x + 4] = rawData[x];
		ROM[0x0006CF20 + x + 4] = rawData[x];
		ROM[0x0006CF70 + x + 4] = rawData[x];
		ROM[0x0006CFC0 + x + 4] = rawData[x];
		ROM[0x0006D010 + x + 4] = rawData[x];
		ROM[0x0006D060 + x + 4] = rawData[x];
		ROM[0x0006D0B0 + x + 4] = rawData[x];
		ROM[0x0006DB70 + x + 4] = rawData[x];
	}


	// Disable overwrites
	//80056930:	2404FFF7	ADDIU   $a0, $zero, 0xFFF7	#
	//80056970:	2404FFFB	ADDIU   $a0, $zero, 0xFFFB	#
	//800569B0:	2404FFEF	ADDIU   $a0, $zero, 0xFFEF	#
	//800569F8:	3C02FFFE	LUI     $v0, 0xFFFE	#
	//80056A0C:	3442FFFF	ORI     $v0, $v0, 0xFFFF	#(*CONSTANT) FFFEFFFF
	WriteShortToBuffer(ROM, 0x00057530 + 2, 0xFFFF);
	WriteShortToBuffer(ROM, 0x00057570 + 2, 0xFFFF);
	WriteShortToBuffer(ROM, 0x000575B0 + 2, 0xFFFF);
	WriteShortToBuffer(ROM, 0x000575F8 + 2, 0xFFFF);
	WriteShortToBuffer(ROM, 0x0005760C + 2, 0xFFFF);

	// Increase buffer size by shifting to C
	//800055F4:	00021280	SLL     $v0, $v0, 0x0A	#
	WriteLongToBuffer(ROM, 0x000061F4, 0x00021300);

	// Force Lo Res
	//80005384:	3C038000	LUI     $v1, 0x8000	#
	//80005388:	8C630318	LW      $v1, 0x0318($v1)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x00005F84, 0x3C030040);
	WriteLongToBuffer(ROM, 0x00005F88, 0x00000000);

	//80005474:	3C038000	LUI     $v1, 0x8000	#
	//80005478:	8C630318	LW      $v1, 0x0318($v1)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x00006074, 0x3C030040);
	WriteLongToBuffer(ROM, 0x00006078, 0x00000000);

	//80005698:	3C068000	LUI     $a2, 0x8000	#
	//8000569C:	8CC60318	LW      $a2, 0x0318($a2)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x00006298, 0x3C060040);
	WriteLongToBuffer(ROM, 0x0000629C, 0x00000000);

	//80006350:	3C038000	LUI     $v1, 0x8000	#
	//80006354:	8C630318	LW      $v1, 0x0318($v1)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x00006F50, 0x3C030040);
	WriteLongToBuffer(ROM, 0x00006F54, 0x00000000);

	//80013B6C:	3C038000	LUI     $v1, 0x8000	#
	//80013B70:	8C630318	LW      $v1, 0x0318($v1)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x0001476C, 0x3C030040);
	WriteLongToBuffer(ROM, 0x00014770, 0x00000000);

	//80023384:	3C038000	LUI     $v1, 0x8000	#
	//80023388:	8C630318	LW      $v1, 0x0318($v1)	#(*LOAD) 80000318
	WriteLongToBuffer(ROM, 0x00023F84, 0x3C030040);
	WriteLongToBuffer(ROM, 0x00023F88, 0x00000000);


	unsigned long startAddress = 0x000655A0;
	while (startAddress < 0x000655C0)
	{
		unsigned short widthTemp = CharArrayToShort(&ROM[startAddress]);
		unsigned short heightTemp = CharArrayToShort(&ROM[startAddress + 2]);
		WriteShortToBuffer(ROM, startAddress, widthTemp * 2);
		WriteShortToBuffer(ROM, startAddress + 2, heightTemp * 2);
		startAddress += 0x8;
	}

	// Depth Buffer written offset to RAM 80088120
	// Part of dynamic allocation just increase size
	//80005668:	3C04800A	LUI     $a0, 0x800A	#
	//8000566C:	24847E1F	ADDIU   $a0, $a0, 0x7E1F	#(*CONSTANT) 800A7E1F
	// Change Depth Buffer Size
	//80005660:	3C030002	LUI     $v1, 0x0002	#
	//80005664:	34635800	ORI     $v1, $v1, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x00006260 + 2, 0x0009);
	WriteShortToBuffer(ROM, 0x00006264 + 2, 0x6000);
	// Don't do second spot, this crashes menus, messes up menus
	//8000CD68:	3C100002	LUI     $s0, 0x0002	#
	//8000CD6C:	36105800	ORI     $s0, $s0, 0x5800	#(*CONSTANT) 00025800
	//WriteShortToBuffer(ROM, 0x0000D968 + 2, 0x0009);
	//WriteShortToBuffer(ROM, 0x0000D96C + 2, 0x6000);


	unsigned short newWidth = 0x280;
	unsigned long newHeight = 0x1E0;

	//80006994:	24060140	ADDIU   $a2, $zero, 0x0140	#
	//8000699C:	240700F0	ADDIU   $a3, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00007594 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x0000759C + 2, newHeight);

	WriteShortToBuffer(ROM, 0x00008970 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00008974 + 2, newHeight);

	//80000E3C:	3C0CFF10	LUI     $t4, 0xFF10	#
	//80000E40:	358C013F	ORI     $t4, $t4, 0x013F	#(*CONSTANT) FF10013F
	WriteShortToBuffer(ROM, 0x00001A3C + 2, 0xFF10);
	WriteShortToBuffer(ROM, 0x00001A40 + 2, 0x027F);
	
	//80000FB4:	3C10FF00	LUI     $s0, 0xFF00	#
	//80000FB8:	3610013F	ORI     $s0, $s0, 0x013F	#(*CONSTANT) FF00013F
	WriteShortToBuffer(ROM, 0x00001BB4 + 2, 0xFF00);
	WriteShortToBuffer(ROM, 0x00001BB8 + 2, 0x027F);

	//80000FE0:	3C05004F	LUI     $a1, 0x004F	#
	//80000FE4:	34A5C3BC	ORI     $a1, $a1, 0xC3BC	#(*CONSTANT) 004FC3BC
	WriteShortToBuffer(ROM, 0x00001BE0 + 2, 0x009F);
	WriteShortToBuffer(ROM, 0x00001BE4 + 2, 0x8778);

	//8000325C:	3C04004F	LUI     $a0, 0x004F	#
	//80003260:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x00003E5C + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x00003E60 + 2, 0x8778);

	//800042F0:	3C04004F	LUI     $a0, 0x004F	#
	//800042F4:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x00004EF0 + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x00004EF4 + 2, 0x8778);

	//80004964:	3C04004F	LUI     $a0, 0x004F	#
	//80004968:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x00005564 + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x00005568 + 2, 0x8778);

	//800182DC:	3C05004F	LUI     $a1, 0x004F	#
	//800182F0:	34A5C3BC	ORI     $a1, $a1, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x00018EDC + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x00018EF0 + 2, 0x8778);

	//80018860:	3C08004F	LUI     $t0, 0x004F	#
	//80018864:	3508C3BC	ORI     $t0, $t0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x00019460 + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x00019464 + 2, 0x8778);

	//8001A354:	3C04004F	LUI     $a0, 0x004F	#
	//8001A358:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteShortToBuffer(ROM, 0x0001AF54 + 2, 0x009F);
	//WriteShortToBuffer(ROM, 0x0001AF58 + 2, 0x8778);



	//80000E54:	3C0FF64F	LUI     $t7, 0xF64F	#
	//80000EC4:	35EFC3BC	ORI     $t7, $t7, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteShortToBuffer(ROM, 0x00001A54 + 2, 0xF69F);
	WriteShortToBuffer(ROM, 0x00001AC4 + 2, 0x8778);

	//80016ADC:	3C06F64F	LUI     $a2, 0xF64F	#
	//80016AE8:	34C6C3BC	ORI     $a2, $a2, 0xC3BC	#(*CONSTANT) F64FC3BC
	//WriteShortToBuffer(ROM, 0x000176DC + 2, 0xF69F);
	//WriteShortToBuffer(ROM, 0x000176E8 + 2, 0x8778);
	
	


	// Lose 16-bit?
	//80000FC0:	30420003	ANDI    $v0, $v0, 0x0003	#
	WriteLongToBuffer(ROM, 0x00001BC0, 0x30420002);
	// These are second area not done for other params either
	//WriteLongToBuffer(ROM, 0x0000D878, 0x30420002);
	//WriteLongToBuffer(ROM, 0x0000FC60, 0x30420002);*/

	FILE* outFile = fopen("C:\\temp\\quake2hires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\quake2hires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk15()
{
	int romSize = 0x2000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\007 - The World is Not Enough (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x01, 0x30, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x01, 0x33, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x000D0B60 + x + 4] = rawData[x];
		ROM[0x000D1D60 + x + 4] = rawData[x];
	}

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	int newSize = newWidth * newHeight * 2;
	int newSizeDoubled = newWidth * newHeight * 2 * 2;
	// Force lo res
	//WriteShortToBuffer(ROM, 0x000A73B8 + 2, 0x003F);

	//80006784:	24030140	ADDIU   $v1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00007384 + 2, newWidth); 
	//80006794:	240300F0	ADDIU   $v1, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00007394 + 2, newHeight); 

	//8000721C:	24020140	ADDIU   $v0, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00007E1C + 2, newWidth); 
	//80007228:	240200F0	ADDIU   $v0, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00007E28 + 2, newHeight); 

	//80007278:	24020140	ADDIU   $v0, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00007E78 + 2, newWidth); 

	//80007284:	240201E0	ADDIU   $v0, $zero, 0x01E0	#
	WriteShortToBuffer(ROM, 0x00007E84 + 2, newHeight * 2); 

	//80039D7C:	28820141	SLTI    $v0, $a0, 0x0141	#
	WriteShortToBuffer(ROM, 0x0003A97C + 2, newWidth + 1); 
	//80039D84:	24040140	ADDIU   $a0, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x0003A984 + 2, newWidth); 
	//80039D98:	286200F1	SLTI    $v0, $v1, 0x00F1	#
	WriteShortToBuffer(ROM, 0x0003A998 + 2, newHeight + 1); 
	//80039DA0:	240300F0	ADDIU   $v1, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0003B598 + 2, newHeight); 

	//8003A33C:	28820141	SLTI    $v0, $a0, 0x0141	#
	WriteShortToBuffer(ROM, 0x0003AF3C + 2, newWidth + 1); 
	//8003A348:	24040140	ADDIU   $a0, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x0003AF48 + 2, newWidth); 
	//8003A34C:	286200F1	SLTI    $v0, $v1, 0x00F1	#
	WriteShortToBuffer(ROM, 0x0003AF4C + 2, newHeight + 1); 
	//8003A354:	240300F0	ADDIU   $v1, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0003AF54 + 2, newHeight); 

	//8006DADC:	24050140	ADDIU   $a1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x0006E6DC + 2, newWidth); 
	//8006DAE4:	240400F0	ADDIU   $a0, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x0006E6E4 + 2, newHeight); 

	//8005919C:	3C014370	LUI     $at, 0x4370	#
	//WriteShortToBuffer(ROM, 0x00059D9C + 2, 0x43F0);

	// These 4 do impact it
	//80075614:	3C014320	LUI     $at, 0x4320	#
	WriteShortToBuffer(ROM, 0x00076214 + 2, 0x43A0); 
	//80075620:	3C1E42F0	LUI     $s8, 0x42F0	#
	WriteShortToBuffer(ROM, 0x00076220 + 2, 0x4370); 
	//800756A0:	3C014370	LUI     $at, 0x4370	#
	WriteShortToBuffer(ROM, 0x000762A0 + 2, 0x43F0); 
	//800756A8:	3C0143A0	LUI     $at, 0x43A0	#
	WriteShortToBuffer(ROM, 0x000762A8 + 2, 0x4420);

	//80075EC4:	3C0142F0	LUI     $at, 0x42F0	#
	//WriteShortToBuffer(ROM, 0x00076AC4 + 2, 0x4370); 
	//80075ECC:	3C014370	LUI     $at, 0x4370	#
	//WriteShortToBuffer(ROM, 0x00076ACC + 2, 0x43F0); 
	//80075EDC:	3C014320	LUI     $at, 0x4320	#
	//WriteShortToBuffer(ROM, 0x00076ADC + 2, 0x43A0); 
	//80075EE8:	3C0143A0	LUI     $at, 0x43A0	#
	//WriteShortToBuffer(ROM, 0x00076AE8 + 2, 0x4420);

	//8007793C:	3C014370	LUI     $at, 0x4370	#
	//WriteShortToBuffer(ROM, 0x0007853C + 2, 0x43F0); 
	//8007794C:	3C0142F0	LUI     $at, 0x42F0	#
	//WriteShortToBuffer(ROM, 0x0007794C + 2, 0x4370); 

	// Force go smaller buffers
	WriteLongToBuffer(ROM, 0x000011D0, 0x24030000);
	WriteShortToBuffer(ROM, 0x000012B4 + 2, 0x8080);

	//800006B8:	3C040002	LUI     $a0, 0x0002	#
	//800006BC:	34845800	ORI     $a0, $a0, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x000012B8 + 2, ((newSize >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x000012BC + 2, ((newSize) & 0xFFFF));

	//800006C8:	3C040002	LUI     $a0, 0x0002	#
	//800006CC:	34845800	ORI     $a0, $a0, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x000012C8 + 2, ((newSize >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x000012CC + 2, ((newSize) & 0xFFFF));

	//800006E0:	3C040002	LUI     $a0, 0x0002	#
	//800006E4:	34845800	ORI     $a0, $a0, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x000012E0 + 2, ((newSize >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x000012E4 + 2, ((newSize) & 0xFFFF));

	//800081DC:	3C120002	LUI     $s2, 0x0002	#
	//800081E0:	36525800	ORI     $s2, $s2, 0x5800	#(*CONSTANT) 00025800
	WriteShortToBuffer(ROM, 0x00008DDC + 2, ((newSize >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x00008DE0 + 2, ((newSize) & 0xFFFF));

	//800005F0:	3C040004	LUI     $a0, 0x0004	#
	//800005F4:	3484B000	ORI     $a0, $a0, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x000011F0 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x000011F4 + 2, ((newSizeDoubled) & 0xFFFF));

	//80000600:	3C040004	LUI     $a0, 0x0004	#
	//80000604:	3484B000	ORI     $a0, $a0, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x00001200 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x00001204 + 2, ((newSizeDoubled) & 0xFFFF));

	// These two crash emu in row
	//80000618:	3C040004	LUI     $a0, 0x0004	#
	//8000061C:	3484B000	ORI     $a0, $a0, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x00001218 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x0000121C + 2, ((newSizeDoubled) & 0xFFFF));

	//80000630:	3C040004	LUI     $a0, 0x0004	#
	//80000634:	3484B000	ORI     $a0, $a0, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x00001230 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x00001234 + 2, ((newSizeDoubled) & 0xFFFF));

	//800081F4:	3C120004	LUI     $s2, 0x0004	#
	//800081F8:	3652B000	ORI     $s2, $s2, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x00008DF4 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x00008DF8 + 2, ((newSizeDoubled) & 0xFFFF));

	//8000B834:	3C050004	LUI     $a1, 0x0004	#
	//8000B838:	34A5B000	ORI     $a1, $a1, 0xB000	#(*CONSTANT) 0004B000
	WriteShortToBuffer(ROM, 0x0000C434 + 2, ((newSizeDoubled >> 16) & 0xFFFF));
	WriteShortToBuffer(ROM, 0x0000C438 + 2, ((newSizeDoubled) & 0xFFFF));


	// Depth Buffer (in dynamic memory?)
	//800005E0:	3C048012	LUI     $a0, 0x8012	#
	//800005E4:	2484FF40	ADDIU   $a0, $a0, 0xFF40	#(*CONSTANT) 8011FF40
	//WriteShortToBuffer(ROM, 0x000011E0 + 2, 0x8060);
	//WriteShortToBuffer(ROM, 0x000011E4 + 2, 0x0000);

	//800006A8:	3C048012	LUI     $a0, 0x8012	#
	//800006AC:	2484FF40	ADDIU   $a0, $a0, 0xFF40	#(*CONSTANT) 8011FF40
	//WriteShortToBuffer(ROM, 0x000012A8 + 2, 0x8060);
	//WriteShortToBuffer(ROM, 0x000012AC + 2, 0x0000);


	FILE* outFile = fopen("C:\\temp\\twinehires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\twinehires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk16()
{
	// Not working console...

	int romSize = 0x4000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Legend of Zelda, The - Ocarina of Time (U) (V1.0) Decompressed [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x6FC0 + x + 4] = rawData[x];
	}

	//Disable overwrite of AA
	// Need find
	WriteLongToBuffer(ROM, 0x00B48E88, 0x2401FFFF);
	



	// Force to 8080 for video write
	WriteShortToBuffer(ROM, 0x00B1A290 + 2, 0x8080);

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;

	unsigned long newFrameBufferLocation = 0x80800000;
	unsigned long deltaFirst = -newSize;
	unsigned long deltaSecond = -(newSize * 2);
	
	//FFFB5000
	WriteAddiuAddress(ROM, deltaSecond, 0x00B1A2E0, 0x00B1A2E4); 

	//FFFDA800
	WriteAddiuAddress(ROM, deltaFirst, 0x00B1A2F8, 0x00B1A2FC);
	WriteAddiuAddress(ROM, deltaFirst, 0x00B24EC8, 0x00B24ECC);
	WriteAddiuAddress(ROM, deltaFirst, 0x00B25410, 0x00B25414);

	//8007FC2C:	3C060002	LUI     $a2, 0x0002	#
	//8007FC30:	34C65800	ORI     $a2, $a2, 0x5800	#(*CONSTANT) 00025800
	//WriteLongToBuffer(ROM, 0x00B8F460, newSize);
	//WriteAddiuAddress(ROM, newSize, 0x00AF5B8C, 0x00AF5B90);

	unsigned long newDepthbuffer = 0x80400000;

	// Depth Buffer?

	//8006684C:	3C1E8013	LUI     $s8, 0x8013	#
	//80066850:	27DEBE40	ADDIU   $s8, $s8, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00ADC7AC, 0x00ADC7B0);

	//8007F0E0:	3C098013	LUI     $t1, 0x8013	#
	//8007F0E4:	2529BE40	ADDIU   $t1, $t1, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00AF5040, 0x00AF5044);

	//8007F4F0:	3C0D8013	LUI     $t5, 0x8013	#
	//8007F4F4:	25ADBE40	ADDIU   $t5, $t5, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00AF5450, 0x00AF5454);

	//8007FBF8:	3C058013	LUI     $a1, 0x8013	#
	//8007FC0C:	24A5BE40	ADDIU   $a1, $a1, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00AF5B58, 0x00AF5B6C);

	//8007FC28:	3C048013	LUI     $a0, 0x8013	#
	//8007FC34:	2484BE40	ADDIU   $a0, $a0, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00AF5B88, 0x00AF5B94);

	//8009B00C:	3C0B8013	LUI     $t3, 0x8013	#
	//8009B01C:	256BBE40	ADDIU   $t3, $t3, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00B10F6C, 0x00B10F7C);

	//8009C568:	3C0F8013	LUI     $t7, 0x8013	#
	//8009C56C:	25EFBE40	ADDIU   $t7, $t7, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00B124C8, 0x00B124CC);

	//8009C984:	3C0F8013	LUI     $t7, 0x8013	#
	//8009C988:	25EFBE40	ADDIU   $t7, $t7, 0xBE40	#(*CONSTANT) 8012BE40
	WriteAddiuAddress(ROM, newDepthbuffer, 0x00B128E4, 0x00B128E8);


	//800756B4:	240E00F0	ADDIU   $t6, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00AEB614 + 2, newHeight);
	//800756B8:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00AEB618 + 2, newWidth);

	//80080FA8:	240E00F0	ADDIU   $t6, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00AF6F08 + 2, newHeight);
	//80080FAC:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00AF6F0C + 2, newWidth);

	//80091898:	240E00F0	ADDIU   $t6, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B077F8 + 2, newHeight);
	//8009189C:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B077FC + 2, newWidth);

	//8009355C:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B094BC + 2, newWidth);
	//80093560:	240F00F0	ADDIU   $t7, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B094C0 + 2, newHeight);
	

	//8009AC2C:	24050140	ADDIU   $a1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B10B8C + 2, newWidth);
	//8009AC30:	240600F0	ADDIU   $a2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B10B90 + 2, newHeight);

	//8009AC48:	24050140	ADDIU   $a1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B10BA8 + 2, newWidth);
	//8009AC4C:	240600F0	ADDIU   $a2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B10BAC + 2, newHeight);

	//8009C470:	241800F0	ADDIU   $t8, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B123D0 + 2, newHeight);
	//8009C474:	24190140	ADDIU   $t9, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B123D4 + 2, newWidth);

	//8009C580:	24050140	ADDIU   $a1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B124E0 + 2, newWidth);
	//8009C588:	240600F0	ADDIU   $a2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B124E8 + 2, newHeight);

	//800A1C64:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B17BC4 + 2, newWidth);
	//800A1C74:	240F00F0	ADDIU   $t7, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B17BD4 + 2, newHeight);

	//800A39D0:	241800F0	ADDIU   $t8, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B19930 + 2, newHeight);
	//800A39D4:	24190140	ADDIU   $t9, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B19934 + 2, newWidth);

	//800A3E2C:	241800F0	ADDIU   $t8, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B19D8C + 2, newHeight);
	//800A3E30:	24190140	ADDIU   $t9, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B19D90 + 2, newWidth);

	WriteShortToBuffer(ROM, 0x00B9F3C8 + 2, newHeight);
	WriteShortToBuffer(ROM, 0x00B9F3CC + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00B9F5B0 + 2, newHeight);
	WriteShortToBuffer(ROM, 0x00B9F5B4 + 2, newWidth);


	//800DDA30:	240E00F0	ADDIU   $t6, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x00B53990 + 2, newHeight);
	//800DDA34:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x00B53994 + 2, newWidth);

	// Changing FF10013F
	// Seems dynamic
	WriteLongToBuffer(ROM, 0x00B724C0, 0xFF10027F);
	


	//800939E4:	3C090050	LUI     $t1, 0x0050	#
	//800939E8:	352903C0	ORI     $t1, $t1, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00B09944, 0x3C0900A0);
	WriteLongToBuffer(ROM, 0x00B09948, 0x35290780);

	//800941C4:	3C0D0050	LUI     $t5, 0x0050	#
	//800941C8:	35AD03C0	ORI     $t5, $t5, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00B0A124, 0x3C0D00A0);
	WriteLongToBuffer(ROM, 0x00B0A128, 0x35AD0780);

	//80094430:	3C0F0050	LUI     $t7, 0x0050	#
	//80094434:	35EF03C0	ORI     $t7, $t7, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00B0A390, 0x3C0F00A0);
	WriteLongToBuffer(ROM, 0x00B0A394, 0x35EF0780);

	WriteLongToBuffer(ROM, 0x00B6EA2C, 0x00A00780);
	WriteLongToBuffer(ROM, 0x00B6EB14, 0x00A00780);
	WriteLongToBuffer(ROM, 0x00B8A5E4, 0x00A00780);
	WriteLongToBuffer(ROM, 0x00B8AA04, 0x00A00780);



	//800606C8:	3C0FF64F	LUI     $t7, 0xF64F	#
	//800606CC:	35EFC3BC	ORI     $t7, $t7, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD6628, 0x3C0FF69F);
	WriteLongToBuffer(ROM, 0x00AD662C, 0x35EF8778);

	//80060EE4:	3C08F64F	LUI     $t0, 0xF64F	#
	//80060EE8:	3508C3BC	ORI     $t0, $t0, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD6E44, 0x3C08F69F);
	WriteLongToBuffer(ROM, 0x00AD6E48, 0x35088778);

	//80060F64:	3C08F64F	LUI     $t0, 0xF64F	#
	//80060F68:	3508C3BC	ORI     $t0, $t0, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD6EC4, 0x3C08F69F);
	WriteLongToBuffer(ROM, 0x00AD6EC8, 0x35088778);

	//80060FFC:	3C0FF64F	LUI     $t7, 0xF64F	#
	//80061000:	35EFC3BC	ORI     $t7, $t7, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD6F5C, 0x3C0FF69F);
	WriteLongToBuffer(ROM, 0x00AD6F60, 0x35EF8778);

	WriteLongToBuffer(ROM, 0x00DE57D0, 0x3C0FF69F);
	WriteLongToBuffer(ROM, 0x00DE57D4, 0x35EF8778);

	//80062674:	3C08F64F	LUI     $t0, 0xF64F	#
	//80062678:	3508C3BC	ORI     $t0, $t0, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD85D4, 0x3C08F69F);
	WriteLongToBuffer(ROM, 0x00AD85D8, 0x35088778);

	//80062754:	3C19F64F	LUI     $t9, 0xF64F	#
	//80062758:	3739C3BC	ORI     $t9, $t9, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x00AD86B4, 0x3C19F69F);
	WriteLongToBuffer(ROM, 0x00AD86B8, 0x37398778);

	WriteLongToBuffer(ROM, 0x00DB8764, 0x3C19F69F);
	WriteLongToBuffer(ROM, 0x00DB8768, 0x37398778);

	WriteLongToBuffer(ROM, 0x00B6EA70, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B6EAB0, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B72108, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B72130, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B72148, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B72168, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B72178, 0xF69F8778);
	WriteLongToBuffer(ROM, 0x00B724D0, 0xF69F8778);


	FILE* outFile = fopen("C:\\temp\\oothires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\oothires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;	
}

void CMakeGameHiResDlg::OnBnClickedButtonbk17()
{
	// Not working console...

	int romSize = 0x1000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Pokemon Snap (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x01, 0x30, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x01, 0x33, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1NoAA;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x000439B0 + x + 4] = rawData[x];
		ROM[0x00043A00 + x + 4] = rawData[x];
	}

	//800027B0:	3C020001	LUI     $v0, 0x0001	#
	WriteLongToBuffer(ROM, 0x000033B0, 0x3C020000 | ((rawData[0] << 8) | (rawData[1])));
	//800027B4:	34420016	ORI     $v0, $v0, 0x0016	#(*CONSTANT) 00010016
	WriteLongToBuffer(ROM, 0x000033B4, 0x34420000 | ((rawData[2] << 8) | (rawData[3])));

	// Disable overwrite (lots of flags changed...)
	//80001230:	8C580004	LW      $t8, 0x0004($v0)	#
	WriteLongToBuffer(ROM, 0x00001E30, 0x3C190000 | ((rawData[0] << 8) | (rawData[1])));
	//8000123C:	0304C825	OR      $t9, $t8, $a0	#
	WriteLongToBuffer(ROM, 0x00001E3C, 0x37390000 | ((rawData[2] << 8) | (rawData[3])));
	


	int newWidth = 0x280;
	int newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;

	unsigned long newFrameBufferLocation = 0x80500000;
	unsigned long newFrameBufferLocationTwo = newFrameBufferLocation + (newSize);
	
	std::vector<unsigned long> registersChecks;
	registersChecks.push_back(0x24010000);
	registersChecks.push_back(0x24080000);
	registersChecks.push_back(0x24090000);
	registersChecks.push_back(0x240A0000);
	registersChecks.push_back(0x240B0000);
	registersChecks.push_back(0x240D0000);
	registersChecks.push_back(0x240E0000);
	registersChecks.push_back(0x240F0000);
	registersChecks.push_back(0x24180000);
	registersChecks.push_back(0x24190000);
	registersChecks.push_back(0x24100000);
	registersChecks.push_back(0x24110000);
	registersChecks.push_back(0x24120000);
	registersChecks.push_back(0x24130000);
	registersChecks.push_back(0x24140000);
	registersChecks.push_back(0x24150000);
	registersChecks.push_back(0x24160000);
	registersChecks.push_back(0x24170000);
	registersChecks.push_back(0x241E0000);
	registersChecks.push_back(0x24020000);
	registersChecks.push_back(0x24030000);
	registersChecks.push_back(0x24040000);
	registersChecks.push_back(0x24050000);
	registersChecks.push_back(0x24060000);
	registersChecks.push_back(0x24070000);

	std::vector<unsigned long> floatRegistersChecks;
	floatRegistersChecks.push_back(0x3C010000);
	floatRegistersChecks.push_back(0x3C080000);
	floatRegistersChecks.push_back(0x3C090000);
	floatRegistersChecks.push_back(0x3C0A0000);
	floatRegistersChecks.push_back(0x3C0B0000);
	floatRegistersChecks.push_back(0x3C0D0000);
	floatRegistersChecks.push_back(0x3C0E0000);
	floatRegistersChecks.push_back(0x3C0F0000);
	floatRegistersChecks.push_back(0x3C180000);
	floatRegistersChecks.push_back(0x3C190000);
	floatRegistersChecks.push_back(0x3C100000);
	floatRegistersChecks.push_back(0x3C110000);
	floatRegistersChecks.push_back(0x3C120000);
	floatRegistersChecks.push_back(0x3C130000);
	floatRegistersChecks.push_back(0x3C140000);
	floatRegistersChecks.push_back(0x3C150000);
	floatRegistersChecks.push_back(0x3C160000);
	floatRegistersChecks.push_back(0x3C170000);
	floatRegistersChecks.push_back(0x3C1E0000);
	floatRegistersChecks.push_back(0x3C020000);
	floatRegistersChecks.push_back(0x3C030000);
	floatRegistersChecks.push_back(0x3C040000);
	floatRegistersChecks.push_back(0x3C050000);
	floatRegistersChecks.push_back(0x3C060000);
	floatRegistersChecks.push_back(0x3C070000);

	for (unsigned long x = 0x0; x < romSize; x+= 4)
	{
		if ((CharArrayToLong(&ROM[x]) == 0x803B5000) && (CharArrayToLong(&ROM[x + 4]) == 0x803DA800))
		{
			WriteLongToBuffer(ROM, x, newFrameBufferLocation);
			WriteLongToBuffer(ROM, x + 4, newFrameBufferLocationTwo);

			x += 4;
		}
		else if ((CharArrayToLong(&ROM[x]) == 0x00000140) && (CharArrayToLong(&ROM[x + 4]) == 0x000000F0))
		{
			WriteLongToBuffer(ROM, x, newWidth);
			WriteLongToBuffer(ROM, x + 4, newHeight);

			x += 4;
		}
		else if (CharArrayToLong(&ROM[x]) == 0x2C810141)
		{
			WriteLongToBuffer(ROM, x, 0x2C810000 | (newWidth + 1));
		}
		else if (CharArrayToLong(&ROM[x]) == 0x2CA100F1)
		{
			WriteLongToBuffer(ROM, x, 0x2CA10000 | (newHeight + 1));
		}
		else if (CharArrayToLong(&ROM[x]) == 0x28A10141)
		{
			WriteLongToBuffer(ROM, x, 0x28A10000 | (newWidth + 1));
		}
		else if (CharArrayToLong(&ROM[x]) == 0x28C100F1)
		{
			WriteLongToBuffer(ROM, x, 0x28C10000 | (newHeight + 1));
		}
		else if (CharArrayToLong(&ROM[x]) == 0x28E10141)
		{
			WriteLongToBuffer(ROM, x, 0x28E10000 | (newWidth + 1));
		}
		else if (CharArrayToLong(&ROM[x]) == 0xFD10013F)
		{
			WriteLongToBuffer(ROM, x, 0xFD10027F);
		}
		else if (CharArrayToLong(&ROM[x]) == 0xFF10013F)
		{
			WriteLongToBuffer(ROM, x, 0xFF10027F);
		}
		else if (CharArrayToLong(&ROM[x]) == 0x005003C0)
		{
			WriteLongToBuffer(ROM, x, 0x00A00780);
		}
		else
		{
			for (int y = 0; y < registersChecks.size(); y++)
			{
				// If in filtered out range, crashes prof oak check	
				if (((x >= 0x9A6D40) || (x < 0x0098C560)) && (CharArrayToLong(&ROM[x]) == (registersChecks[y] | 0x140)))
				{
					WriteLongToBuffer(ROM, x, registersChecks[y] | newWidth);
				}
				else if (((x >= 0x9A6D40) || (x < 0x0098C560)) && (CharArrayToLong(&ROM[x]) == (registersChecks[y] | 0xF0)))
				{
					WriteLongToBuffer(ROM, x, registersChecks[y] | newHeight);
				}
				else if (CharArrayToLong(&ROM[x]) == (floatRegistersChecks[y] | 0x43A0))
				{
					float floatValue = newWidth;
					unsigned long intValue = (*reinterpret_cast<unsigned long*> (&floatValue));
					WriteLongToBuffer(ROM, x, (floatRegistersChecks[y] | ((intValue >> 16) & 0xFFFF)));
				}
				else if (CharArrayToLong(&ROM[x]) == (floatRegistersChecks[y] | 0x4370))
				{
					float floatValue = newHeight;
					unsigned long intValue = (*reinterpret_cast<unsigned long*> (&floatValue));
					WriteLongToBuffer(ROM, x, (floatRegistersChecks[y] | ((intValue >> 16) & 0xFFFF)));
				}
			}
		}
	}

	
	// Zoom in
	//803584E4
	WriteLongToBuffer(ROM, 0x004F88F4, 0x240D0000 | (0x0130 + 0x140));
	WriteLongToBuffer(ROM, 0x004F8904, 0x240E0000 | (0x00E8 + 0xF0));
	// Zoom out
	//803527C8:	240F00D8	ADDIU   $t7, $zero, 0x00D8	#
	WriteLongToBuffer(ROM, 0x004F2BD8, 0x240F0000 | (0x00D8 + 0xF0));
	//803527D0:	24190121	ADDIU   $t9, $zero, 0x0121	#
	WriteLongToBuffer(ROM, 0x004F2BE0, 0x24190000 | (0x0121 + 0x140));
	//803527E0:	24160109	ADDIU   $s6, $zero, 0x0109	#
	WriteLongToBuffer(ROM, 0x004F2BF0, 0x24160000 | (0x0109 + 0xF0));
	//803527E8:	241E0159	ADDIU   $s8, $zero, 0x0159	#
	WriteLongToBuffer(ROM, 0x004F2BF8, 0x241E0000 | (0x0159 + 0x140));

	//80000300 seems to be region flag, 1 NTSC, 2 PAL?

	//Disable overwrite of AA
	WriteLongToBuffer(ROM, 0x00001DFC, 0x2401FFFF);
	
	// Fix 0500/0A00 Shifting
	//80001634
	//80001670
	WriteLongToBuffer(ROM, 0x00002234, 0x240E0500);
	WriteLongToBuffer(ROM, 0x00002270, 0x240E0A00);
	//WriteLongToBuffer(ROM, 0x00002270, 0x001870C0);


	// Fix Y Scale back to 0x400
	//8000131C
	//WriteLongToBuffer(ROM, 0x00001F1C, 0x25F803C0);
	WriteLongToBuffer(ROM, 0x00001F10, 0x24040002);
	
	// V Video Reg for 0x500 offset
	//800013BC/800013CC
	WriteLongToBuffer(ROM, 0x00001FBC, 0x3C0E0023);
	WriteLongToBuffer(ROM, 0x00001FCC, 0x35CE01FD);

	// Hack out PAL to put out second one
	//800013E4
	WriteLongToBuffer(ROM, 0x00001FE4, 0x3C0F0025);
	WriteLongToBuffer(ROM, 0x00001FE8, 0x35EF01FF);
	WriteLongToBuffer(ROM, 0x00001FEC, 0x00000000);
	WriteLongToBuffer(ROM, 0x00001FF0, 0x00000000);
	WriteLongToBuffer(ROM, 0x00001FF4, 0x00000000);
	WriteLongToBuffer(ROM, 0x00001FF8, 0x00000000);
	WriteLongToBuffer(ROM, 0x00001FFC, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002000, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002004, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002008, 0x00000000);
	WriteLongToBuffer(ROM, 0x0000200C, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002010, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002014, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002018, 0x00000000);
	WriteLongToBuffer(ROM, 0x0000201C, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002020, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002024, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002028, 0x00000000);
	WriteLongToBuffer(ROM, 0x0000202C, 0x00000000);
	WriteLongToBuffer(ROM, 0x00002030, 0x00000000);

	// Don't load first field's
	//80001438
	WriteLongToBuffer(ROM, 0x00002038, 0x00000000);

	// Fix X to double
	//80001360
	WriteLongToBuffer(ROM, 0x00001F60, 0x24040002);
	WriteLongToBuffer(ROM, 0x00001F68, 0x24040002);
	WriteLongToBuffer(ROM, 0x00001F74, 0x24040002);

	// Oddly seemed to need 020D
	// NOP overwrite of 020C
	WriteLongToBuffer(ROM, 0x00002154, 0x00000000);
	
	// Write out 020D instead of 020C then
	//800013A0
	WriteLongToBuffer(ROM, 0x00001FA0, 0x240E020C);
	
	//80026208 Load sprite ASM Choice
	//80027FEC Load Sprite ASM One-time (better check)

	//80212120 - Cursor Position
	//802121a0 - Zoomed aimer
	//80212518 - Z
	//80212570 - R Not Zoomed
	//802125c8 - R Icon When Zoomed
	//80212620 - Camera When Zoomed
	//80212678 - C-Down
	//802126D0 - A Apple
	//80212728 - B Pokeball
	//80212808 - Camera icon
	//80212860 - Camera Number 2
	//802128B8 - Camera Number 1
	//80213050 - Pause Overlay
	//802130A8/C - PAUSE
	//80213100 - Pause Slide
	//802131B0/4 - Quit Course
	//80213208/C - Continue
	//80213310 - Retry

	//8011a9f0 N64 logo intro
	//80121060 Island in Intro
	//80121008 Nintendo Logo
	//80120FB0 HAL Logo
	//80121060 Jack and Beans
	//80121008 Pokemon Snap Logo
	//80121110 Car Intro
	//80121218 Pikachu Intro
	//801212C8 1995 Intro
	//80121320 Press Start Intro

	//Take picture function: 8009C9E8

	// Fix aimer center spot
	//803561C4
	WriteLongToBuffer(ROM, 0x004F65D4, 0x24C60000 | ((newHeight / 2) - 8));
	WriteLongToBuffer(ROM, 0x004F65DC, 0x24A50000 | ((newWidth / 2) - 8));

	// Fix zoomed aimer
	//8035681C
	WriteLongToBuffer(ROM, 0x004F6C2C, 0x24050000 | ((newWidth / 2) - 0x11));
	WriteLongToBuffer(ROM, 0x004F6C34, 0x24060000 | ((newHeight / 2) - 0x11));
	WriteLongToBuffer(ROM, 0x004F6C88, 0x24050000 | ((newWidth / 2) - 0x11));
	WriteLongToBuffer(ROM, 0x004F6C90, 0x24060000 | ((newHeight / 2) - 0x11));

	// Fix camera spot Width
	//8035E408
	//8035E430
	//8035E45C
	WriteLongToBuffer(ROM, 0x004FE818, 0x24050000 | (CharArrayToShort(&ROM[0x004FE818+2])) + 0x140);
	WriteLongToBuffer(ROM, 0x004FE840, 0x24050000 | (CharArrayToShort(&ROM[0x004FE840+2])) + 0x140);
	WriteLongToBuffer(ROM, 0x004FE86C, 0x24050000 | (CharArrayToShort(&ROM[0x004FE86C+2])) + 0x140);
	
	//1A0410
	// Pause Slide
	//803541CC:	24050168	ADDIU   $a1, $zero, 0x0168	#	
	WriteLongToBuffer(ROM, 0x004F45DC, 0x24050000 | (CharArrayToShort(&ROM[0x004F45DC+2])) + 0x140/2);
	//803541D0:	2406005E	ADDIU   $a2, $zero, 0x005E	#
	WriteLongToBuffer(ROM, 0x004F45E0, 0x24060000 | (CharArrayToShort(&ROM[0x004F45E0+2])) + 0xF0/2);
	//80354208:	24190099	ADDIU   $t9, $zero, 0x0099	#
	WriteLongToBuffer(ROM, 0x004F4618, 0x24190000 | 0x39);
	//80354210:	2B01009A	SLTI    $at, $t8, 0x009A	#+F slide check
	WriteLongToBuffer(ROM, 0x004F4620, 0x2B010000 | 0x3A);
	//80354218:	2406005E	ADDIU   $a2, $zero, 0x005E	#
	WriteLongToBuffer(ROM, 0x004F4628, 0x24060000 | (CharArrayToShort(&ROM[0x004F4628+2])) + 0xF0/2);
	//8035421C:	24080099	ADDIU   $t0, $zero, 0x0099	#
	WriteLongToBuffer(ROM, 0x004F462C, 0x24080000 | 0x39);
	//803543F8:	2406005E	ADDIU   $a2, $zero, 0x005E	#
	WriteLongToBuffer(ROM, 0x004F4808, 0x24060000 | (CharArrayToShort(&ROM[0x004F4808+2])) + 0xF0/2);
	//803544D4:	2406005E	ADDIU   $a2, $zero, 0x005E	#
	WriteLongToBuffer(ROM, 0x004F48E4, 0x24060000 | (CharArrayToShort(&ROM[0x004F48E4+2])) + 0xF0/2);
	
	// Pause Overlay (32.0 and 24.0)
	//80356BF4:	3C014200	LUI     $at, 0x4200	#
	//80356C00:	3C0141C0	LUI     $at, 0x41C0	#
	float floatValueW = newWidth / 10.0;
	unsigned long intValueW = (*reinterpret_cast<unsigned long*> (&floatValueW));
	WriteLongToBuffer(ROM, 0x004F7004, 0x3C010000 | ((intValueW >> 16) & 0xFFFF));
	float floatValueH = newHeight / 10.0;
	unsigned long intValueH = (*reinterpret_cast<unsigned long*> (&floatValueH));
	WriteLongToBuffer(ROM, 0x004F7010, 0x3C010000 | ((intValueH >> 16) & 0xFFFF));

	// Pause
	//80354244:	2405006F	ADDIU   $a1, $zero, 0x006F	#
	WriteLongToBuffer(ROM, 0x004F4654, 0x24050000 | (CharArrayToShort(&ROM[0x004F4654+2])) + 0x140/2);
	//80354248:	2406005E	ADDIU   $a2, $zero, 0x005E	#
	WriteLongToBuffer(ROM, 0x004F4658, 0x24060000 | (CharArrayToShort(&ROM[0x004F4658+2])) + 0xF0/2);

	//80356C84:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F7094, 0x24050000 | (CharArrayToShort(&ROM[0x004F7094+2])) + 0x140/2);
	//80356C88:	2406009C	ADDIU   $a2, $zero, 0x009C	#
	WriteLongToBuffer(ROM, 0x004F7098, 0x24060000 | (CharArrayToShort(&ROM[0x004F7098+2])) + 0xF0/2);
	//80356CC0:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F70D0, 0x24050000 | (CharArrayToShort(&ROM[0x004F70D0+2])) + 0x140/2);
	//80356CC4:	2406009C	ADDIU   $a2, $zero, 0x009C	#
	WriteLongToBuffer(ROM, 0x004F70D4, 0x24060000 | (CharArrayToShort(&ROM[0x004F70D4+2])) + 0xF0/2);
	//80356CFC:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F710C, 0x24050000 | (CharArrayToShort(&ROM[0x004F710C+2])) + 0x140/2);
	//80356D00:	24060085	ADDIU   $a2, $zero, 0x0085	#
	WriteLongToBuffer(ROM, 0x004F7110, 0x24060000 | (CharArrayToShort(&ROM[0x004F7110+2])) + 0xF0/2);
	//80356D38:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F7148, 0x24050000 | (CharArrayToShort(&ROM[0x004F7148+2])) + 0x140/2);
	//80356D3C:	24060085	ADDIU   $a2, $zero, 0x0085	#
	WriteLongToBuffer(ROM, 0x004F714C, 0x24060000 | (CharArrayToShort(&ROM[0x004F714C+2])) + 0xF0/2);
	//80356D74:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F7184, 0x24050000 | (CharArrayToShort(&ROM[0x004F7184+2])) + 0x140/2);
	//80356D78:	240600B3	ADDIU   $a2, $zero, 0x00B3	#
	WriteLongToBuffer(ROM, 0x004F7188, 0x24060000 | (CharArrayToShort(&ROM[0x004F7188+2])) + 0xF0/2);
	//80356DB0:	24050074	ADDIU   $a1, $zero, 0x0074	#
	WriteLongToBuffer(ROM, 0x004F71C0, 0x24050000 | (CharArrayToShort(&ROM[0x004F71C0+2])) + 0x140/2);
	//80356DB4:	240600B3	ADDIU   $a2, $zero, 0x00B3	#
	WriteLongToBuffer(ROM, 0x004F71C4, 0x24060000 | (CharArrayToShort(&ROM[0x004F71C4+2])) + 0xF0/2);





	// Rest seem in ROM
	for (unsigned long x = 0x0052853C; x < 0x00528608; x += 0xC)
	{
		unsigned long valueW = CharArrayToLong(&ROM[x]);
		unsigned long valueH = CharArrayToLong(&ROM[x + 4]);
		if (valueW > 0x20)
		{
			unsigned long newValue = valueW + 0x140;
			WriteLongToBuffer(ROM, x, newValue);
		}
		if (valueH > 0x20)
		{
			unsigned long newValue = valueH + 0xF0;
			WriteLongToBuffer(ROM, x + 4, newValue);
		}
	}

	for (unsigned long x = 0x00528654; x < 0x00528714; x += 0x18)
	{
		unsigned long valueW = CharArrayToLong(&ROM[x]);
		unsigned long valueH = CharArrayToLong(&ROM[x + 4]);
		if (valueW > 0x20)
		{
			unsigned long newValue = valueW + 0x140;
			WriteLongToBuffer(ROM, x, newValue);
		}
		if (valueH > 0x20)
		{
			unsigned long newValue = valueH + 0xF0;
			WriteLongToBuffer(ROM, x + 4, newValue);
		}
	}
	


	//80356294
	WriteLongToBuffer(ROM, 0x004F66A4, 0x24050000 | ((newWidth / 2) - 8));
	WriteLongToBuffer(ROM, 0x004F66AC, 0x24060000 | ((newHeight / 2) - 8));

	// Allow move Neach level
	WriteShortToBuffer(ROM, 0x004F7244, 0x1000);

	// All levels
	//800C2210 Word # Levels Beaten, 06 is max
	//800C029C 8DC20050 24020006 ROM 0005D13C
	WriteLongToBuffer(ROM, 0x0005D13C, 0x24020006);
	//800C0C3C 8CAE0000 240E0006 ROM 0005DADC
	WriteLongToBuffer(ROM, 0x0005DADC, 0x240E0006);

	//All Items
	//803565A8 Unlock 20 Dash Engine ROM 004F69B8
	WriteLongToBuffer(ROM, 0x004F69B8, 0x00000000);

	//8035D314 Unlock 20 Dash Engine Icon ROM 004FD724
	WriteLongToBuffer(ROM, 0x004FD724, 0x00000000);

	//8035D1D8 Check 01 ROM 004FD5E8
	WriteLongToBuffer(ROM, 0x004FD5E8, 0x00000000);
	//8035D1EC Check 02 ROM 004FD5FC
	WriteLongToBuffer(ROM, 0x004FD5FC, 0x00000000);
	//8035D200 Check 04 ROM 004FD610
	WriteLongToBuffer(ROM, 0x004FD610, 0x00000000);

	unsigned long newDepthbuffer = 0x80700000;
	//802C45E0
	//lui $at, 8060
	//ori $at, $at, 0
	//JAL 0x80007BC4
	//SW $at, C(A0)
	//lui $V1, 0x800C
	//addiu $A0, V1, 0xE248
	//addiu $V0, V1, 0xE228
	//addiu $V1, V1, 0xE248

	// Fix pre-intro and intro buffer to spot, in function called before
	//800054CC Maybe LUI $at, 8060? 3C018060 (ROM 000060CC)
	WriteLongToBuffer(ROM, 0x000060CC, 0x3C010000 | ((newDepthbuffer >> 16) & 0xFFFF));

	// Pre-intro depth buffer
	//800E1B78 SW $at, C(A0) AC81000C (ROM 00AA0928)
	WriteLongToBuffer(ROM, 0x00AA0928, 0xAC81000C);

	// Intro depth buffer
	//800E4674 SW $at, C(A0) AC81000C (ROM 00A0BC04)
	WriteLongToBuffer(ROM, 0x00A0BC04, 0xAC81000C);

	std::vector<unsigned long> depthBufferSpots;
	depthBufferSpots.push_back(0x0055C650);
	depthBufferSpots.push_back(0x005DFB24);
	depthBufferSpots.push_back(0x006406FC);
	depthBufferSpots.push_back(0x006C0EB8);
	depthBufferSpots.push_back(0x00727850);
	depthBufferSpots.push_back(0x0079F99C);
	depthBufferSpots.push_back(0x008264E0);

	for (int x = 0; x < depthBufferSpots.size(); x++)
	{
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x00, (0x3C010000 | ((newDepthbuffer >> 16) & 0xFFFF)));
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x04, (0x34210000 | ((newDepthbuffer) & 0xFFFF)));
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x08, 0x0C001EF1);
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x0C, 0xAC81000C);
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x10, 0x3C03800C);
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x14, 0x2464E248);
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x18, 0x2462E228);
		WriteLongToBuffer(ROM, depthBufferSpots[x] + 0x1C, 0x2463E248);
	}


	//8035814C:	3C0F0050	LUI     $t7, 0x0050	#
	//80358150:	35EF03C0	ORI     $t7, $t7, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00B09944, 0x3C0F00A0);
	WriteLongToBuffer(ROM, 0x00B09948, 0x35EF0780);

	//803582B8:	3C0F0050	LUI     $t7, 0x0050	#
	//803582BC:	35EF03C0	ORI     $t7, $t7, 0x03C0	#(*CONSTANT) 005003C0
	WriteLongToBuffer(ROM, 0x00B09944, 0x3C0F00A0);
	WriteLongToBuffer(ROM, 0x00B09948, 0x35EF0780);

	//80357F24:	3C0EF64F	LUI     $t6, 0xF64F	#
	//80357F34:	35CEC3BC	ORI     $t6, $t6, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x004F8334, 0x3C0EF69F);
	WriteLongToBuffer(ROM, 0x004F8344, 0x35CEC77C);

	//8035818C:	3C18F64F	LUI     $t8, 0xF64F	#
	//80358190:	3718C3BC	ORI     $t8, $t8, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteLongToBuffer(ROM, 0x004F859C, 0x3C18F69F);
	WriteLongToBuffer(ROM, 0x004F85A0, 0x3718C77C);

	//80357F00:	3C0DF64F	LUI     $t5, 0xF64F	#
	//80357F08:	35ADC000	ORI     $t5, $t5, 0xC000	#(*CONSTANT) F64FC000
	WriteLongToBuffer(ROM, 0x004F8310, 0x3C0DF69F);
	WriteLongToBuffer(ROM, 0x004F8318, 0x35ADC000);

	FILE* outFile = fopen("C:\\temp\\snaphires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\snaphires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;	
}
void CMakeGameHiResDlg::OnBnClickedButtonbk18()
{
	// Not working...allocation based issue somehow, like stuff wrong spots

	int romSize = 0x1000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Golden Nugget 64 (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x01, 0x30, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x01, 0x33, 0x56, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1NoAA;
	for (int x = 0; x < 0x4C; x++)
	{
		ROM[0x000B0710 + x + 4] = rawData[x];
		ROM[0x000B0760 + x + 4] = rawData[x];
		ROM[0x000B0BD0 + x + 4] = rawData[x];
		ROM[0x000B0760 + x + 4] = rawData[x];
	}

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	
	// Seems like allocation issue

	WriteShortToBuffer(ROM, 0x00001D10 + 2, newWidth);
	WriteShortToBuffer(ROM, 0x00001D14 + 2, newHeight);
	WriteShortToBuffer(ROM, 0x000755BC + 2, newWidth);
	WriteShortToBuffer(ROM, 0x000755C0 + 2, newHeight);

	// Half, not all confirmed
	//WriteShortToBuffer(ROM, 0x00007DB8 + 2, newWidth / 2);
	//WriteShortToBuffer(ROM, 0x0005A494 + 2, newWidth / 2);
	//WriteShortToBuffer(ROM, 0x0005CD84 + 2, newWidth / 2);

	//Override what it thinks allocated for frame buffers
	WriteLongToBuffer(ROM, 0x000758F0, 0x3C040007);
	WriteLongToBuffer(ROM, 0x000758F4, 0x348408C0);

	// Unconfirmed
	/*WriteShortToBuffer(ROM, 0x0005A430 + 2, newWidth / 2);
	WriteShortToBuffer(ROM, 0x0005CD34 + 2, newWidth / 2);
	
	// Compressed data of 014000F0? Didn't seem to help changing anything...
	WriteLongToBuffer(ROM, 0x002BEFF1, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x002C9FA2, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x002C5F71, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003113DA, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x00389DC0, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x00399A67, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003AA95F, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003BBB9A, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003CBE40, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003DD3A3, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x003E2511, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x0040539F, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x0040E602, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x005170FB, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x0051ABD5, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x0051DF10, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x00520DD3, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x00524C27, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x005281A7, ((newWidth << 16) | newHeight));
	WriteLongToBuffer(ROM, 0x0052D330, ((newWidth << 16) | newHeight));*/

	/*
	80074D0C:
	NOP

	80074D2C:
	LUI $AT, 8040
	SW $AT, 0x0000(T9)
	LUI $AT, 8049
	ORI $AT, $AT, 6000
	SW $AT, 0x0004(T9)
	LUI $AT, 8052
	ORI $AT, $AT, C000
	SW $AT, 0x0008(T9)

	LUI $AT, 0007
	ORI $AT, $AT, 0800
	ADDU $V1, $V1, $AT
	NOP
	NOP
	NOP
	NOP
	NOP
	*/
	// Adjust output buffer spot
	WriteLongToBuffer(ROM, 0x0007590C, 0x00000000);

	WriteLongToBuffer(ROM, 0x0007592C, 0x3C018040);
	WriteLongToBuffer(ROM, 0x00075930, 0xAF210000);
	WriteLongToBuffer(ROM, 0x00075934, 0x3C018049);
	WriteLongToBuffer(ROM, 0x00075938, 0x34216000);
	WriteLongToBuffer(ROM, 0x0007593C, 0xAF210004);
	WriteLongToBuffer(ROM, 0x00075940, 0x3C018052);
	WriteLongToBuffer(ROM, 0x00075944, 0x3421C000);
	WriteLongToBuffer(ROM, 0x00075948, 0xAF210008);
	WriteLongToBuffer(ROM, 0x0007594C, 0x3C010007);
	WriteLongToBuffer(ROM, 0x00075950, 0x34210800);
	WriteLongToBuffer(ROM, 0x00075954, 0x00611821);
	WriteLongToBuffer(ROM, 0x00075958, 0x00000000);
	WriteLongToBuffer(ROM, 0x0007595C, 0x00000000);
	WriteLongToBuffer(ROM, 0x00075960, 0x00000000);
	WriteLongToBuffer(ROM, 0x00075964, 0x00000000);
	WriteLongToBuffer(ROM, 0x00075968, 0x00000000);


	
	
	FILE* outFile = fopen("C:\\temp\\goldennuggethires.rom", "wb");
	fwrite(ROM, 1, romSize, outFile);
	fclose(outFile);

	CString tempStr;
	tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\goldennuggethires.rom");
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;	
}

CString SetPath()
{
	//To get Directory in MFC
	CString directory;
	char tempFolder[8000];
	::GetCurrentDirectory(8000, tempFolder);
	directory.Format("%s\\", tempFolder);
	return directory;
}

unsigned long calculateRNXUncompressedCRC(unsigned char* outputDecompressed, int fileSize)
{
	unsigned long value = 0;
	for (int x = 0; x < fileSize; x++)
		value += outputDecompressed[x];
	return value;
}

bool DecompressRNCFileInPlace(RncDecoder* rnc, unsigned char* ROM, unsigned char* outputDecompressed, int offset, int& fileSize, int& expectedCompressed)
{
	int expectedDecompressed;

	int failure = rnc->getLengths(&ROM[offset], expectedDecompressed, expectedCompressed);
	if (failure)
	{
		//MessageBox("RNC header failure");
		return false;
	}

	int compressedSize = -1;
	
	fileSize = rnc->unpackM1(&ROM[offset], outputDecompressed, 0x0000, compressedSize);

	if (fileSize == 0)
	{
		//MessageBox("RNC failure");
		return false;
	}

	expectedCompressed++;
	return true;
}

bool DecompressRNCFile(RncDecoder* rnc, unsigned char* ROM, unsigned char*& outputDecompressed, int offset, int& fileSize)
{
	int expectedCompressed;
	int expectedDecompressed;

	int failure = rnc->getLengths(&ROM[offset], expectedDecompressed, expectedCompressed);
	if (failure)
	{
		//MessageBox("RNC header failure");
		return false;
	}

	outputDecompressed = new unsigned char[0x1000000];
	int compressedSize = -1;
	
	fileSize = rnc->unpackM1(&ROM[offset], outputDecompressed, 0x0000, compressedSize);

	if (fileSize == 0)
	{
		//MessageBox("RNC failure");
		return false;
	}

	expectedCompressed++;
	return true;
}

int CompressRNCFile(RncDecoder* rnc, unsigned char* ROM, unsigned char* outputDecompressed, int fileSize, int offset, int maxSize, int level = 1)
{
	unsigned long crc = calculateRNXUncompressedCRC(outputDecompressed, fileSize);
	CString currentDir = SetPath();
	CString tempFileLocation = currentDir + "temp123rnc.bin";
	CString outFileLocation = currentDir + "temp123rnc.rnx";
	FILE* outRNC = fopen(tempFileLocation, "wb");
	if (!outRNC)
	{
		//MessageBox("RNC temp file failure");
		return 0;
	}
	fwrite(outputDecompressed, 1, fileSize, outRNC);
	fclose(outRNC);

	if (!rnc->CompressRNCFile(currentDir, tempFileLocation, outFileLocation, true, level))
	{
		//MessageBox("RNC compression file failure");
		return 0;
	}

	int sizeNewCompressed = GetSizeFile(outFileLocation);
	if (sizeNewCompressed > maxSize)
	{
		//MessageBox("RNX too large");
		return 0;
	}

	FILE* inTemp = fopen(outFileLocation, "rb");
	if (!inTemp)
	{
		//MessageBox("RNX output not found");	
		return 0;
	}
	fread(&ROM[offset], 1, sizeNewCompressed, inTemp);
	fclose(inTemp);

	::DeleteFile(tempFileLocation);
	::DeleteFile(outFileLocation);

	return sizeNewCompressed;
}

unsigned long TestCRC(unsigned char* ROM, int offset)
{
	unsigned char* outputDecompressed = NULL;
	int fileSize = -1;

	RncDecoder rnc;
	if (!DecompressRNCFile(&rnc, ROM, outputDecompressed, offset, fileSize))
	{
		delete [] outputDecompressed;
		return -1;
	}

	FILE* outTest = fopen("C:\\temp\\a.bin", "wb");
	fwrite(outputDecompressed, 1, fileSize, outTest);
	fclose(outTest);

	unsigned char* compressedBufferFirst = new unsigned char[0x100000];
	int compressedSize = CompressRNCFile(&rnc, compressedBufferFirst, outputDecompressed, fileSize, 0, 999999);
	if (compressedSize == 0)
	{
		return 0;
	}
	FILE* outCompressed = fopen("C:\\temp\\aa.bin", "wb");
	fwrite(compressedBufferFirst, 1, compressedSize, outCompressed);
	fflush(outCompressed);
	fclose(outCompressed);
	delete [] compressedBufferFirst;

	unsigned long value = calculateRNXUncompressedCRC(outputDecompressed, fileSize);
	delete [] outputDecompressed;
	return value;
}

void CMakeGameHiResDlg::OnBnClickedButtonbk19()
{
	// Not working console...

	int romSize = 0x800000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\Forsaken 64 (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	unsigned long testCRC = TestCRC(ROM, 0x006FE078);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	for (int y = 0x00029A10; y < 0x0002A730; y += 0x50)
	{
		for (int x = 0; x < 0x4C; x++)
		{
			ROM[y + x + 4] = rawData[x];
		}
	}
	for (int y = 0x0002A760; y < 0x0002A850; y += 0x50)
	{
		for (int x = 0; x < 0x4C; x++)
		{
			ROM[y + x + 4] = rawData[x];
		}
	}

	int startCompressedData = 0x006C49D8;
	unsigned long firstCompressedASM = startCompressedData + CharArrayToLong(&ROM[0x006C49D8]);
	unsigned long firstCompressedCount = CharArrayToLong(&ROM[0x006C49DC]);
	unsigned long firstCompressedChecksum = CharArrayToLong(&ROM[0x006C49E0]);

	unsigned long secondCompressedASM = startCompressedData + CharArrayToLong(&ROM[0x006C49E4]);
	unsigned long secondCompressedCount = CharArrayToLong(&ROM[0x006C49E8]);
	unsigned long secondCompressedChecksum = CharArrayToLong(&ROM[0x006C49EC]);

	unsigned char* outputBufferFirst = new unsigned char[firstCompressedCount];
	for (int x = 0; x < firstCompressedCount; x++)
		outputBufferFirst[x] = 0;

	int outputSpotFirst = 0;
	int currentCompressedSpotFirst = firstCompressedASM;
	RncDecoder rnc;
	while (outputSpotFirst < firstCompressedCount)
	{
		if (CharArrayToLong(&ROM[currentCompressedSpotFirst]) == 0x46494C4C) // FILL
		{
			unsigned short fillAmount = CharArrayToShort(&ROM[currentCompressedSpotFirst + 4]);
			outputSpotFirst += fillAmount;
			currentCompressedSpotFirst += 8;
		}
		else if (CharArrayToLong(&ROM[currentCompressedSpotFirst]) == 0x454E4421) // END
		{
			break;
		}
		else
		{
			int subFileSize = -1;
			int compressedSize = -1;
			if (!DecompressRNCFileInPlace(&rnc, ROM, &outputBufferFirst[outputSpotFirst], currentCompressedSpotFirst, subFileSize, compressedSize))
			{
				MessageBox("BAD ERROR overall decompression 1");
				return;
			}
			outputSpotFirst += subFileSize;
			currentCompressedSpotFirst += compressedSize + 0x10;
			currentCompressedSpotFirst += (8 - ((currentCompressedSpotFirst - firstCompressedASM) % 8));
		}
	}

	unsigned long checksumfirst = calculateRNXUncompressedCRC(outputBufferFirst, outputSpotFirst);
	FILE* outFirst = fopen("C:\\temp\\firstdecompressed.bin", "wb");
	if (outFirst)
	{
		fwrite(outputBufferFirst, 1, outputSpotFirst, outFirst);
		fflush(outFirst);
		fclose(outFirst);
	}

	unsigned char* outputBufferSecond = new unsigned char[secondCompressedCount];
	for (int x = 0; x < secondCompressedCount; x++)
		outputBufferSecond[x] = 0;

	int outputSpotSecond = 0;
	int currentCompressedSpotSecond = secondCompressedASM;

	while (outputSpotSecond < secondCompressedCount)
	{
		if (CharArrayToLong(&ROM[currentCompressedSpotSecond]) == 0x46494C4C) // FILL
		{
			unsigned short fillAmount = CharArrayToShort(&ROM[currentCompressedSpotSecond + 4]);
			outputSpotSecond += fillAmount;
			currentCompressedSpotSecond += 8;
		}
		else if (CharArrayToLong(&ROM[currentCompressedSpotSecond]) == 0x454E4421) // END
		{
			break;
		}
		else
		{
			int subFileSize = -1;
			int compressedSize = -1;
			if (!DecompressRNCFileInPlace(&rnc, ROM, &outputBufferSecond[outputSpotSecond], currentCompressedSpotSecond, subFileSize, compressedSize))
			{
				MessageBox("BAD ERROR overall decompression 2");
				return;
			}
			outputSpotSecond += subFileSize;
			currentCompressedSpotSecond += compressedSize + 0x10;
			currentCompressedSpotSecond += (8 - ((currentCompressedSpotSecond - secondCompressedASM) % 8));
		}
	}

	unsigned long checksumsecond = calculateRNXUncompressedCRC(outputBufferSecond, outputSpotSecond);
	FILE* outSecond = fopen("C:\\temp\\seconddecompressed.bin", "wb");
	if (outSecond)
	{
		fwrite(outputBufferSecond, 1, outputSpotSecond, outSecond);
		fflush(outSecond);
		fclose(outSecond);
	}


    // RNX Checksum here of whole section
	//80009D30:	10000006	BEQZ    $zero, 0x80009D4C	#
	//WriteLongToBuffer(ROM, 0x0000A930, 0x10000006);

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;

	unsigned long endRAM = 0x80800000;
	unsigned long first = endRAM - (newSize * 3);
	unsigned long second = endRAM - (newSize * 2);
	unsigned long third = endRAM - (newSize * 1);

	unsigned long newDepthBuffer = 0x8048EE7F;
 
	unsigned long newFF10013F = 0xFF10027F;
	unsigned long newF64FC3BC = 0xF69F8778;
	// ED Command
	unsigned long new005003C0 = 0x00A00780;
	unsigned long new004FC3BC = 0x009F8778;
	unsigned long newE44FC3BC = 0xE49F8778; // Tex Rect
	
	if ((newWidth <= 0x140) && (newHeight <= 0xF0))
	{
		newFF10013F = 0xFF10013F;
		newF64FC3BC = 0xF64FC3BC;
		new005003C0 = 0x005003C0;
		new004FC3BC = 0x004FC3BC;
		newE44FC3BC = 0xE44FC3BC;
	}

	float newWidthMinus1 = newWidth - 1;
	float newHeightMinus1 = newHeight - 1;
	unsigned long newWidthMinus1Hex = *(unsigned long *)&(newWidthMinus1);
	unsigned long newHeightMinus1Hex = *(unsigned long *)&(newHeightMinus1);

	// Fix when hit red cover whole screen

	//80109A7C:	3C06439F	LUI     $a2, 0x439F	#
	//80109A80:	34C68000	ORI     $a2, $a2, 0x8000	#(*CONSTANT) 439F8000
	//80109A84:	3C07436F	LUI     $a3, 0x436F	#

	WriteOriAddress(outputBufferFirst, newWidthMinus1Hex, 0x0004A3F0, 0x0004A3F4);
	WriteShortToBuffer(outputBufferFirst, 0x0004A3F8 + 2, ((newHeightMinus1Hex >> 16) & 0xFFFF)); // truncates by 1.0...

	//801026A0:	3C06439F	LUI     $a2, 0x439F	#
	//801026A4:	34C68000	ORI     $a2, $a2, 0x8000	#(*CONSTANT) 439F8000
	//801026A8:	3C07436F	LUI     $a3, 0x436F	#

	WriteOriAddress(outputBufferFirst, newWidthMinus1Hex, 0x000517CC, 0x000517D0);
	WriteShortToBuffer(outputBufferFirst, 0x000517D4 + 2, ((newHeightMinus1Hex >> 16) & 0xFFFF)); // truncates by 1.0...

	// Intro fade
	//80119CF4:	3C11E49F	LUI     $s1, 0xE49F	#
	//80119CFC:	36318778	ORI     $s1, $s1, 0x8778	#(*CONSTANT) E49F8778
	WriteOriAddress(outputBufferFirst, newE44FC3BC, 0x00061A44, 0x00061A4C);

	// Disable AA bit removed
	//80019464:	2403FCFF	ADDIU   $v1, $zero, 0xFCFF	#
	WriteLongToBuffer(ROM, 0x0001A064, 0x2403FFFF);


	//80001BD8:	3C028009	LUI     $v0, 0x8009	#
	//80001BDC:	2442EE7F	ADDIU   $v0, $v0, 0xEE7F	#(*CONSTANT) 8008EE7F
	WriteAddiuAddress(ROM, newDepthBuffer, 0x000027D8, 0x000027DC);

	// Not sure why checking if & 0xFFF00000 == 0x80000000
	//800029A0:	10620007	BEQ     $v1, $v0, 0x800029C0	#
	WriteLongToBuffer(ROM, 0x000035A0, 0x10000007);


	//8038F800
	// Not sure if this one
	WriteLongToBuffer(ROM, 0x00022C78, first);
	WriteLongToBuffer(ROM, 0x000242B0, first);

	//80001D40:	3C070001	LUI     $a3, 0x0001	#
	//80001D44:	34E72BFF	ORI     $a3, $a3, 0x2BFF	#(*CONSTANT) 00012BFF
	WriteOriAddress(ROM, ((newSize / 2) - 1), 0x0000A280, 0x0000A284);

	//80009868:	3C050002	LUI     $a1, 0x0002	#
	//80009870:	34A55800	ORI     $a1, $a1, 0x5800	#(*CONSTANT) 00025800
	WriteOriAddress(ROM, newSize, 0x0000A468, 0x0000A470);

	//80001D24:	3C028039	LUI     $v0, 0x8039	#
	//80001D28:	2446F800	ADDIU   $a2, $v0, 0xF800	#(*CONSTANT) 8038F800
	WriteAddiuAddress(ROM, first, 0x00002924, 0x00002928);

	//80001D2C:	3C02803B	LUI     $v0, 0x803B	#
	//80001D30:	24455000	ADDIU   $a1, $v0, 0x5000	#(*CONSTANT) 803B5000
	WriteAddiuAddress(ROM, second, 0x0000292C, 0x00002930);

	//80001D34:	3C02803E	LUI     $v0, 0x803E	#
	//80001D38:	2444A800	ADDIU   $a0, $v0, 0xA800	#(*CONSTANT) 803DA800
	WriteAddiuAddress(ROM, third, 0x00002934, 0x00002938);


	//80008510:	3C028039	LUI     $v0, 0x8039	#
	//80008514:	2442F828	ADDIU   $v0, $v0, 0xF828	#(*CONSTANT) 8038F828
	WriteAddiuAddress(ROM, first + 0x28, 0x00009110, 0x00009114);

	//8000851C:	3C02803B	LUI     $v0, 0x803B	#
	//80008520:	24425028	ADDIU   $v0, $v0, 0x5028	#(*CONSTANT) 803B5028
	WriteAddiuAddress(ROM, second + 0x28, 0x0000911C, 0x00009120);

	//80001D40:	3C070001	LUI     $a3, 0x0001	#
	//80001D44:	34E72BFF	ORI     $a3, $a3, 0x2BFF	#(*CONSTANT) 00012BFF
	WriteOriAddress(ROM, ((newSize / 2) - 1), 0x00002940, 0x00002944);

	//80001D6C:	3C048039	LUI     $a0, 0x8039	#
	//80001D74:	2484F800	ADDIU   $a0, $a0, 0xF800	#(*CONSTANT) 8038F800
	WriteAddiuAddress(ROM, first, 0x0000296C, 0x00002974);

	//80008BA0:	3C028039	LUI     $v0, 0x8039	#
	//80008BA4:	2442F800	ADDIU   $v0, $v0, 0xF800	#(*CONSTANT) 8038F800
	WriteAddiuAddress(ROM, first, 0x000097A0, 0x000097A4);

	//800084E8:	2C8200F0	SLTIU   $v0, $a0, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000090E8 + 2, newHeight);
	//800084F4:	2484FF10	ADDIU   $a0, $a0, 0xFF10	#
	WriteShortToBuffer(ROM, 0x000090F4 + 2, (0x10000 - newHeight));
	//800084F8:	2C8200F0	SLTIU   $v0, $a0, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000090F8 + 2, newHeight);
	//80008500:	2484FF10	ADDIU   $a0, $a0, 0xFF10	#
	WriteShortToBuffer(ROM, 0x00009100 + 2, (0x10000 - newHeight));

	
	// File 7084CC
	// Offset 00002344
	//800CE5F4:	24020140	ADDIU   $v0, $zero, 0x0140	#
	// Wrong this is for FD command for intro menus
	//WriteShortToBuffer(outputDecompressed7084CC, 0x00002344 + 2, newWidth);
	//WriteShortToBuffer(outputBufferSecond, 0x00016344 + 2, newWidth);

	// File 7084CC
	// Offset 0000234C
	//800CE5FC:	240200F0	ADDIU   $v0, $zero, 0x00F0	#
	// Wrong this is for FD command for intro menus
	//WriteShortToBuffer(outputDecompressed7084CC, 0x0000234C + 2, newHeight);
	//WriteShortToBuffer(outputBufferSecond, 0x0001634C + 2, newHeight);


	// To Fit - Crashes if change anything check for security
	//WriteLongToBuffer(outputDecompressed703C24, 0x60, 0x45584954);
	//WriteLongToBuffer(outputDecompressed703C24, 0x68, 0x45584954);
	

	//800C4894:	3C048039	LUI     $a0, 0x8039	#
	//800C4898:	2484F800	ADDIU   $a0, $a0, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed703C24, first, 0x000005E4, 0x000005E8);
	WriteAddiuAddress(outputBufferSecond, first, 0x0000C5E4, 0x0000C5E8);

	//800C48A0:	3C060002	LUI     $a2, 0x0002	#
	//800C48A8:	34C65800	ORI     $a2, $a2, 0x5800	#(*CONSTANT) 00025800
	//WriteOriAddress(outputDecompressed703C24, newSize, 0x000005F0, 0x000005F8);
	WriteAddiuAddress(outputBufferSecond, newSize, 0x0000C5F0, 0x0000C5F8);


	//800C48AC:	3C04803B	LUI     $a0, 0x803B	#
	//800C48B0:	24845000	ADDIU   $a0, $a0, 0x5000	#(*CONSTANT) 803B5000
	//WriteAddiuAddress(outputDecompressed703C24, second, 0x000005FC, 0x00000600);
	WriteAddiuAddress(outputBufferSecond, second, 0x0000C5FC, 0x0000C600);

	//800C48B8:	3C060002	LUI     $a2, 0x0002	#
	//800C48C0:	34C65800	ORI     $a2, $a2, 0x5800	#(*CONSTANT) 00025800
	//WriteOriAddress(outputDecompressed703C24, newSize, 0x00000608, 0x00000610);
	WriteOriAddress(outputBufferSecond, newSize, 0x0000C608, 0x0000C610);

	//800C48C4:	3C04803E	LUI     $a0, 0x803E	#
	//800C48C8:	2484A800	ADDIU   $a0, $a0, 0xA800	#(*CONSTANT) 803DA800
	//WriteAddiuAddress(outputDecompressed703C24, third, 0x00000614, 0x00000618);
	WriteAddiuAddress(outputBufferSecond, third, 0x0000C614, 0x0000C618);

	//800C48D0:	3C060002	LUI     $a2, 0x0002	#
	//800C48D8:	34C65800	ORI     $a2, $a2, 0x5800	#(*CONSTANT) 00025800
	//WriteOriAddress(outputDecompressed703C24, newSize, 0x00000620, 0x00000628);
	WriteOriAddress(outputBufferSecond, newSize, 0x0000C620, 0x0000C628);

	//800C7A8C:	3C0F0050	LUI     $t7, 0x0050	#
	//800C7A90:	35EF03C0	ORI     $t7, $t7, 0x03C0	#(*CONSTANT) 005003C0
	//WriteOriAddress(outputDecompressed703C24, new005003C0, 0x000037DC, 0x000037E0);
	WriteOriAddress(outputBufferSecond, new005003C0, 0x0000F7DC, 0x0000F7E0);

	//800C6DA8:	00031AC0	SLL     $v1, $v1, 0x0B	# was 4B000 offset from 8038F800
	//WriteLongToBuffer(outputDecompressed6CA208, 0x00002AF8, 0x00031B40);
	WriteLongToBuffer(outputBufferFirst, 0x0000EAF8, 0x00031B40);

	//800C6DAC:	3C048039	LUI     $a0, 0x8039	#
	//800C6DB0:	2484F800	ADDIU   $a0, $a0, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed6CA208, first, 0x00002AFC, 0x00002B00);
	WriteAddiuAddress(outputBufferFirst, first, 0x0000EAFC, 0x0000EB00);

	//FF10013F
	//800C70D0:	3C0BFF10	LUI     $t3, 0xFF10	#
	//800C70D4:	356B013F	ORI     $t3, $t3, 0x013F	#(*CONSTANT) FF10013F
	//WriteOriAddress(outputDecompressed6CA208, newFF10013F, 0x00002E20, 0x00002E24);
	WriteOriAddress(outputBufferFirst, newFF10013F, 0x0000EE20, 0x0000EE24);

	//800C713C:	000422C0	SLL     $a0, $a0, 0x0B	#
	WriteLongToBuffer(outputBufferFirst, 0x0000EE8C, 0x00042340);

	//800C7140:	3C028039	LUI     $v0, 0x8039	#
	//800C7144:	2442F800	ADDIU   $v0, $v0, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed6CA208, first, 0x00002E90, 0x00002E94);
	WriteAddiuAddress(outputBufferFirst, first, 0x0000EE90, 0x0000EE94);

	//800C73E4: 000212C0	SLL     $v0, $v0, 0x0B	#
	WriteLongToBuffer(outputBufferFirst, 0x0000F134, 0x00021340);

	//800C73E8:	3C038039	LUI     $v1, 0x8039	#
	//800C73EC:	2463F800	ADDIU   $v1, $v1, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed6CA208, first, 0x00003138, 0x0000313C);
	WriteAddiuAddress(outputBufferFirst, first, 0x0000F138, 0x0000F13C);

	//WriteShortToBuffer(outputDecompressed6CA208, 0x000029BC + 2, newWidth - 1);
	WriteShortToBuffer(outputBufferFirst, 0x0000E9BC + 2, newWidth - 1);
	//WriteShortToBuffer(outputDecompressed6CA208, 0x000029C4 + 2, newHeight - 1);
	WriteShortToBuffer(outputBufferFirst, 0x0000E9C4 + 2, newHeight - 1);


	//800D1590:	000212C0	SLL     $v0, $v0, 0x0B	#
	WriteLongToBuffer(outputBufferSecond, 0x000192E0, 0x00021340);

	//800D1594:	3C038039	LUI     $v1, 0x8039	#
	//800D1598:	2463F800	ADDIU   $v1, $v1, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed70A4EC, first, 0x000012E4, 0x000012E8);
	WriteAddiuAddress(outputBufferSecond, first, 0x000192E4, 0x000192E8);


	//800D1638:	3C028039	LUI     $v0, 0x8039	#
	//800D163C:	2442F800	ADDIU   $v0, $v0, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed70A4EC, first, 0x00001388, 0x0000138C);
	WriteAddiuAddress(outputBufferSecond, first, 0x00019388, 0x0001938C);

	//800D1644:	3C02803B	LUI     $v0, 0x803B	#
	//800D1648:	24425000	ADDIU   $v0, $v0, 0x5000	#(*CONSTANT) 803B5000
	//WriteAddiuAddress(outputDecompressed70A4EC, second, 0x00001394, 0x00001398);
	WriteAddiuAddress(outputBufferSecond, second, 0x00019394, 0x00019398);

	//800D184C:	000212C0	SLL     $v0, $v0, 0x0B
	WriteLongToBuffer(outputBufferSecond, 0x0001959C, 0x00021340);

	//800D1850:	3C038039	LUI     $v1, 0x8039	#
	//800D1854:	2463F800	ADDIU   $v1, $v1, 0xF800	#(*CONSTANT) 8038F800
	//WriteAddiuAddress(outputDecompressed70A4EC, first, 0x000015A0, 0x000015A4);
	WriteAddiuAddress(outputBufferSecond, first, 0x000195A0, 0x000195A4);



	// Crashes the in between
	//FF10013F
	//WriteLongToBuffer(outputDecompressed6F7118, 0x000018A0, newFF10013F);
	WriteLongToBuffer(outputBufferFirst, 0x000658A0, newFF10013F);
	//WriteLongToBuffer(outputDecompressed6F7118, 0x000018D8, newFF10013F);
	WriteLongToBuffer(outputBufferFirst, 0x000658D8, newFF10013F);

	//F64FC3BC
	//WriteLongToBuffer(outputDecompressed6F7118, 0x000018B0, newF64FC3BC);
	WriteLongToBuffer(outputBufferFirst, 0x000658B0, newF64FC3BC);
	//WriteLongToBuffer(outputDecompressed6F7118, 0x000018E8, newF64FC3BC);
	WriteLongToBuffer(outputBufferFirst, 0x000658E8, newF64FC3BC);

	//005003C0
	//WriteLongToBuffer(outputDecompressed6F7118, 0x000017CC, new005003C0);
	WriteLongToBuffer(outputBufferFirst, 0x000657CC, new005003C0);
	//WriteLongToBuffer(outputDecompressed6F7118, 0x00001804, new005003C0);
	WriteLongToBuffer(outputBufferFirst, 0x00065804, new005003C0);

	/*WriteLongToBuffer(outputDecompressed6F7118, 0x000016F0, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x000016F8, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001700, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001708, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001710, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001718, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001720, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001728, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001730, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001738, (((newWidth * 3) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001740, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001748, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001750, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001758, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001760, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001768, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001770, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001778, (((newWidth * 3) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001780, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001788, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001790, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x00001798, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x000017A0, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x000017A8, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x000017B0, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputDecompressed6F7118, 0x000017B8, (((newWidth * 3) << 16) | (newHeight * 3)));*/
	WriteLongToBuffer(outputBufferFirst, 0x000656F0, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputBufferFirst, 0x000656F8, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputBufferFirst, 0x00065700, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065708, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065710, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065718, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065720, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065728, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputBufferFirst, 0x00065730, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065738, (((newWidth * 3) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputBufferFirst, 0x00065740, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065748, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065750, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065758, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065760, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065768, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputBufferFirst, 0x00065770, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065778, (((newWidth * 3) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputBufferFirst, 0x00065780, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065788, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065790, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x00065798, (((newWidth * 3) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x000657A0, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x000657A8, (((newWidth) << 16) | (newHeight * 3)));
	WriteLongToBuffer(outputBufferFirst, 0x000657B0, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferFirst, 0x000657B8, (((newWidth * 3) << 16) | (newHeight * 3)));

	// To Fit
	//WriteLongToBuffer(outputDecompressed6F7118, 0x00003FF0, 0x11B111B1);


	// These changed crash the intro...first of each (FF, F6), if commented out load but look off
	// The rest crash the ingame part ...
	//FF10013F
	//800DCCB8
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000A08, newFF10013F);
	WriteLongToBuffer(outputBufferSecond, 0x00024A08, newFF10013F);
	//800DCCD0
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000A20, newFF10013F);
	WriteLongToBuffer(outputBufferSecond, 0x00024A20, newFF10013F);

	//F64FC3BC
	//800DCCC0
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000A10, newF64FC3BC);
	WriteLongToBuffer(outputBufferSecond, 0x00024A10, newF64FC3BC);
	//800DCCE0
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000A30, newF64FC3BC);
	WriteLongToBuffer(outputBufferSecond, 0x00024A30, newF64FC3BC);

	//005003C0
	//800DCC24
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000974, new005003C0);
	WriteLongToBuffer(outputBufferSecond, 0x00024974, new005003C0);

	//800DC7A0
	//WriteLongToBuffer(outputDecompressed70C78C, 0x000004F0, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputBufferSecond, 0x000244F0, (((newWidth * 2) << 16) | (newHeight * 2)));
	//800DC7A8
	//WriteLongToBuffer(outputDecompressed70C78C, 0x000004F8, (((newWidth * 2) << 16) | (newHeight * 2)));
	WriteLongToBuffer(outputBufferSecond, 0x000244F8, (((newWidth * 2) << 16) | (newHeight * 2)));
	
	//800DC814
	//WriteLongToBuffer(outputDecompressed70C78C, 0x00000564, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferSecond, 0x00024564, (((newWidth) << 16) | (newHeight)));
	//800DC84C
	//WriteLongToBuffer(outputDecompressed70C78C, 0x0000059C, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferSecond, 0x0002459C, (((newWidth) << 16) | (newHeight)));
	//800DC884
	//WriteLongToBuffer(outputDecompressed70C78C, 0x000005D4, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferSecond, 0x000245D4, (((newWidth) << 16) | (newHeight)));
	//800DC8BC
	//WriteLongToBuffer(outputDecompressed70C78C, 0x0000060C, (((newWidth) << 16) | (newHeight)));
	WriteLongToBuffer(outputBufferSecond, 0x0002460C, (((newWidth) << 16) | (newHeight)));



	/*WriteLongToBuffer(outputDecompressed6F9A90, 0x00002158, (unsigned long)((float)newWidth / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002164, (unsigned long)((float)newWidth / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x0000216C, (unsigned long)((float)newWidth / 2.0) + 2);
	
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002194, (unsigned long)((float)newWidth / 2.0) - 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021A8, (unsigned long)((float)newWidth / 2.0) - 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021A0, (unsigned long)((float)newWidth / 2.0) - 2);
	
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021C4, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021D4, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021D8, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021E8, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021EC, (unsigned long)((float)newHeight / 2.0) + 2);

	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002200, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002210, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002220, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002224, (unsigned long)((float)newHeight / 2.0) - 2);

	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002170, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002180, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002190, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002198, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021A4, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021AC, newWidth - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x000021F0, newHeight - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002204, newHeight - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002214, newHeight - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002218, newHeight - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x00002228, newHeight - 1);
	WriteLongToBuffer(outputDecompressed6F9A90, 0x0000222C, newHeight - 1);*/
	WriteLongToBuffer(outputBufferFirst, 0x00072158, (unsigned long)((float)newWidth / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x00072164, (unsigned long)((float)newWidth / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x0007216C, (unsigned long)((float)newWidth / 2.0) + 2);
	
	WriteLongToBuffer(outputBufferFirst, 0x00072194, (unsigned long)((float)newWidth / 2.0) - 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721A8, (unsigned long)((float)newWidth / 2.0) - 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721A0, (unsigned long)((float)newWidth / 2.0) - 2);
	
	WriteLongToBuffer(outputBufferFirst, 0x000721C4, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721D4, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721D8, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721E8, (unsigned long)((float)newHeight / 2.0) + 2);
	WriteLongToBuffer(outputBufferFirst, 0x000721EC, (unsigned long)((float)newHeight / 2.0) + 2);

	WriteLongToBuffer(outputBufferFirst, 0x00072200, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputBufferFirst, 0x00072210, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputBufferFirst, 0x00072220, (unsigned long)((float)newHeight / 2.0) - 2);
	WriteLongToBuffer(outputBufferFirst, 0x00072224, (unsigned long)((float)newHeight / 2.0) - 2);

	WriteLongToBuffer(outputBufferFirst, 0x00072170, newWidth - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072180, newWidth - 1); // Multi width P1
	WriteLongToBuffer(outputBufferFirst, 0x00072184, newWidth - 1); // Multi width P2
	WriteLongToBuffer(outputBufferFirst, 0x00072190, newWidth - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072198, newWidth - 1);
	WriteLongToBuffer(outputBufferFirst, 0x000721A4, newWidth - 1);
	WriteLongToBuffer(outputBufferFirst, 0x000721AC, newWidth - 1);
	WriteLongToBuffer(outputBufferFirst, 0x000721F0, newHeight - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072204, newHeight - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072214, newHeight - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072218, newHeight - 1);
	WriteLongToBuffer(outputBufferFirst, 0x00072228, newHeight - 1);
	WriteLongToBuffer(outputBufferFirst, 0x0007222C, newHeight - 1);

	// To Fit
	//WriteLongToBuffer(outputDecompressed6F9A90, 0x00003FF4, 0xF88CF891);
	//WriteLongToBuffer(outputDecompressed6F9A90, 0x00003FFC, 0xF88CF891);


	// Crashes load of logo in between file loads
	//8011B128:	240200C8	ADDIU   $v0, $zero, 0x00C8	#
	unsigned short newHeightC8 = (unsigned short)((float)newHeight / 6.0 * 5.0);
	//WriteShortToBuffer(outputDecompressed6F4D88, 0x00002E78 + 2, newHeightC8);
	WriteShortToBuffer(outputBufferFirst, 0x00062E78 + 2, newHeightC8);



	// Crashes when start in-level (the middle one)
	// ED000000
	//800C896C:	3C04004F	LUI     $a0, 0x004F	#
	//800C8970:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteOriAddress(outputDecompressed6CC748, new004FC3BC, 0x000006BC, 0x000006C0);
	WriteOriAddress(outputBufferFirst, new004FC3BC, 0x000106BC, 0x000106C0);
	
	//800C8E88:	3C04004F	LUI     $a0, 0x004F	#
	//800C8E90:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteOriAddress(outputDecompressed6CC748, new004FC3BC, 0x00000BD8, 0x00000BC0);
	//WriteOriAddress(outputBufferFirst, new004FC3BC, 0x00010BD8, 0x00010BC0);

	//800C9098:	3C04004F	LUI     $a0, 0x004F	#
	//800C90A0:	3484C3BC	ORI     $a0, $a0, 0xC3BC	#(*CONSTANT) 004FC3BC
	//WriteOriAddress(outputDecompressed6CC748, new004FC3BC, 0x00000DE8, 0x00000DF0);
	WriteOriAddress(outputBufferFirst, new004FC3BC, 0x00010DE8, 0x00010DF0);

	
	outFirst = fopen("C:\\temp\\firstdecompressedre.bin", "wb");
	if (outFirst)
	{
		fwrite(outputBufferFirst, 1, outputSpotFirst, outFirst);
		fflush(outFirst);
		fclose(outFirst);
	}


	outSecond = fopen("C:\\temp\\seconddecompressedre.bin", "wb");
	if (outSecond)
	{
		fwrite(outputBufferSecond, 1, outputSpotSecond, outSecond);
		fflush(outSecond);
		fclose(outSecond);
	}


	int outputDataSpotFirst = 0;
	unsigned char* compressedBufferFirst = new unsigned char[0x1000000];
	for (int x = 0; x < 0x1000000; x++)
		compressedBufferFirst[x] = 0x00;

	int compressedBufferFirstSpot = 0;

	while (outputDataSpotFirst < firstCompressedCount)
	{
		int remaining = (firstCompressedCount - outputDataSpotFirst);
		if (remaining > 0x4000)
			remaining = 0x4000;

		bool nonZero = true;
		for (int x = 0; x < remaining; x++)
		{
			if (outputBufferFirst[outputDataSpotFirst + x] != 0)
			{
				nonZero = false;
				break;
			}
		}

		if (nonZero)
		{
			WriteLongToBuffer(compressedBufferFirst, compressedBufferFirstSpot, 0x46494C4C);
			WriteShortToBuffer(compressedBufferFirst, compressedBufferFirstSpot + 4, remaining);
			compressedBufferFirstSpot += 8;
			outputDataSpotFirst += remaining;
		}
		else
		{
			int compressedSize = CompressRNCFile(&rnc, compressedBufferFirst, &outputBufferFirst[outputDataSpotFirst], remaining, compressedBufferFirstSpot, 999999);
			if (compressedSize == 0)
			{
				MessageBox("Error rnc compression");
				return;
			}
			outputDataSpotFirst += remaining;
			compressedBufferFirstSpot += compressedSize;

			if ((compressedBufferFirstSpot % 8) > 0)
				compressedBufferFirstSpot += (8 - (compressedBufferFirstSpot % 8));
		}
	}

	WriteLongToBuffer(compressedBufferFirst, compressedBufferFirstSpot, 0x454E4421); // END
	compressedBufferFirstSpot += 4;

	memcpy(&ROM[startCompressedData + 0x18], compressedBufferFirst, compressedBufferFirstSpot);
	unsigned long checksumrefirst = calculateRNXUncompressedCRC(outputBufferFirst, outputSpotFirst);

	int startSecondDataSpot = startCompressedData + 0x18 + compressedBufferFirstSpot;

	int outputDataSpotSecond = 0;
	unsigned char* compressedBufferSecond = new unsigned char[0x1000000];
	for (int x = 0; x < 0x1000000; x++)
		compressedBufferSecond[x] = 0x00;

	int compressedBufferSecondSpot = 0;

	while (outputDataSpotSecond < secondCompressedCount)
	{
		int remaining = (secondCompressedCount - outputDataSpotSecond);
		if (remaining > 0x4000)
			remaining = 0x4000;

		bool nonZero = true;
		for (int x = 0; x < remaining; x++)
		{
			if (outputBufferSecond[outputDataSpotSecond + x] != 0)
			{
				nonZero = false;
				break;
			}
		}

		if (nonZero)
		{
			WriteLongToBuffer(compressedBufferSecond, compressedBufferSecondSpot, 0x46494C4C);
			WriteShortToBuffer(compressedBufferSecond, compressedBufferSecondSpot + 4, remaining);
			compressedBufferSecondSpot += 8;
			outputDataSpotSecond += remaining;
		}
		else
		{
			int compressedSize = CompressRNCFile(&rnc, compressedBufferSecond, &outputBufferSecond[outputDataSpotSecond], remaining, compressedBufferSecondSpot, 999999);
			if (compressedSize == 0)
			{
				MessageBox("Error rnc compression");
				return;
			}
			outputDataSpotSecond += remaining;
			compressedBufferSecondSpot += compressedSize;

			if ((compressedBufferSecondSpot % 8) > 0)
				compressedBufferSecondSpot += (8 - (compressedBufferSecondSpot % 8));
		}
	}

	WriteLongToBuffer(compressedBufferSecond, compressedBufferSecondSpot, 0x454E4421); // END
	compressedBufferSecondSpot += 4;

	if (startSecondDataSpot > 0x6FE48C)
	{
		MessageBox("Too big");
	}
	else
	{
		for (int x = startSecondDataSpot; x < 0x6FE48C; x++)
			compressedBufferSecond[compressedBufferSecondSpot]++;
	}

	startSecondDataSpot = 0x6FE48C;

	memcpy(&ROM[startSecondDataSpot], compressedBufferSecond, compressedBufferSecondSpot);
	unsigned long checksumresecond = calculateRNXUncompressedCRC(outputBufferSecond, outputSpotSecond);

	WriteLongToBuffer(ROM, startCompressedData + 0x8, checksumrefirst);
	WriteLongToBuffer(ROM, startCompressedData + 0x8 + 0xC, checksumresecond);

	FILE* outFileA;
	CString tempStr;
	if (rawData == rawDataHAN1NoAA)
	{
		outFileA = fopen("C:\\temp\\forsakenhiresnoaa.rom", "wb");
		tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\forsakenhiresnoaa.rom");
	}
	else
	{
		outFileA = fopen("C:\\temp\\forsakenhires.rom", "wb");
		tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\forsakenhires.rom");
	}
	fwrite(ROM, 1, romSize, outFileA);
	fclose(outFileA);
	
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] compressedBufferFirst;
	delete [] compressedBufferSecond;
	delete [] outputBufferFirst;
    delete [] outputBufferSecond;

	delete [] ROM;	
}

void CMakeGameHiResDlg::OnBnClickedButtonbk20()
{
	int romSize = 0x1000000;
	unsigned char* ROM = new unsigned char[romSize];

	FILE* inFile = fopen("C:\\GoldeneyeStuff\\N64Hack\\ROMs\\GoodSet\\F-ZERO X (U) [!].z64", "rb");
	fread(ROM, 1, romSize, inFile);
	fclose(inFile);

	// VI Settings
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1[76] =
	{
		0x00, 0x00, 0x30, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	// HAN1 No AA
	// Normal 640 x 480i, supposed to flicker but be 640 x 480...not working, overriden by game settings
	unsigned char rawDataHAN1NoAA[76] =
	{
		0x00, 0x00, 0x33, 0x5E, 0x00, 0x00, 0x05, 0x00, 0x03, 0xE5, 0x22, 0x39, 0x00, 0x00, 0x02, 0x0C, 
		0x00, 0x00, 0x0C, 0x15, 0x0C, 0x15, 0x0C, 0x15, 0x00, 0x6C, 0x02, 0xEC, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x23, 0x01, 0xFD, 
		0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 
		0x00, 0x25, 0x01, 0xFF, 0x00, 0x0E, 0x02, 0x04, 0x00, 0x00, 0x00, 0x02, 
	};

	unsigned char* rawData = rawDataHAN1;
	for (int y = 0x0006BD00; y < 0x0006CE80; y += 0x50)
	{
		for (int x = 0; x < 0x4C; x++)
		{
			ROM[y + x + 4] = rawData[x];
		}
	}

	int newWidth = 0x280;
	int newHeight = 0x1E0;
	unsigned long newSize = newWidth * newHeight * 2;

	unsigned long endRAM = 0x80800000;
	unsigned long first = endRAM - (newSize * 3);
	unsigned long second = endRAM - (newSize * 2);
	unsigned long third = endRAM - (newSize * 1);
	unsigned long newDepthBuffer = 0x80400400;

	unsigned long newFF10013F = 0xFF10027F;
	unsigned long newF64FC3BC = 0xF69F8778;
	// ED Command
	unsigned long new005003C0 = 0x00A00780;
	unsigned long new004D03A0 = 0x009A0740;
	unsigned long new004D0380 = 0x009A0700;
	
	if ((newWidth <= 0x140) && (newHeight <= 0xF0))
	{
		newFF10013F = 0xFF10013F;
		newF64FC3BC = 0xF64FC3BC;
		new005003C0 = 0x005003C0;
		new004D03A0 = 0x004D03A0;
		new004D0380 = 0x004D0380;
	}

	//ED
	WriteLongToBuffer(ROM, 0x0001B5B94, 0x004D0380 * 2);
	//F64CC37C
	WriteLongToBuffer(ROM, 0x001B5B98, 0xF6000000 | (0x4CC37C * 2));


	//F64D03A0
	WriteLongToBuffer(ROM, 0x0017B4F8, 0xF6000000 | (0x4D03A0 * 2));
	//800FF9A8:	3C0CF64D	LUI     $t4, 0xF64D	#
	//800FF9B0:	358C03A0	ORI     $t4, $t4, 0x03A0	#(*CONSTANT) F64D03A0
	WriteAddiuAddress(ROM, 0xF6000000 | (0x4D03A0 * 2), 0x0009B2F8, 0x0009B300);
	
	
	//FE command
	WriteLongToBuffer(ROM, 0x0017B35C, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x0017B4E4, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x0017B50C, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x001B5A94, newDepthBuffer & 0xFFFFFF); 
	WriteLongToBuffer(ROM, 0x001B5B7C, newDepthBuffer & 0xFFFFFF); 
	//FF Command
	WriteLongToBuffer(ROM, 0x0017B364, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x0017B4EC, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x001B5A9C, newDepthBuffer & 0xFFFFFF);
	WriteLongToBuffer(ROM, 0x001B5B84, newDepthBuffer & 0xFFFFFF); 

	//800678C4:	3C0E801E	LUI     $t6, 0x801E	#
	//800678D8:	25CE9800	ADDIU   $t6, $t6, 0x9800	#(*CONSTANT) 801D9800
	WriteAddiuAddress(ROM, first, 0x000018C4, 0x000018D8);

	//800678C8:	3C0F8020	LUI     $t7, 0x8020	#
	//800678DC:	25EF0000	ADDIU   $t7, $t7, 0x0000	#(*CONSTANT) 80200000
	WriteAddiuAddress(ROM, second, 0x000018C8, 0x000018DC);

	//800678CC:	3C18803E	LUI     $t8, 0x803E	#
	//800678E0:	2718A800	ADDIU   $t8, $t8, 0xA800	#(*CONSTANT) 803DA800
	WriteAddiuAddress(ROM, third, 0x000018CC, 0x000018E0);


	// start game, must be in compressed data?
	//801274C4:	24100140	ADDIU   $s0, $zero, 0x0140	#
	//801274CC:	240600F0	ADDIU   $a2, $zero, 0x00F0	#


	WriteShortToBuffer(ROM, 0x0033F2E8, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F2F0, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F2F8, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F300, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F308, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F310, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F318, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F320, (newWidth + 0x18));
	WriteShortToBuffer(ROM, 0x0033F328, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F330, ((newWidth * 3) - 0x18));
	WriteShortToBuffer(ROM, 0x0033F338, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F340, (newWidth + 0x18));
	WriteShortToBuffer(ROM, 0x0033F348, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F350, ((newWidth * 3) - 0x18));
	WriteShortToBuffer(ROM, 0x0033F358, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F360, (newWidth + 0x18));
	WriteShortToBuffer(ROM, 0x0033F368, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F370, ((newWidth * 3) - 0x18));
	WriteShortToBuffer(ROM, 0x0033F378, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F380, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F388, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F390, (newWidth * 2));
	WriteShortToBuffer(ROM, 0x0033F398, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F3A0, (newWidth + 0x18));
	WriteShortToBuffer(ROM, 0x0033F3A8, (newWidth));
	WriteShortToBuffer(ROM, 0x0033F3B0, ((newWidth * 3) - 0x18));
	
	WriteShortToBuffer(ROM, 0x0033F2EA, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F2F2, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F2FA, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F302, ((newHeight * 2) + 0x10));
	WriteShortToBuffer(ROM, 0x0033F30A, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F312, ((newHeight * 4) - 0x10));
	WriteShortToBuffer(ROM, 0x0033F31A, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F322, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F32A, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F332, ((newHeight * 2)));
	WriteShortToBuffer(ROM, 0x0033F33A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F342, (newHeight + 0x10));
	WriteShortToBuffer(ROM, 0x0033F34A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F352, (newHeight + 0x10));
	WriteShortToBuffer(ROM, 0x0033F35A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F362, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(ROM, 0x0033F36A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F372, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(ROM, 0x0033F37A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F382, (newHeight + 0x10));
	WriteShortToBuffer(ROM, 0x0033F38A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F392, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(ROM, 0x0033F39A, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F3A2, (newHeight * 2));
	WriteShortToBuffer(ROM, 0x0033F3AA, (newHeight));
	WriteShortToBuffer(ROM, 0x0033F3B2, ((newHeight * 2)));

	// Multi viewports
	WriteLongToBuffer(ROM, 0x000679C8, CharArrayToLong(&ROM[0x000679C8]) * 2);
	WriteLongToBuffer(ROM, 0x000679CC, CharArrayToLong(&ROM[0x000679CC]) * 2);
	WriteLongToBuffer(ROM, 0x000679D0, CharArrayToLong(&ROM[0x000679D0]) * 2);
	WriteLongToBuffer(ROM, 0x000679D4, CharArrayToLong(&ROM[0x000679D4]) * 2);
	WriteLongToBuffer(ROM, 0x000679D8, CharArrayToLong(&ROM[0x000679D8]) * 2);
	WriteLongToBuffer(ROM, 0x000679DC, CharArrayToLong(&ROM[0x000679DC]) * 2);
	WriteLongToBuffer(ROM, 0x000679E0, CharArrayToLong(&ROM[0x000679E0]) * 2);
	WriteLongToBuffer(ROM, 0x000679E4, CharArrayToLong(&ROM[0x000679E4]) * 2);
	WriteLongToBuffer(ROM, 0x000679E8, CharArrayToLong(&ROM[0x000679E8]) * 2);
	WriteLongToBuffer(ROM, 0x000679EC, CharArrayToLong(&ROM[0x000679EC]) * 2);
	WriteLongToBuffer(ROM, 0x000679F0, CharArrayToLong(&ROM[0x000679F0]) * 2);
	WriteLongToBuffer(ROM, 0x000679F4, CharArrayToLong(&ROM[0x000679F4]) * 2);
	WriteLongToBuffer(ROM, 0x000679F8, CharArrayToLong(&ROM[0x000679F8]) * 2);
	WriteLongToBuffer(ROM, 0x000679FC, CharArrayToLong(&ROM[0x000679FC]) * 2);
	WriteLongToBuffer(ROM, 0x00067A00, CharArrayToLong(&ROM[0x00067A00]) * 2);
	WriteLongToBuffer(ROM, 0x00067A04, CharArrayToLong(&ROM[0x00067A04]) * 2);
	WriteLongToBuffer(ROM, 0x00067A08, CharArrayToLong(&ROM[0x00067A08]) * 2);
	WriteLongToBuffer(ROM, 0x00067A0C, CharArrayToLong(&ROM[0x00067A0C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A10, CharArrayToLong(&ROM[0x00067A10]) * 2);
	WriteLongToBuffer(ROM, 0x00067A14, CharArrayToLong(&ROM[0x00067A14]) * 2);
	WriteLongToBuffer(ROM, 0x00067A18, CharArrayToLong(&ROM[0x00067A18]) * 2);
	WriteLongToBuffer(ROM, 0x00067A1C, CharArrayToLong(&ROM[0x00067A1C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A20, CharArrayToLong(&ROM[0x00067A20]) * 2);
	WriteLongToBuffer(ROM, 0x00067A24, CharArrayToLong(&ROM[0x00067A24]) * 2);
	WriteLongToBuffer(ROM, 0x00067A28, CharArrayToLong(&ROM[0x00067A28]) * 2);
	WriteLongToBuffer(ROM, 0x00067A2C, CharArrayToLong(&ROM[0x00067A2C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A30, CharArrayToLong(&ROM[0x00067A30]) * 2);
	WriteLongToBuffer(ROM, 0x00067A34, CharArrayToLong(&ROM[0x00067A34]) * 2);
	WriteLongToBuffer(ROM, 0x00067A38, CharArrayToLong(&ROM[0x00067A38]) * 2);
	WriteLongToBuffer(ROM, 0x00067A3C, CharArrayToLong(&ROM[0x00067A3C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A40, CharArrayToLong(&ROM[0x00067A40]) * 2);
	WriteLongToBuffer(ROM, 0x00067A44, CharArrayToLong(&ROM[0x00067A44]) * 2);
	WriteLongToBuffer(ROM, 0x00067A48, CharArrayToLong(&ROM[0x00067A48]) * 2);
	WriteLongToBuffer(ROM, 0x00067A4C, CharArrayToLong(&ROM[0x00067A4C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A50, CharArrayToLong(&ROM[0x00067A50]) * 2);
	WriteLongToBuffer(ROM, 0x00067A54, CharArrayToLong(&ROM[0x00067A54]) * 2);
	WriteLongToBuffer(ROM, 0x00067A58, CharArrayToLong(&ROM[0x00067A58]) * 2);
	WriteLongToBuffer(ROM, 0x00067A5C, CharArrayToLong(&ROM[0x00067A5C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A60, CharArrayToLong(&ROM[0x00067A60]) * 2);
	WriteLongToBuffer(ROM, 0x00067A64, CharArrayToLong(&ROM[0x00067A64]) * 2);
	WriteLongToBuffer(ROM, 0x00067A68, CharArrayToLong(&ROM[0x00067A68]) * 2);
	WriteLongToBuffer(ROM, 0x00067A6C, CharArrayToLong(&ROM[0x00067A6C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A70, CharArrayToLong(&ROM[0x00067A70]) * 2);
	WriteLongToBuffer(ROM, 0x00067A74, CharArrayToLong(&ROM[0x00067A74]) * 2);
	WriteLongToBuffer(ROM, 0x00067A78, CharArrayToLong(&ROM[0x00067A78]) * 2);
	WriteLongToBuffer(ROM, 0x00067A7C, CharArrayToLong(&ROM[0x00067A7C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A80, CharArrayToLong(&ROM[0x00067A80]) * 2);
	WriteLongToBuffer(ROM, 0x00067A84, CharArrayToLong(&ROM[0x00067A84]) * 2);
	WriteLongToBuffer(ROM, 0x00067A88, CharArrayToLong(&ROM[0x00067A88]) * 2);
	WriteLongToBuffer(ROM, 0x00067A8C, CharArrayToLong(&ROM[0x00067A8C]) * 2);
	WriteLongToBuffer(ROM, 0x00067A90, CharArrayToLong(&ROM[0x00067A90]) * 2);

	WriteShortToBuffer(ROM, 0x0017B4B0, (newWidth));
	WriteShortToBuffer(ROM, 0x0017B4B4, (newHeight));
	WriteShortToBuffer(ROM, 0x0017B4B8, (newWidth));
	WriteShortToBuffer(ROM, 0x0017B4BC, (newHeight));


	//8007A4C4:	24070140	ADDIU   $a3, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000144C4 + 2, newWidth);
	//8007A4C8:	284100F1	SLTI    $at, $v0, 0x00F1	#
	WriteShortToBuffer(ROM, 0x000144C8 + 2, newHeight + 1);
	//8007A4D4:	240200F0	ADDIU   $v0, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000144D4 + 2, newHeight);


	// Not 100% sure these
	//801274B0:	240B0140	ADDIU   $t3, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000C14B0 + 2, newWidth);
	//801274B8:	2A0100A0	SLTI    $at, $s0, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000C14B8 + 2, newWidth / 2);
	//801274C4:	241000A0	ADDIU   $s0, $zero, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000C14C4 + 2, newWidth / 2);
	//801274CC:	24060078	ADDIU   $a2, $zero, 0x0078	#
	WriteShortToBuffer(ROM, 0x000C14CC + 2, newHeight / 2);

	//801275CC:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000C15CC + 2, newWidth);
	//801275D0:	240500A0	ADDIU   $a1, $zero, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000C15D0 + 2, newWidth / 2);
	//801275DC:	2A0100A0	SLTI    $at, $s0, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000C15DC + 2, newWidth / 2);
	//801275E8:	241000A0	ADDIU   $s0, $zero, 0x00A0	#
	WriteShortToBuffer(ROM, 0x000C15E8 + 2, newWidth / 2);

	//801330A4:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000CD0A4 + 2, newWidth);
	
	//80135528:	24160140	ADDIU   $s6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000CF528 + 2, newWidth);
	//8013552C:	241700F0	ADDIU   $s7, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000CF52C + 2, newHeight);

	//80136694:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000D0694 + 2, newWidth);

	//8014295C:	240E0140	ADDIU   $t6, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DC95C + 2, newWidth);
	//80142968:	240F00F0	ADDIU   $t7, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DC968 + 2, newHeight);
	//80142988:	24190280	ADDIU   $t9, $zero, 0x0280	#
	WriteShortToBuffer(ROM, 0x000DC988 + 2, newWidth * 2);
	//80142994:	240D0258	ADDIU   $t5, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DC994 + 2, (newHeight * 2) + (newHeight / 2));

	//801429B4:	240F0140	ADDIU   $t7, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DC9B4 + 2, newWidth);
	//801429C0:	241800F0	ADDIU   $t8, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DC9C0 + 2, newHeight);
	//801429E0:	240D0280	ADDIU   $t5, $zero, 0x0280	#
	WriteShortToBuffer(ROM, 0x000DC9E0 + 2, newWidth * 2);
	//801429EC:	240E0258	ADDIU   $t6, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DC9EC + 2, (newHeight * 2) + (newHeight / 2));

	//80142A0C:	24180140	ADDIU   $t8, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DCA0C + 2, newWidth);
	//80142A18:	241900F0	ADDIU   $t9, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DCA18 + 2, newHeight);
	//80142A38:	240E0780	ADDIU   $t6, $zero, 0x0780	#
	WriteShortToBuffer(ROM, 0x000DCA38 + 2, newWidth * 6);
	//80142A44:	240F0258	ADDIU   $t7, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DCA44 + 2, (newHeight * 2) + (newHeight / 2));

	//80142A64:	24190140	ADDIU   $t9, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DCA64 + 2, newWidth);
	//80142A70:	240D00F0	ADDIU   $t5, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DCA70 + 2, newHeight);
	//80142A90:	240F0780	ADDIU   $t7, $zero, 0x0780	#
	WriteShortToBuffer(ROM, 0x000DCA90 + 2, newWidth * 6);
	//80142A9C:	24180258	ADDIU   $t8, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DCA9C + 2, (newHeight * 2) + (newHeight / 2));

	//80142AD0:	24040140	ADDIU   $a0, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DCAD0 + 2, newWidth);
	//80142AD4:	240500F0	ADDIU   $a1, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DCAD4 + 2, newHeight);
	//80142AD8:	24060258	ADDIU   $a2, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DCAD8 + 2, (newHeight * 2) + (newHeight / 2));
	//80142AE8:	24E90780	ADDIU   $t1, $a3, 0x0780	#
	WriteShortToBuffer(ROM, 0x000DCAE8 + 2, newWidth * 6);
	//80142AEC:	24EA0C80	ADDIU   $t2, $a3, 0x0C80	#
	WriteShortToBuffer(ROM, 0x000DCAEC + 2, newWidth * 0xA);
	//80142AF0:	24EB1180	ADDIU   $t3, $a3, 0x1180	#
	WriteShortToBuffer(ROM, 0x000DCAF0 + 2, newWidth * 0xE);
	//80142AF4:	24E80280	ADDIU   $t0, $a3, 0x0280	#
	WriteShortToBuffer(ROM, 0x000DCAF4 + 2, newWidth * 0x2);

	//80142C30:	24090140	ADDIU   $t1, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000DCC30 + 2, newWidth);
	//80142C34:	240A00F0	ADDIU   $t2, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000DCC34 + 2, newHeight);
	//80142C38:	240C0258	ADDIU   $t4, $zero, 0x0258	#
	WriteShortToBuffer(ROM, 0x000DCC38 + 2, (newHeight * 2) + (newHeight / 2));
	//80142C3C:	24980280	ADDIU   $t8, $a0, 0x0280	#(*CONSTANT) 000003C0
	WriteShortToBuffer(ROM, 0x000DCC3C + 2, newWidth * 2);
	//80142C64:	248E0780	ADDIU   $t6, $a0, 0x0780	#(*CONSTANT) 00000B40
	WriteShortToBuffer(ROM, 0x000DCC64 + 2, newWidth * 6);
	//80142CD0:	24CE0280	ADDIU   $t6, $a2, 0x0280	#
	WriteShortToBuffer(ROM, 0x000DCCD0 + 2, newWidth * 2);
	//80142CF8:	24CD0780	ADDIU   $t5, $a2, 0x0780	#
	WriteShortToBuffer(ROM, 0x000DCCF8 + 2, newWidth * 6);
	//80142D38:	24D90C80	ADDIU   $t9, $a2, 0x0C80	#
	WriteShortToBuffer(ROM, 0x000DCD38 + 2, newWidth * 0xA);
	//80142D78:	24D81180	ADDIU   $t8, $a2, 0x1180	#
	WriteShortToBuffer(ROM, 0x000DCD78 + 2, newWidth * 0xE);

	//80147088:	29410141	SLTI    $at, $t2, 0x0141	#
	WriteShortToBuffer(ROM, 0x000E1088 + 2, newWidth + 1);
	//80147094:	240A0140	ADDIU   $t2, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000E1094 + 2, newWidth);

	//80149048:	240E00F0	ADDIU   $t6, $zero, 0x00F0	#
	WriteShortToBuffer(ROM, 0x000E3048 + 2, newHeight);
	//8014904C:	24180140	ADDIU   $t8, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000E304C + 2, newWidth);

	//8014D7A0:	24130140	ADDIU   $s3, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000E77A0 + 2, newWidth);
	//80152120:	240A0140	ADDIU   $t2, $zero, 0x0140	#
	WriteShortToBuffer(ROM, 0x000EC120 + 2, newWidth);

	WriteLongToBuffer(ROM, 0x0017B360, newFF10013F);
	WriteLongToBuffer(ROM, 0x0017B4E8, newFF10013F);
	WriteLongToBuffer(ROM, 0x001B5A98, newFF10013F);
	WriteLongToBuffer(ROM, 0x001B5B80, newFF10013F);

	//8007ABCC:	3C18FF10	LUI     $t8, 0xFF10	#
	//8007ABD0:	3718013F	ORI     $t8, $t8, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x00014BCC, 0x00014BD0);
	//8007AC0C:	3C0BFF10	LUI     $t3, 0xFF10	#
	//8007AC10:	356B013F	ORI     $t3, $t3, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x00014C0C, 0x00014C10);
	//80105634:	3C0CFF10	LUI     $t4, 0xFF10	#
	//80105638:	358C013F	ORI     $t4, $t4, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009F634, 0x0009F638);
	//80105670:	3C19FF10	LUI     $t9, 0xFF10	#
	//80105674:	3739013F	ORI     $t9, $t9, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009F670, 0x0009F674);
	//80105730:	3C0EFF10	LUI     $t6, 0xFF10	#
	//80105734:	35CE013F	ORI     $t6, $t6, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009F730, 0x0009F734);
	//8010576C:	3C0BFF10	LUI     $t3, 0xFF10	#
	//80105770:	356B013F	ORI     $t3, $t3, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009F76C, 0x0009F770);
	//80105A5C:	3C0DFF10	LUI     $t5, 0xFF10	#
	//80105A60:	35AD013F	ORI     $t5, $t5, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009FA5C, 0x0009FA60);
	//80105A58:	3C0AFF10	LUI     $t2, 0xFF10	#
	//80105A98:	354A013F	ORI     $t2, $t2, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x0009FA58, 0x0009FA98);
	//80133684:	3C19FF10	LUI     $t9, 0xFF10	#
	//80133690:	3739013F	ORI     $t9, $t9, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000CD684, 0x000CD690);
	//8015093C:	3C0BFF10	LUI     $t3, 0xFF10	#
	//80150948:	356B013F	ORI     $t3, $t3, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000EA93C, 0x000EA948);
	//801509BC:	3C0CFF10	LUI     $t4, 0xFF10	#
	//801509C8:	358C013F	ORI     $t4, $t4, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000EA9BC, 0x000EA9C8);
	//80150AB8:	3C0DFF10	LUI     $t5, 0xFF10	#
	//80150AD0:	35AD013F	ORI     $t5, $t5, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000EAAB8, 0x000EAAD0);
	//80158160:	3C0BFF10	LUI     $t3, 0xFF10	#
	//8015816C:	356B013F	ORI     $t3, $t3, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000F2160, 0x000F216C);
	//801581E0:	3C0CFF10	LUI     $t4, 0xFF10	#
	//801581EC:	358C013F	ORI     $t4, $t4, 0x013F	#(*CONSTANT) FF10013F
	WriteOriAddress(ROM, newFF10013F, 0x000F21E0, 0x000F21EC);

	
	//801056A8:	3C0EF64F	LUI     $t6, 0xF64F	#
	//801056AC:	35CEC3BC	ORI     $t6, $t6, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteOriAddress(ROM, newF64FC3BC, 0x0009F6A8, 0x0009F6AC);
	//8013FE08:	3C0EF64F	LUI     $t6, 0xF64F	#
	//8013FE0C:	35CEC3BC	ORI     $t6, $t6, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteOriAddress(ROM, newF64FC3BC, 0x000D9E08, 0x000D9E0C);
	//80150980:	3C18F64F	LUI     $t8, 0xF64F	#
	//80150984:	3718C3BC	ORI     $t8, $t8, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteOriAddress(ROM, newF64FC3BC, 0x000EA980, 0x000EA984);
	//801581A4:	3C18F64F	LUI     $t8, 0xF64F	#
	//801581A8:	3718C3BC	ORI     $t8, $t8, 0xC3BC	#(*CONSTANT) F64FC3BC
	WriteOriAddress(ROM, newF64FC3BC, 0x000F21A4, 0x000F21A8);

	//ED
	WriteLongToBuffer(ROM, 0x00070D94, new005003C0);
	WriteLongToBuffer(ROM, 0x000711B4, new005003C0);
	WriteLongToBuffer(ROM, 0x000715C4, new005003C0);
	WriteLongToBuffer(ROM, 0x00071974, new005003C0);

	//801055EC:	3C180050	LUI     $t8, 0x0050	#
	//801055F0:	371803C0	ORI     $t8, $t8, 0x03C0	#(*CONSTANT) 005003C0
	WriteOriAddress(ROM, new005003C0, 0x0009F5EC, 0x0009F5F0);
	//8012689C:	3C0B0050	LUI     $t3, 0x0050	#
	//801268A0:	356B03C0	ORI     $t3, $t3, 0x03C0	#(*CONSTANT) 005003C0
	WriteOriAddress(ROM, new005003C0, 0x000C089C, 0x000C08A0);
	//8013FD9C:	3C180050	LUI     $t8, 0x0050	#
	//8013FDA0:	371803C0	ORI     $t8, $t8, 0x03C0	#(*CONSTANT) 005003C0
	WriteOriAddress(ROM, new005003C0, 0x000D9D9C, 0x000D9DA0);
	//80150914:	3C180050	LUI     $t8, 0x0050	#
	//80150918:	371803C0	ORI     $t8, $t8, 0x03C0	#(*CONSTANT) 005003C0
	WriteOriAddress(ROM, new005003C0, 0x000EA914, 0x000EA918);
	//80158138:	3C180050	LUI     $t8, 0x0050	#
	//8015813C:	371803C0	ORI     $t8, $t8, 0x03C0	#(*CONSTANT) 005003C0
	WriteOriAddress(ROM, new005003C0, 0x000F2138, 0x000F213C);
	
	WriteLongToBuffer(ROM, 0x0017B414, new004D03A0);
	WriteLongToBuffer(ROM, 0x0017B4DC, new004D03A0);
	WriteLongToBuffer(ROM, 0x0017B55C, new004D03A0);
	WriteLongToBuffer(ROM, 0x001B5AAC, new004D03A0);


	//8011D8B0:	3C18004D	LUI     $t8, 0x004D	#
	//8011D8B4:	371803A0	ORI     $t8, $t8, 0x03A0	#(*CONSTANT) 004D03A0
	WriteOriAddress(ROM, new004D03A0, 0x000B0B80, 0x000B0B84);

	//80120D64:	3C19004D	LUI     $t9, 0x004D	#
	//80120D6C:	373903A0	ORI     $t9, $t9, 0x03A0	#(*CONSTANT) 004D03A0
	WriteOriAddress(ROM, new004D03A0, 0x000B4034, 0x000B403C);

	//80121308:	3C19004D	LUI     $t9, 0x004D	#
	//8012130C:	373903A0	ORI     $t9, $t9, 0x03A0	#(*CONSTANT) 004D03A0
	WriteOriAddress(ROM, new004D03A0, 0x000B45D8, 0x000B45DC);

	//80126D00:	3C0F004D	LUI     $t7, 0x004D	#
	//80126D04:	35EF03A0	ORI     $t7, $t7, 0x03A0	#(*CONSTANT) 004D03A0
	WriteOriAddress(ROM, new004D03A0, 0x000B9FD0, 0x000B9FD4);

	//8012D7B0:	3C0D004D	LUI     $t5, 0x004D	#
	//8012D7B4:	35AD03A0	ORI     $t5, $t5, 0x03A0	#(*CONSTANT) 004D03A0
	WriteOriAddress(ROM, new004D03A0, 0x000C0A80, 0x000C0A84);




	WriteLongToBuffer(ROM, 0x001B5B94, new004D0380);

	//800834D4:	3C0B004D	LUI     $t3, 0x004D	#
	//800834D8:	356B0380	ORI     $t3, $t3, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x0001D4D4, 0x0001D4D8);

	//8011D964:	3C0D004D	LUI     $t5, 0x004D	#
	//8011D968:	35AD0380	ORI     $t5, $t5, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B0C34, 0x0000B0C38);
	
	//8011DAB8:	3C0D004D	LUI     $t5, 0x004D	#
	//8011DABC:	35AD0380	ORI     $t5, $t5, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B0D88, 0x000B0D8C);

	//8011DC0C:	3C0E004D	LUI     $t6, 0x004D	#
	//8011DC18:	35CE0380	ORI     $t6, $t6, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B0EDC, 0x000B0EE8);

	//8011DD80:	3C0F004D	LUI     $t7, 0x004D	#
	//8011DD8C:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B1050, 0x000B105C);

	//8011ED34:	3C0F004D	LUI     $t7, 0x004D	#
	//8011ED38:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B2004, 0x000B2008);

	//8011FB98:	3C19004D	LUI     $t9, 0x004D	#
	//8011FBA0:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B2E68, 0x000B2E70);

	//8011FFF0:	3C19004D	LUI     $t9, 0x004D	#
	//8011FFF8:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B32C0, 0x000B32C8);

	// CRASHES for some reason after lap 1
	//80121FD8:	3C19004D	LUI     $t9, 0x004D	#
	//80121FE4:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	//WriteOriAddress(ROM, new004D0380, 0x000B45D8, 0x000B45E4);

	//801239F0:	3C18004D	LUI     $t8, 0x004D	#
	//801239F4:	37180380	ORI     $t8, $t8, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B6CC0, 0x000B6CC4);

	//80125C0C:	3C0E004D	LUI     $t6, 0x004D	#
	//80125C10:	35CE0380	ORI     $t6, $t6, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B8EDC, 0x000B0EE0);

	//80126308:	3C19004D	LUI     $t9, 0x004D	#
	//8012630C:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B95D8, 0x000B95DC);

	//80126B18:	3C0C004D	LUI     $t4, 0x004D	#
	//80126B1C:	358C0380	ORI     $t4, $t4, 0x0380	#(*CONSTANT) 004D0380

	//80126CDC:	3C19004D	LUI     $t9, 0x004D	#
	//80126CE0:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000B9FAC, 0x000B9FB0);

	//80127818:	3C0E004D	LUI     $t6, 0x004D	#
	//80127820:	35CE0380	ORI     $t6, $t6, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BAAE8, 0x000BAAF0);

	//80127AF0:	3C0E004D	LUI     $t6, 0x004D	#
	//80127AF8:	35CE0380	ORI     $t6, $t6, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BADC0, 0x000BADC8);

	//80127E50:	3C0F004D	LUI     $t7, 0x004D	#
	//80127E54:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BB120, 0x000BB124);

	//8012817C:	3C18004D	LUI     $t8, 0x004D	#
	//80128180:	37180380	ORI     $t8, $t8, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BB44C, 0x000BB450);

	//8012891C:	3C0F004D	LUI     $t7, 0x004D	#
	//80128920:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BBBEC, 0x000BBBF0);

	//80128D60:	3C0F004D	LUI     $t7, 0x004D	#
	//80128D64:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BC030, 0x000BC034);

	//80128ED0:	3C19004D	LUI     $t9, 0x004D	#
	//80128EDC:	37390380	ORI     $t9, $t9, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BC1A0, 0x000BC1AC);

	//8012BB64:	3C0F004D	LUI     $t7, 0x004D	#
	//8012BB68:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000BEE34, 0x000BEE38);

	//8012D790:	3C0B004D	LUI     $t3, 0x004D	#
	//8012D794:	356B0380	ORI     $t3, $t3, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000C0A60, 0x000C0A64);

	//8012E188:	3C0F004D	LUI     $t7, 0x004D	#
	//8012E18C:	35EF0380	ORI     $t7, $t7, 0x0380	#(*CONSTANT) 004D0380
	WriteOriAddress(ROM, new004D0380, 0x000C1458, 0x000C145C);

	// Updates to solo HUD
	//8013f11c Time 00E6 -> 00000226
	WriteLongToBuffer(ROM, 0x000D23EC, 0x00000226);
	//8013f19c TIME word 000000C6 -> 00000208
	WriteLongToBuffer(ROM, 0x000D246C, 0x00000208);
	WriteLongToBuffer(ROM, 0x000D2470, 0x00000026);
	//8013f254 Energy bar 000000DC -> 0000021C
	WriteLongToBuffer(ROM, 0x000D2524, 0x0000021C);
	//8013f2D4 Energy bar contents 000000DE -> 0000021E
	WriteLongToBuffer(ROM, 0x000D25A4, 0x0000021E);
	//8013f354 XCoord of the speedometer 000000E2 -> 222  , Y 000001AC
	WriteLongToBuffer(ROM, 0x000D2624, 0x00000222); WriteLongToBuffer(ROM, 0x000D2628, 0x000001AC);
	//8013f3D4 Number players 0076 -> 00000116
	WriteLongToBuffer(ROM, 0x000D26A4, 0x00000116);
	//8013f454 Lap 1/3 0042
	WriteLongToBuffer(ROM, 0x000D2724, 0x00000042);
	//8013f504 Time +/- 00000078 -> 00000218
	WriteLongToBuffer(ROM, 0x000D27D4, 0x00000218);
	//80140708 Xcoord of track 000000E8 -> 228, Y 00000154
	WriteLongToBuffer(ROM, 0x000D39D8, 0x00000228); WriteLongToBuffer(ROM, 0x000D39DC, 0x00000154);

	// Verification Delta: RAM - 0x8006CD30 = ROM Offset

	// --- 2-PLAYER HUD ---
	// 8013f274 1P Energy Bar E0 -> 00000210
	WriteLongToBuffer(ROM, 0x000D2544, 0x00000210);
	// 8013f27C 2P Energy Bar X: 00000210, Y: 000000F8 (8013f280)
	WriteLongToBuffer(ROM, 0x000D254C, 0x00000210); 
	WriteLongToBuffer(ROM, 0x000D2550, 0x000000F8);

	// 8013f2F4 1P Energy Bar Contents 00000212
	WriteLongToBuffer(ROM, 0x000D25C4, 0x00000212);
	// 8013f2FC 2P Energy Bar Contents X: 00000212, Y: 00000100 (8013f300)
	WriteLongToBuffer(ROM, 0x000D25CC, 0x00000212); 
	WriteLongToBuffer(ROM, 0x000D25D0, 0x00000100);

	// 8013f374 1P Speedometer X: 00000212, Y: 000000D0 (8013f378)
	WriteLongToBuffer(ROM, 0x000D2644, 0x00000212); 
	WriteLongToBuffer(ROM, 0x000D2648, 0x000000D0);
	// 8013f37C 2P Speedometer X: 00000212, Y: 000001B8 (8013f380)
	WriteLongToBuffer(ROM, 0x000D264C, 0x00000212); 
	WriteLongToBuffer(ROM, 0x000D2650, 0x000001B8);

	// 80140728 1P Track X: 00000226, Y: 00000098 (8014072C)
	WriteLongToBuffer(ROM, 0x000D39F8, 0x00000226); 
	WriteLongToBuffer(ROM, 0x000D39FC, 0x00000098);
	// 80140730 2P Track X: 00000226, Y: 00000180 (80140734)
	WriteLongToBuffer(ROM, 0x000D3A00, 0x00000226); 
	WriteLongToBuffer(ROM, 0x000D3A04, 0x00000180);

	// 8013f144 2P Time X: 00000018, Y: 000000FC (8013f148)
	WriteLongToBuffer(ROM, 0x000D2414, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2418, 0x000000FC);

	// 8013f47C 2P Lap X: 00000018, Y: 00000110 (8013f480)
	WriteLongToBuffer(ROM, 0x000D274C, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2750, 0x00000110);

	// 8013f3FC 2P Position X: FFFFFFFC, Y: 00000134 (8013f400)
	WriteLongToBuffer(ROM, 0x000D26CC, 0xFFFFFFFC); 
	WriteLongToBuffer(ROM, 0x000D26D0, 0x00000134);

	// 8013f52C 2P Time +/- X: 00000078, Y: 000000FC (8013f530)
	WriteLongToBuffer(ROM, 0x000D27FC, 0x00000078); 
	WriteLongToBuffer(ROM, 0x000D2800, 0x000000FC);


	// --- 3-PLAYER HUD ---

	// Remove Box, but really more to it, supposed to cover mute city text behind it as black
	// 8012D608 240500A0 240E00E8
	// 8012D61c 24060078 24070131 Box 
	// 8012D608: 240500A0 -> 24050140
	WriteLongToBuffer(ROM, 0x000C08D8, 0x24050140);
	// 8012D60C: 240E00E8 -> 240E01D0
	WriteLongToBuffer(ROM, 0x000C08DC, 0x240E01D0);
	// 8012D61C: 24060078 -> 240600F0
	WriteLongToBuffer(ROM, 0x000C08EC, 0x240600F0);
	// 8012D620: 24070131 -> 24070262
	WriteLongToBuffer(ROM, 0x000C08F0, 0x24070262);

	// 8012D684 Mute City Background color: 3C01436A -> 3C0143EA
	WriteLongToBuffer(ROM, 0x000C0954, 0x3C0143EA);
	// 8012D69C: 24060094 -> 24060128
	WriteLongToBuffer(ROM, 0x000C096C, 0x24060128);
	// 8012D69C: 24060094 -> 24060128
	WriteLongToBuffer(ROM, 0x000C096C, 0x24060128);
	// 8012D72C: 24060092 -> 24060124
	WriteLongToBuffer(ROM, 0x000C09FC, 0x24060124);

	// 8012D714 Mute City: 3C014368 -> 3C0143E8
	WriteLongToBuffer(ROM, 0x000C09E4, 0x3C0143E8);

	// 8013f29C 2P Energy Bar X: 00000060, Y: 000000F4 (8013f2A0)
	WriteLongToBuffer(ROM, 0x000D256C, 0x00000060); 
	WriteLongToBuffer(ROM, 0x000D2570, 0x000000F4);
	// 8013f2A4 3P Energy Bar X: 00000188
	WriteLongToBuffer(ROM, 0x000D2574, 0x00000188);

	// 8013f31C 2P Energy Bar Contents X: 00000062, Y: 000000FA (8013f320)
	WriteLongToBuffer(ROM, 0x000D25EC, 0x00000062); 
	WriteLongToBuffer(ROM, 0x000D25F0, 0x000000FA);
	// 8013f324 3P Energy Bar Contents X: 0000018A
	WriteLongToBuffer(ROM, 0x000D25F4, 0x0000018A);

	// 8013f39C 2P Speedometer X: 00000018, Y: 000000F4 (8013f3A0)
	WriteLongToBuffer(ROM, 0x000D266C, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2670, 0x000000F4);
	// 8013f3A4 3P Speedometer X: 00000140
	WriteLongToBuffer(ROM, 0x000D2674, 0x00000140);

	// 8013f494 1P Lap X: 00000112, Y: 000000C7 (8013f498)
	WriteLongToBuffer(ROM, 0x000D2764, 0x00000112); 
	WriteLongToBuffer(ROM, 0x000D2768, 0x000000C7);
	// 8013f49C 2P Lap X: 00000112, Y: 000001B3 (8013f4A0)
	WriteLongToBuffer(ROM, 0x000D276C, 0x00000112); 
	WriteLongToBuffer(ROM, 0x000D2770, 0x000001A3);
	// 8013f4A4 3P Lap X: 00000250, Y: 000000C7 (8013f4A8)
	WriteLongToBuffer(ROM, 0x000D2774, 0x00000240); 
	WriteLongToBuffer(ROM, 0x000D2778, 0x000000C7);

	// 80140748 1P Track X: 000000F2, Y: 000000B7 (8014074C)
	WriteLongToBuffer(ROM, 0x000D3A18, 0x000000F2); 
	WriteLongToBuffer(ROM, 0x000D3A1C, 0x000000B7);

	// 80140750 2P Track X: 000000F2, Y: 000001A3 (80140754)
	WriteLongToBuffer(ROM, 0x000D3A20, 0x000000F2); 
	WriteLongToBuffer(ROM, 0x000D3A24, 0x000001A3);

	// 80140758 3P Track X: 00000230, Y: 000000B7 (8014075C)
	WriteLongToBuffer(ROM, 0x000D3A28, 0x00000230); 
	WriteLongToBuffer(ROM, 0x000D3A2C, 0x000000B7);

	// 80140760 4P Track X: 00000230, Y: 000001A3 (80140764)
	WriteLongToBuffer(ROM, 0x000D3A30, 0x00000230); 
	WriteLongToBuffer(ROM, 0x000D3A34, 0x000001A3);

	// 8013f414 1P Position X: 00000004, Y: 000000C4 (8013f418)
	WriteLongToBuffer(ROM, 0x000D26E4, 0x00000004); 
	WriteLongToBuffer(ROM, 0x000D26E8, 0x000000C4);
	// 8013f41C 2P Position X: 00000004, Y: 000001B4 (8013f420)
	WriteLongToBuffer(ROM, 0x000D26EC, 0x00000004); 
	WriteLongToBuffer(ROM, 0x000D26F0, 0x000001B4);
	// 8013f424 3P Position X: 0000013A, Y: 000000C4 (8013f428)
	WriteLongToBuffer(ROM, 0x000D26F4, 0x0000013A); 
	WriteLongToBuffer(ROM, 0x000D26F8, 0x000000C4);

	// 8013f16C 2P Time X: 00000018, Y: 000000F4 (8013f170)
	WriteLongToBuffer(ROM, 0x000D243C, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2440, 0x000000F4);
	// 8013f174 3P Time X: 00000140
	WriteLongToBuffer(ROM, 0x000D2444, 0x00000140);

	// 8013f54C 2P Time +/- X: 00000030, Y: 00000150 (8013f550)
	WriteLongToBuffer(ROM, 0x000D281C, 0x00000030); 
	WriteLongToBuffer(ROM, 0x000D2820, 0x00000150);
	// 8013f554 3P Time +/- X: 00000158
	WriteLongToBuffer(ROM, 0x000D2824, 0x00000158);


	// --- 4-PLAYER HUD ---

	// 8013f2BC 2P Energy Bar X: 00000060, Y: 000000F4 (8013f2C0)
	WriteLongToBuffer(ROM, 0x000D258C, 0x00000060); 
	WriteLongToBuffer(ROM, 0x000D2590, 0x000000F4);
	// 8013f2C4 3P Energy Bar X: 00000188
	WriteLongToBuffer(ROM, 0x000D2594, 0x00000188);
	// 8013f2CC 4P Energy Bar X: 00000188, Y: 000000F4 (8013f2D0)
	WriteLongToBuffer(ROM, 0x000D259C, 0x00000188); 
	WriteLongToBuffer(ROM, 0x000D25A0, 0x000000F4);

	// 8013f33C 2P Energy Bar Contents X: 00000062, Y: 000000FA (8013f340)
	WriteLongToBuffer(ROM, 0x000D260C, 0x00000062); 
	WriteLongToBuffer(ROM, 0x000D2610, 0x000000FA);
	// 8013f344 3P Energy Bar Contents X: 0000018A
	WriteLongToBuffer(ROM, 0x000D2614, 0x0000018A);
	// 8013f34C 4P Energy Bar Contents X: 0000018A, Y: 000000FA (8013f350)
	WriteLongToBuffer(ROM, 0x000D261C, 0x0000018A); 
	WriteLongToBuffer(ROM, 0x000D2620, 0x000000FA);

	// 8013f3BC 2P Speedometer X: 00000018, Y: 000000F4 (8013f3C0)
	WriteLongToBuffer(ROM, 0x000D268C, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2690, 0x000000F4);
	// 8013f3C4 3P Speedometer X: 00000140
	WriteLongToBuffer(ROM, 0x000D2694, 0x00000140);
	// 8013f3CC 4P Speedometer X: 00000140, Y: 000000F4 (8013f3D0)
	WriteLongToBuffer(ROM, 0x000D269C, 0x00000140); 
	WriteLongToBuffer(ROM, 0x000D26A0, 0x000000F4);

	// 8013f4B4 1P Lap X: 00000112, Y: 000000C7 (8013f4B8)
	WriteLongToBuffer(ROM, 0x000D2784, 0x00000112); 
	WriteLongToBuffer(ROM, 0x000D2788, 0x000000C7);
	// 8013f4BC 2P Lap X: 00000112, Y: 000001B3 (8013f4C0)
	WriteLongToBuffer(ROM, 0x000D278C, 0x00000112); 
	WriteLongToBuffer(ROM, 0x000D2790, 0x000001A3);
	// 8013f4C4 3P Lap X: 00000250, Y: 000000C7 (8013f4C8)
	WriteLongToBuffer(ROM, 0x000D2794, 0x00000240); 
	WriteLongToBuffer(ROM, 0x000D2798, 0x000000C7);
	// 8013f4CC 4P Lap X: 00000250, Y: 000001B3 (8013f4D0)
	WriteLongToBuffer(ROM, 0x000D279C, 0x00000240); 
	WriteLongToBuffer(ROM, 0x000D27A0, 0x000001A3);

	// 80140768 1P Track X: 000000F2, Y: 000000B7 (8014076C)
	WriteLongToBuffer(ROM, 0x000D3A38, 0x000000F2); 
	WriteLongToBuffer(ROM, 0x000D3A3C, 0x000000B7);

	// 80140770 2P Track X: 000000F2, Y: 000001A3 (80140774)
	WriteLongToBuffer(ROM, 0x000D3A40, 0x000000F2); 
	WriteLongToBuffer(ROM, 0x000D3A44, 0x000001A3);

	// 80140778 3P Track X: 00000230, Y: 000000B7 (8014077C)
	WriteLongToBuffer(ROM, 0x000D3A48, 0x00000230); 
	WriteLongToBuffer(ROM, 0x000D3A4C, 0x000000B7);

	// 80140780 4P Track X: 00000230, Y: 000001A3 (80140784)
	WriteLongToBuffer(ROM, 0x000D3A50, 0x00000230); 
	WriteLongToBuffer(ROM, 0x000D3A54, 0x000001A3);


	// 8013f434 1P Position X: 00000004, Y: 000000C4 (8013f438)
	WriteLongToBuffer(ROM, 0x000D2704, 0x00000004); 
	WriteLongToBuffer(ROM, 0x000D2708, 0x000000C4);
	// 8013f43C 2P Position X: 00000004, Y: 000001B4 (8013f440)
	WriteLongToBuffer(ROM, 0x000D270C, 0x00000004); 
	WriteLongToBuffer(ROM, 0x000D2710, 0x000001B4);
	// 8013f444 3P Position X: 0000013A, Y: 000000C4 (8013f448)
	WriteLongToBuffer(ROM, 0x000D2714, 0x0000013A); 
	WriteLongToBuffer(ROM, 0x000D2718, 0x000000C4);
	// 8013f44C 4P Position X: 0000013A, Y: 000001B4 (8013f450)
	WriteLongToBuffer(ROM, 0x000D271C, 0x0000013A); 
	WriteLongToBuffer(ROM, 0x000D2720, 0x000001B4);

	// 8013f18C 2P Time X: 00000018, Y: 000000F4 (8013f190)
	WriteLongToBuffer(ROM, 0x000D245C, 0x00000018); 
	WriteLongToBuffer(ROM, 0x000D2460, 0x000000F4);
	// 8013f194 3P Time X: 00000140
	WriteLongToBuffer(ROM, 0x000D2464, 0x00000140);

	// 8013f56C 2P Time +/- X: 00000030, Y: 00000150 (8013f570)
	WriteLongToBuffer(ROM, 0x000D283C, 0x00000030); 
	WriteLongToBuffer(ROM, 0x000D2840, 0x00000150);
	// 8013f574 3P Time +/- X: 00000158
	WriteLongToBuffer(ROM, 0x000D2844, 0x00000158);
	// 8013f57C 4P Time +/- X: 00000158, Y: 00000150 (8013f580)
	WriteLongToBuffer(ROM, 0x000D284C, 0x00000158); 
	WriteLongToBuffer(ROM, 0x000D2850, 0x00000150);

	FILE* outFile = fopen("tempgh9.bin", "wb");
	fwrite(&ROM[0x16C8A0], 1, 0xE940, outFile);
	fflush(outFile);
	fclose(outFile);

	char tempFolder[8000];
	::GetCurrentDirectory(8000, tempFolder);

	CString mainFolder;
	mainFolder.Format("%s", tempFolder);

	CString tempStr = ("mio0.exe -d tempgh9.bin TEMPGH9.BIZ");
	hiddenExec(_T(tempStr.GetBuffer()), (mainFolder));

	unsigned long decompressedSize16C8A0 = CharArrayToLong(&ROM[0x16C8A0 + 4]);
	unsigned char* temp16C8A0Buffer = new unsigned char[decompressedSize16C8A0];
	inFile = fopen("TEMPGH9.BIZ", "rb");
	fread(temp16C8A0Buffer, 1, decompressedSize16C8A0, inFile);
	fclose(inFile);

	WriteShortToBuffer(temp16C8A0Buffer, 0x000146A8, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146AA, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146B0, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146B2, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146B8, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146BA, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146C0, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146C2, newHeight*2/* + 0x10*/); // to fit compressed
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146C8, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146CA, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146D0, newWidth*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146D2, newHeight*4 - 0x10);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146D8, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146DA, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146E0, newWidth + 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146E2, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146E8, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146EA, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146F0, (newWidth * 3) - 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146F2, newHeight*2);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146F8, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x000146FA, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014700, newWidth + 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014702, newHeight + 0x20);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014708, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001470A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014710, (newWidth * 3) - 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014712, newHeight + 0x20);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014718, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001471A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014720, (newWidth) + 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014722, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014728, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001472A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014730, (newWidth * 3) - 0x18);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014732, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014738, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001473A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014740, (newWidth * 2));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014742, ((newHeight) + 0x20));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014748, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001474A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014750, (newWidth * 2));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014752, ((newHeight * 3) - 0x10));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014758, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001475A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014760, (newWidth + 0x18));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014762, (newHeight * 2));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014768, newWidth);
	WriteShortToBuffer(temp16C8A0Buffer, 0x0001476A, newHeight);
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014770, ((newWidth * 3) - 0x18));
	WriteShortToBuffer(temp16C8A0Buffer, 0x00014772, (newHeight * 2));

	outFile = fopen("tempgh92.bin", "wb");
	fwrite(temp16C8A0Buffer, 1, decompressedSize16C8A0, outFile);
	fflush(outFile);
	fclose(outFile);

	tempStr = ("mio0.exe -c tempgh92.bin TEMPGH92.BIZ");
	hiddenExec(_T(tempStr.GetBuffer()), (mainFolder));

	int compressedSize = GetSizeFile("TEMPGH92.BIZ");
	if (compressedSize > 0xE940)
	{
		delete [] ROM;
		MessageBox("Too big compressed");
		return;
	}
	inFile = fopen("TEMPGH92.BIZ", "rb");
	fread(&ROM[0x16C8A0], 1, compressedSize, inFile);
	fclose(inFile);

	delete [] temp16C8A0Buffer;

	::DeleteFile("tempgh9.bin");
	::DeleteFile("tempgh92.bin");
	::DeleteFile("TEMPGH9.BIZ");
	::DeleteFile("TEMPGH92.BIZ");


	FILE* outFileA;
	if (rawData == rawDataHAN1NoAA)
	{
		outFileA = fopen("C:\\temp\\fzerohiresnoaa.rom", "wb");
		tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\fzerohiresnoaa.rom");
	}
	else
	{
		outFileA = fopen("C:\\temp\\fzerohires.rom", "wb");
		tempStr.Format("\"C:\\GoldeneyeStuff\\GE Editor Source\\rn64crc.exe\" -u \"%s\"", "C:\\temp\\fzerohires.rom");
	}
	fwrite(ROM, 1, romSize, outFileA);
	fclose(outFileA);
	
	hiddenExec(_T(tempStr.GetBuffer()), "C:\\GoldeneyeStuff\\GE Editor Source\\");

	delete [] ROM;	
}