//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MakeGameHiRes.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAKEGAMEHIRES_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BUTTONBK11                  1000
#define IDC_BUTTONBK12                  1001
#define IDC_BUTTONBK13                  1002
#define IDC_BUTTONBK14                  1003
#define IDC_BUTTONBK15                  1004
#define IDC_BUTTONBK16                  1005
#define IDC_BUTTONBK17                  1006
#define IDC_BUTTONBK18                  1007
#define IDC_BUTTONBK19                  1008
#define IDC_BUTTONBK20                  1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
