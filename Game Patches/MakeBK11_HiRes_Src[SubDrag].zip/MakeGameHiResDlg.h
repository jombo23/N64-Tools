
// MakeGameHiResDlg.h : header file
//

#pragma once


// CMakeGameHiResDlg dialog
class CMakeGameHiResDlg : public CDialog
{
// Construction
public:
	CMakeGameHiResDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MAKEGAMEHIRES_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonbk11();
	afx_msg void OnBnClickedButtonbk12();
	afx_msg void OnBnClickedButtonbk13();
	afx_msg void OnBnClickedButtonbk14();
	afx_msg void OnBnClickedButtonbk15();
	afx_msg void OnBnClickedButtonbk16();
	afx_msg void OnBnClickedButtonbk17();
};
