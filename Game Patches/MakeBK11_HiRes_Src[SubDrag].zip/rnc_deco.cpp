#include "stdafx.h"
/* ScummVM - Graphic Adventure Engine
 *
 * ScummVM is the legal property of its developers, whose names
 * are too numerous to list here. Please refer to the COPYRIGHT
 * file distributed with this source distribution.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */


#include "rnc_deco.h"
#include <vector>

//return codes
#define NOT_PACKED	0
#define PACKED_CRC	0
#define UNPACKED_CRC	0

//other defines
#define TABLE_SIZE	(16 * 8)
#define MIN_LENGTH	2
#define HEADER_LEN	18

RncDecoder::RncDecoder() {
	initCrc();
}

RncDecoder::~RncDecoder() { }

void RncDecoder::initCrc() {
	crc_table[0x0] = 0x0000;
crc_table[0x1] = 0xC0C1;
crc_table[0x2] = 0xC181;
crc_table[0x3] = 0x0140;
crc_table[0x4] = 0xC301;
crc_table[0x5] = 0x03C0;
crc_table[0x6] = 0x0280;
crc_table[0x7] = 0xC241,
crc_table[0x8] = 0xC601;
crc_table[0x9] = 0x06C0;
crc_table[0xA] = 0x0780;
crc_table[0xB] = 0xC741;
crc_table[0xC] = 0x0500;
crc_table[0xD] = 0xC5C1;
crc_table[0xE] = 0xC481;
crc_table[0xF] = 0x0440,
crc_table[0x10] = 0xCC01;
crc_table[0x11] = 0x0CC0;
crc_table[0x12] = 0x0D80;
crc_table[0x13] = 0xCD41;
crc_table[0x14] = 0x0F00;
crc_table[0x15] = 0xCFC1;
crc_table[0x16] = 0xCE81;
crc_table[0x17] = 0x0E40,
crc_table[0x18] = 0x0A00;
crc_table[0x19] = 0xCAC1;
crc_table[0x1A] = 0xCB81;
crc_table[0x1B] = 0x0B40;
crc_table[0x1C] = 0xC901;
crc_table[0x1D] = 0x09C0;
crc_table[0x1E] = 0x0880;
crc_table[0x1F] = 0xC841,
crc_table[0x20] = 0xD801;
crc_table[0x21] = 0x18C0;
crc_table[0x22] = 0x1980;
crc_table[0x23] = 0xD941;
crc_table[0x24] = 0x1B00;
crc_table[0x25] = 0xDBC1;
crc_table[0x26] = 0xDA81;
crc_table[0x27] = 0x1A40,
crc_table[0x28] = 0x1E00;
crc_table[0x29] = 0xDEC1;
crc_table[0x2A] = 0xDF81;
crc_table[0x2B] = 0x1F40;
crc_table[0x2C] = 0xDD01;
crc_table[0x2D] = 0x1DC0;
crc_table[0x2E] = 0x1C80;
crc_table[0x2F] = 0xDC41,
crc_table[0x30] = 0x1400;
crc_table[0x31] = 0xD4C1;
crc_table[0x32] = 0xD581;
crc_table[0x33] = 0x1540;
crc_table[0x34] = 0xD701;
crc_table[0x35] = 0x17C0;
crc_table[0x36] = 0x1680;
crc_table[0x37] = 0xD641,
crc_table[0x38] = 0xD201;
crc_table[0x39] = 0x12C0;
crc_table[0x3A] = 0x1380;
crc_table[0x3B] = 0xD341;
crc_table[0x3C] = 0x1100;
crc_table[0x3D] = 0xD1C1;
crc_table[0x3E] = 0xD081;
crc_table[0x3F] = 0x1040,
crc_table[0x40] = 0xF001;
crc_table[0x41] = 0x30C0;
crc_table[0x42] = 0x3180;
crc_table[0x43] = 0xF141;
crc_table[0x44] = 0x3300;
crc_table[0x45] = 0xF3C1;
crc_table[0x46] = 0xF281;
crc_table[0x47] = 0x3240,
crc_table[0x48] = 0x3600;
crc_table[0x49] = 0xF6C1;
crc_table[0x4A] = 0xF781;
crc_table[0x4B] = 0x3740;
crc_table[0x4C] = 0xF501;
crc_table[0x4D] = 0x35C0;
crc_table[0x4E] = 0x3480;
crc_table[0x4F] = 0xF441,
crc_table[0x50] = 0x3C00;
crc_table[0x51] = 0xFCC1;
crc_table[0x52] = 0xFD81;
crc_table[0x53] = 0x3D40;
crc_table[0x54] = 0xFF01;
crc_table[0x55] = 0x3FC0;
crc_table[0x56] = 0x3E80;
crc_table[0x57] = 0xFE41,
crc_table[0x58] = 0xFA01;
crc_table[0x59] = 0x3AC0;
crc_table[0x5A] = 0x3B80;
crc_table[0x5B] = 0xFB41;
crc_table[0x5C] = 0x3900;
crc_table[0x5D] = 0xF9C1;
crc_table[0x5E] = 0xF881;
crc_table[0x5F] = 0x3840,
crc_table[0x60] = 0x2800;
crc_table[0x61] = 0xE8C1;
crc_table[0x62] = 0xE981;
crc_table[0x63] = 0x2940;
crc_table[0x64] = 0xEB01;
crc_table[0x65] = 0x2BC0;
crc_table[0x66] = 0x2A80;
crc_table[0x67] = 0xEA41,
crc_table[0x68] = 0xEE01;
crc_table[0x69] = 0x2EC0;
crc_table[0x6A] = 0x2F80;
crc_table[0x6B] = 0xEF41;
crc_table[0x6C] = 0x2D00;
crc_table[0x6D] = 0xEDC1;
crc_table[0x6E] = 0xEC81;
crc_table[0x6F] = 0x2C40,
crc_table[0x70] = 0xE401;
crc_table[0x71] = 0x24C0;
crc_table[0x72] = 0x2580;
crc_table[0x73] = 0xE541;
crc_table[0x74] = 0x2700;
crc_table[0x75] = 0xE7C1;
crc_table[0x76] = 0xE681;
crc_table[0x77] = 0x2640,
crc_table[0x78] = 0x2200;
crc_table[0x79] = 0xE2C1;
crc_table[0x7A] = 0xE381;
crc_table[0x7B] = 0x2340;
crc_table[0x7C] = 0xE101;
crc_table[0x7D] = 0x21C0;
crc_table[0x7E] = 0x2080;
crc_table[0x7F] = 0xE041,
crc_table[0x80] = 0xA001;
crc_table[0x81] = 0x60C0;
crc_table[0x82] = 0x6180;
crc_table[0x83] = 0xA141;
crc_table[0x84] = 0x6300;
crc_table[0x85] = 0xA3C1;
crc_table[0x86] = 0xA281;
crc_table[0x87] = 0x6240,
crc_table[0x88] = 0x6600;
crc_table[0x89] = 0xA6C1;
crc_table[0x8A] = 0xA781;
crc_table[0x8B] = 0x6740;
crc_table[0x8C] = 0xA501;
crc_table[0x8D] = 0x65C0;
crc_table[0x8E] = 0x6480;
crc_table[0x8F] = 0xA441,
crc_table[0x90] = 0x6C00;
crc_table[0x91] = 0xACC1;
crc_table[0x92] = 0xAD81;
crc_table[0x93] = 0x6D40;
crc_table[0x94] = 0xAF01;
crc_table[0x95] = 0x6FC0;
crc_table[0x96] = 0x6E80;
crc_table[0x97] = 0xAE41,
crc_table[0x98] = 0xAA01;
crc_table[0x99] = 0x6AC0;
crc_table[0x9A] = 0x6B80;
crc_table[0x9B] = 0xAB41;
crc_table[0x9C] = 0x6900;
crc_table[0x9D] = 0xA9C1;
crc_table[0x9E] = 0xA881;
crc_table[0x9F] = 0x6840,
crc_table[0xA0] = 0x7800;
crc_table[0xA1] = 0xB8C1;
crc_table[0xA2] = 0xB981;
crc_table[0xA3] = 0x7940;
crc_table[0xA4] = 0xBB01;
crc_table[0xA5] = 0x7BC0;
crc_table[0xA6] = 0x7A80;
crc_table[0xA7] = 0xBA41,
crc_table[0xA8] = 0xBE01;
crc_table[0xA9] = 0x7EC0;
crc_table[0xAA] = 0x7F80;
crc_table[0xAB] = 0xBF41;
crc_table[0xAC] = 0x7D00;
crc_table[0xAD] = 0xBDC1;
crc_table[0xAE] = 0xBC81;
crc_table[0xAF] = 0x7C40,
crc_table[0xB0] = 0xB401;
crc_table[0xB1] = 0x74C0;
crc_table[0xB2] = 0x7580;
crc_table[0xB3] = 0xB541;
crc_table[0xB4] = 0x7700;
crc_table[0xB5] = 0xB7C1;
crc_table[0xB6] = 0xB681;
crc_table[0xB7] = 0x7640,
crc_table[0xB8] = 0x7200;
crc_table[0xB9] = 0xB2C1;
crc_table[0xBA] = 0xB381;
crc_table[0xBB] = 0x7340;
crc_table[0xBC] = 0xB101;
crc_table[0xBD] = 0x71C0;
crc_table[0xBE] = 0x7080;
crc_table[0xBF] = 0xB041,
crc_table[0xC0] = 0x5000;
crc_table[0xC1] = 0x90C1;
crc_table[0xC2] = 0x9181;
crc_table[0xC3] = 0x5140;
crc_table[0xC4] = 0x9301;
crc_table[0xC5] = 0x53C0;
crc_table[0xC6] = 0x5280;
crc_table[0xC7] = 0x9241,
crc_table[0xC8] = 0x9601;
crc_table[0xC9] = 0x56C0;
crc_table[0xCA] = 0x5780;
crc_table[0xCB] = 0x9741;
crc_table[0xCC] = 0x5500;
crc_table[0xCD] = 0x95C1;
crc_table[0xCE] = 0x9481;
crc_table[0xCF] = 0x5440,
crc_table[0xD0] = 0x9C01;
crc_table[0xD1] = 0x5CC0;
crc_table[0xD2] = 0x5D80;
crc_table[0xD3] = 0x9D41;
crc_table[0xD4] = 0x5F00;
crc_table[0xD5] = 0x9FC1;
crc_table[0xD6] = 0x9E81;
crc_table[0xD7] = 0x5E40,
crc_table[0xD8] = 0x5A00;
crc_table[0xD9] = 0x9AC1;
crc_table[0xDA] = 0x9B81;
crc_table[0xDB] = 0x5B40;
crc_table[0xDC] = 0x9901;
crc_table[0xDD] = 0x59C0;
crc_table[0xDE] = 0x5880;
crc_table[0xDF] = 0x9841,
crc_table[0xE0] = 0x8801;
crc_table[0xE1] = 0x48C0;
crc_table[0xE2] = 0x4980;
crc_table[0xE3] = 0x8941;
crc_table[0xE4] = 0x4B00;
crc_table[0xE5] = 0x8BC1;
crc_table[0xE6] = 0x8A81;
crc_table[0xE7] = 0x4A40,
crc_table[0xE8] = 0x4E00;
crc_table[0xE9] = 0x8EC1;
crc_table[0xEA] = 0x8F81;
crc_table[0xEB] = 0x4F40;
crc_table[0xEC] = 0x8D01;
crc_table[0xED] = 0x4DC0;
crc_table[0xEE] = 0x4C80;
crc_table[0xEF] = 0x8C41,
crc_table[0xF0] = 0x4400;
crc_table[0xF1] = 0x84C1;
crc_table[0xF2] = 0x8581;
crc_table[0xF3] = 0x4540;
crc_table[0xF4] = 0x8701;
crc_table[0xF5] = 0x47C0;
crc_table[0xF6] = 0x4680;
crc_table[0xF7] = 0x8641,
crc_table[0xF8] = 0x8201;
crc_table[0xF9] = 0x42C0;
crc_table[0xFA] = 0x4380;
crc_table[0xFB] = 0x8341;
crc_table[0xFC] = 0x4100;
crc_table[0xFD] = 0x81C1;
crc_table[0xFE] = 0x8081;
crc_table[0xFF] = 0x4040;
}

//calculate 16 bit crc of a block of memory
unsigned short RncDecoder::crcBlock(const unsigned char *block, unsigned long size) {
	unsigned short crc = 0;
	unsigned char tmp;
	unsigned long i;

	int offset = 0;
    while (size--)
    {
        crc ^= block[offset++];
        crc = (crc >> 8) ^ crc_table[crc & 0xFF];
    }

    return crc;
}

unsigned short RncDecoder::inputBits(unsigned char amount) {
	unsigned short newBitBuffh = _bitBuffh;
	unsigned short newBitBuffl = _bitBuffl;
	signed short newBitCount = _bitCount;
	unsigned short remBits, returnVal;

	returnVal = ((1 << amount) - 1) & newBitBuffl;
	newBitCount -= amount;

	if (newBitCount < 0) {
		newBitCount += amount;
		remBits = (newBitBuffh << (16 - newBitCount));
		newBitBuffh >>= newBitCount;
		newBitBuffl >>= newBitCount;
		newBitBuffl |= remBits;
		_srcPtr += 2;
		newBitBuffh = READ_LE_UINT16(_srcPtr);
		amount -= newBitCount;
		newBitCount = 16 - amount;
	}
	remBits = (newBitBuffh << (16 - amount));
	_bitBuffh = newBitBuffh >> amount;
	_bitBuffl = (newBitBuffl >> amount) | remBits;
	_bitCount = (unsigned char)newBitCount;

	return returnVal;
}

void RncDecoder::makeHufftable(unsigned short *table) {
	unsigned short bitLength, i, j;
	unsigned short numCodes = inputBits(5);

	if (!numCodes)
		return;

	unsigned char huffLength[16];
	for (i = 0; i < numCodes; i++)
		huffLength[i] = (unsigned char)(inputBits(4) & 0x00FF);

	unsigned short huffCode = 0;

	for (bitLength = 1; bitLength < 17; bitLength++) {
		for (i = 0; i < numCodes; i++) {
			if (huffLength[i] == bitLength) {
				*table++ = (1 << bitLength) - 1;

				unsigned short b = huffCode >> (16 - bitLength);
				unsigned short a = 0;

				for (j = 0; j < bitLength; j++)
					a |= ((b >> j) & 1) << (bitLength - j - 1);
				*table++ = a;

				*(table + 0x1e) = (huffLength[i] << 8) | (i & 0x00FF);
				huffCode += 1 << (16 - bitLength);
			}
		}
	}
}

unsigned short RncDecoder::inputValue(unsigned short *table) {
	unsigned short valOne, valTwo, value = _bitBuffl;

	do {
		valTwo = (*table++) & value;
		valOne = *table++;

	} while (valOne != valTwo);

	value = *(table + 0x1e);
	inputBits((unsigned char)((value>>8) & 0x00FF));
	value &= 0x00FF;

	if (value >= 2) {
		value--;
		valOne = inputBits((unsigned char)value & 0x00FF);
		valOne |= (1 << value);
		value = valOne;
	}

	return value;
}

unsigned short RncDecoder::READ_BE_UINT16(const unsigned char* buffer)
{
	unsigned short tempValue = (((buffer[0] << 8) | buffer[1]));
	return tempValue;
}

unsigned short RncDecoder::READ_LE_UINT16(const unsigned char* buffer)
{
	unsigned short tempValue = (((buffer[1] << 8) | buffer[0]));
	return tempValue;
}

unsigned long RncDecoder::READ_BE_UINT32(const unsigned char* buffer)
{
	unsigned long tempValue = ((((((buffer[0] << 8) | buffer[1]) << 8) | buffer[2]) << 8) | buffer[3]);
	return tempValue;
}

int RncDecoder::getLengths(const void *input, int& unpackLen, int& packLen)
{
	const unsigned char* inputptr = (const unsigned char *)input;
	unpackLen = 0;
	packLen = 0;

	if ((READ_BE_UINT32(inputptr) != RNC_SIGNATURE) && (READ_BE_UINT32(inputptr) != RNC_SIGNATUREV2) && 
		(READ_BE_UINT32(inputptr) != RNX_SIGNATURE) && (READ_BE_UINT32(inputptr) != RNX_SIGNATUREV2)
		 && (READ_BE_UINT32(inputptr) != RNC_SIGNATURE81))
		return NOT_PACKED;

	int version = inputptr[3];

	inputptr += 4;

	// read unpacked/packed file length
	unpackLen = READ_BE_UINT32(inputptr); inputptr += 4;
	packLen = READ_BE_UINT32(inputptr); inputptr += 4;

	return 0;
}

int RncDecoder::unpackM1(const void *input, void *output, unsigned short key, int& packLen) 
{
	void* inputStart = (void*)input;

	void* outputStart = output;
	unsigned char *outputLow, *outputHigh;
	const unsigned char *inputHigh, *inputptr = (const unsigned char *)input;

	unsigned long unpackLen = 0;
	packLen = 0;
	unsigned short counts = 0;
	unsigned short crcUnpacked = 0;
	unsigned short crcPacked = 0;


	_bitBuffl = 0;
	_bitBuffh = 0;
	_bitCount = 0;

	//Check for "RNC "
	if ((READ_BE_UINT32(inputptr) != RNC_SIGNATURE) && (READ_BE_UINT32(inputptr) != RNC_SIGNATUREV2) && 
		(READ_BE_UINT32(inputptr) != RNX_SIGNATURE) && (READ_BE_UINT32(inputptr) != RNX_SIGNATUREV2)
		 && (READ_BE_UINT32(inputptr) != RNC_SIGNATURE81))
		return NOT_PACKED;

	int version = inputptr[3];

	inputptr += 4;

	// read unpacked/packed file length
	unpackLen = READ_BE_UINT32(inputptr); inputptr += 4;
	packLen = READ_BE_UINT32(inputptr); inputptr += 4;

	unsigned char blocks = *(inputptr + 5);

	int indexedBlockCount = 1;
	int indexedBlockSize = 0;
	std::vector<int> compressedSizes;

	int totalUnpackLen = unpackLen;

	if (version != 0x81)
	{
		//read CRC's
		crcUnpacked = READ_BE_UINT16(inputptr); inputptr += 2;
		crcPacked = READ_BE_UINT16(inputptr); inputptr += 2;
		inputptr = (inputptr + HEADER_LEN - 16);

		inputptr = (((const unsigned char *)input) + HEADER_LEN);
	}
	else
	{
		indexedBlockCount = READ_BE_UINT16(inputptr);
		inputptr += 2;

		indexedBlockSize = inputptr[0] * 0x1000;
		inputptr++;

		// reserved
		inputptr +=3;

		for (int x = 0; x < indexedBlockCount; x++)
		{
			compressedSizes.push_back(READ_BE_UINT16(inputptr));
			inputptr += 2;
		}
	}

	//if (crcBlock((unsigned char*) inputStart + HEADER_LEN, (packLen)) != crcPacked)
		//return PACKED_CRC;

	for (int x = 0; x < indexedBlockCount; x++)
	{
		if (version == 0x81)
		{
			unpackLen = indexedBlockSize;
			packLen = compressedSizes[x];
			blocks = 1;
		}

		if ((version == 0x01) || (version == 0x81))
		{
			_srcPtr = inputptr;

			inputHigh = ((const unsigned char *)input) + packLen + HEADER_LEN;
			outputLow = (unsigned char *)output;
			outputHigh = *(((const unsigned char *)input) + 16) + unpackLen + outputLow;

			if (! ((inputHigh <= outputLow) || (outputHigh <= inputHigh)) ) {
				_srcPtr = inputHigh;
				_dstPtr = outputHigh;
				memcpy((_dstPtr-packLen), (_srcPtr-packLen), packLen);
				_srcPtr = (_dstPtr-packLen);
			}

			_dstPtr = (unsigned char *)output;
			_bitCount = 0;

			_bitBuffl = READ_LE_UINT16(_srcPtr);
			inputBits(2);

			do {
				makeHufftable(_rawTable);
				makeHufftable(_posTable);
				makeHufftable(_lenTable);

				counts = inputBits(16);

				do {
					unsigned long inputLength = inputValue(_rawTable);
					unsigned long inputOffset;

					if (inputLength) {
						memcpy(_dstPtr, _srcPtr, inputLength); //memcpy is allowed here
						_dstPtr += inputLength;
						_srcPtr += inputLength;
						unsigned short a = READ_LE_UINT16(_srcPtr);
						unsigned short b = READ_LE_UINT16(_srcPtr + 2);

						_bitBuffl &= ((1 << _bitCount) - 1);
						_bitBuffl |= (a << _bitCount);
						_bitBuffh = (a >> (16 - _bitCount)) | (b << _bitCount);
					}

					if (counts > 1) {
						inputOffset = inputValue(_posTable) + 1;
						inputLength = inputValue(_lenTable) + MIN_LENGTH;

						// Don't use memcpy here! because input and output overlap.
						unsigned char *tmpPtr = (_dstPtr-inputOffset);
						while (inputLength--)
							*_dstPtr++ = *tmpPtr++;
					}
				} while (--counts);
			} while (--blocks);

			output = _dstPtr;
		}
		else
		{
			int fileSizeUncompressed = 0;
			unsigned long bitBuffer = 0;
			int bitBufferCount = 0;
			unsigned char* dst = (unsigned char*)output;
			int dstOffset = 0;
			int inpOffset = 0;
			 get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
			 get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset); // unused 2 bits

			 while ((fileSizeUncompressed < unpackLen) && (inpOffset < packLen))
			 {
			   if (!get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
			   {
				   unsigned char byte = get_byte(inputptr, inpOffset);
				 *dst++ = byte;
				 
				 dstOffset++;
				 fileSizeUncompressed ++;
			   }
			   else 
			   {
				   // ?
				 int length = 2;
				 int offset = 0;
				 if (!get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
				 {
				   length = 4 + get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
				   if (get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
				   {
					 length = (length - 1) * 2 + get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
					 if (length == 9) 
					 {
					   int valueToAdd = ((((((get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset) << 1) | get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) << 1) | get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) << 1) | get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset));
					   length = (valueToAdd + 3) * 4;
					   for (int i = 0; i < length; i++)
					   {
						   unsigned char byte = get_byte(inputptr, inpOffset);
						   *dst++ = byte;
						   dstOffset++;
					   }
					   fileSizeUncompressed += length;
					   continue;
					 }
				   }
				   offset = get_offset(inputptr, bitBuffer, bitBufferCount, inpOffset);
				 } 
				 else 
				 {
					if (get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
					{
						if (get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
						{
							length = get_byte(inputptr, inpOffset) + 8;
							if (length == 8) 
							{
								get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
								continue; //dunno why
							}
						} 
						else 
						{
							length = 3;
						}
						offset = get_offset(inputptr, bitBuffer, bitBufferCount, inpOffset);
					} 
					else 
					{
						offset = get_byte(inputptr, inpOffset) + 1;
					}
				 }
				 unsigned char *tmpPtr = (dst-offset);
				 int tmpPtrSpot = dstOffset - offset;
				 if (tmpPtrSpot < 0)
					 return 0;

				 int iterLength = length;
				 while (iterLength--)
				 {
					 unsigned char byte = *tmpPtr++;
					 *dst++ = byte;
					 dstOffset++;
				 }
				 fileSizeUncompressed = (fileSizeUncompressed + length);
			   }
			 }

			 output = dst;
		}
	}

	if (version != 0x81)
	{
		//if (crcBlock((unsigned char*)outputStart, unpackLen) != crcUnpacked)
			//return UNPACKED_CRC;
	}

	// all is done..return the amount of unpacked bytes
	return totalUnpackLen;
}

bool RncDecoder::get_bit(const unsigned char*& inputptr, unsigned long& bitBuffer, int& bitBufferCount, int& inpOffset)
{
	if (bitBufferCount == 0)
	{
		bitBuffer = *inputptr++;
		inpOffset++;
		bitBufferCount = 8;
	}
	bool returnBool = ((bitBuffer >> (bitBufferCount-1)) & 0x1);
	bitBufferCount--;
	return returnBool;
}

int RncDecoder::get_offset(const unsigned char*& inputptr, unsigned long& bitBuffer, int& bitBufferCount, int& inpOffset)
{
	int value = 0;
	int offset = 0;
	if (get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
	{
		value = get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
		if (get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset)) 
		{
			value = value * 2 + 4 + get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
			if (!get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset))
			{
				value = value * 2 + get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset);
			}
		} 
		else if (value == 0)
		{
			value = get_bit(inputptr, bitBuffer, bitBufferCount, inpOffset) + 2;
		}
	}
	offset = (value << 8) + get_byte(inputptr, inpOffset) + 1;
	return offset;

}
unsigned char RncDecoder::get_byte(const unsigned char*& inputptr, int& inpOffset)
{
	unsigned char returnChar = *inputptr;
	inputptr++;
	inpOffset++;
	return returnChar;
}

BOOL RncDecoder::hiddenExec (PTSTR pCmdLine, CString currentDirectory)
{
   STARTUPINFO si;
   PROCESS_INFORMATION processInfo;
   ZeroMemory(&si, sizeof(si));
   si.cb           = sizeof(si);
   si.dwFlags      = STARTF_USESHOWWINDOW;
   si.wShowWindow  = SW_HIDE;
   ZeroMemory(&processInfo, sizeof(processInfo));
   /*return */CreateProcess(0, pCmdLine, 0, 0, FALSE, 0, 0, currentDirectory, &si, &processInfo);
   WaitForSingleObject(processInfo.hProcess, 20000);
   DWORD exitCode;
   if (GetExitCodeProcess(processInfo.hProcess, &exitCode))
   {
        if (exitCode == STILL_ACTIVE)
		{
			MessageBox(NULL, "For some reason GZip Failed", "Error", NULL);
			TerminateProcess(processInfo.hProcess, exitCode);
			return false;
		}
   }   
   return true;
};

BOOL RncDecoder::IsFileExist(LPSTR lpszFilename)
{
	DWORD dwAttr = GetFileAttributes(lpszFilename);
	if (dwAttr == 0xffffffff)
		return FALSE;
	else 
		return TRUE;
}

bool RncDecoder::CompressRNCFile(CString mainFolder, CString inputFile, CString outputFile, bool useRNX, int level)
{
	CString gzipFileName = (mainFolder + "rnc_propack_x64.exe");
	char tempFileExistName[1000];
	strcpy(tempFileExistName, (mainFolder + "rnc_propack_x64.exe"));
	if (IsFileExist(tempFileExistName) == false)
	{
		MessageBox(NULL, "rncencode.exe not found!", "Error", NULL);
		return false;
	}

	strcpy(tempFileExistName, inputFile);
	if (IsFileExist(tempFileExistName))
	{
		FILE* tempInputFile = fopen(inputFile, "rb");
		fseek(tempInputFile, 0, SEEK_END);
		unsigned long size = ftell(tempInputFile);

		unsigned char* tempBuffer;
		tempBuffer = new unsigned char[size];
		
		fseek(tempInputFile, 0, SEEK_SET);
		fread(tempBuffer, 1, size, tempInputFile);

		FILE* tempOutputFile = fopen((mainFolder+"tempgh9.bin"), "wb");
		if (tempOutputFile == 0)
		{
			fclose(tempInputFile);
			delete [] tempBuffer;
			MessageBox(NULL, "Cannot Write Temporary File", "Error", NULL);
			return false;
		}

		fwrite(tempBuffer, 1, size, tempOutputFile);	

		fclose(tempInputFile);
		fclose(tempOutputFile);

		delete [] tempBuffer;

		::SetCurrentDirectory(mainFolder);
		CString params;
		params.Format("-m=%d", level);
		CString tempStr = ("rnc_propack_x64.exe p tempgh9.bin TEMPGH9.BIZ " + params);
		hiddenExec(_T(tempStr.GetBuffer()), (mainFolder));
		CString outputGZippedName = (mainFolder+"TEMPGH9.BIZ");

		DeleteFile((mainFolder+"tempgh9.bin"));

		strcpy(tempFileExistName, outputGZippedName);
		if (IsFileExist(tempFileExistName))
		{
			FILE* inputFileName = fopen(outputGZippedName, "rb");
			int sizeNew = 0;
			fseek(inputFileName, 0, SEEK_END);
			sizeNew = ftell(inputFileName);
			fseek(inputFileName, 0, SEEK_SET);

			unsigned char* tempBufferNew;
			tempBufferNew = new unsigned char[sizeNew];
			fread(tempBufferNew, 1, sizeNew, inputFileName);

			fclose(inputFileName);
			DeleteFile((mainFolder+"TEMPGH9.BIZ"));
			FILE* outputFileName = fopen(outputFile, "wb");
			if (outputFileName == NULL)
			{
				delete [] tempBufferNew;
				MessageBox(NULL, "Error opening temp output file", "Error", NULL);
				return false;
			}

			if (useRNX)
				tempBufferNew[2] = 0x58;

			fwrite(&tempBufferNew[0], 1, (sizeNew), outputFileName);	

			delete [] tempBufferNew;
			fflush(outputFileName);
			fclose(outputFileName);
			return true;
		}
		else
		{
			MessageBox(NULL, "Error Compressing - rncencode didn't spit out a file", "Error", NULL);
			return false;
		}
	}
}

/*
void header(data)
{
    //"""Returns dictionary:
	//indexed     True if an indexed file
	//archive     True if an archive
	//unsupported True if some other flag raised
	//h_sz        size of header/start of data
	//cmp_type:   compression type, or -1 if invalid (not RNC)
	//cmp_sz:     compressed file size
	//dec_sz:     decompressed file size
	//Indexed types:
		//blk_n:      number of blocks
		//blk_s:      byte size of blocks
	//Normal types:
		//crc_in:     CRC for input
		//crc_out:    CRC for output
		//chk_d:      cmp. chunk overlap over dec. chunks
		//chk_n:      number of chunks to overlap

//Original Format:
	//0x0     3   signature, usually b'RNC'
	//0x3     1   mode
		//80    indexed mode
		//40    archive mode
		//03    compression types 0:'store', 1:'huff', or 2:'lz'
	//File types:
		//0x4     4   decompressed size
		//Compressed types:
			//0x8     4   compressed size
			//Normal mode:
				//0xC     2   CRC for compressed data
				//0xE     2   CRC for decompressed data
				//0x10    1   difference in cmp and dec sizes in largest chunk
				//0x11    1   overlap size for in-place decompression
			//Indexed mode:
				//0xC     2   block count
				//0xE     1   block size (in kb)
				//0xF     3   RESERVED
				//0x12    2ea compressed filesizes for each block
	//Archives:
		//0x4     2   size of header
		//0x6     2   CRC for filetable
		//0x8     var filetable
		//var     var files
		//files end with NULL ID+type (NULL word)
		//Filetable header:
			//0x0 2   offset to next directory or start of files
			//0x2 var directory name; root is NULL
			//var var file entries
		//Filetable entries:
			//0x0 var NULL-terminated filename string
			//var 4   offset to data
			//entries end with first NULL string (1 NULL byte)
	name = data[0:3].decode(errors='replace')
	t = True if data[3] & 0x80 else False
	a = True if data[3] & 0x40 else False
	u = True if data[3] & 0x3C else False
	mode = data[3] & 3
	if name not in RNC.IDs:
		mode = -1
	if mode == 3:
		mode = -1
	h = dict({'indexed':t, 'archive':a, 'unsupported':u, 'cmp_type':mode})
	//# Three things are lethal: bad mode, unsupported features, and archive+indexed mode.
	if (mode < 0) or u or (t&a):
		return h

	if a:
		h.update(RNC.arcs(data))
	elif t:
		h.update(RNC.indexed(data))
	else:
		h.update(RNC.files(data))
	return h
}

void files(data)
{
    z = 8
    dec_s= int.from_bytes(data[ 4: 8], byteorder='big')
    //# Test if mode 0 file.
    mode = data[3]&3
    if mode==0:
        return {'h_sz':z, 'cmp_sz':dec_s, 'dec_sz':dec_s}
    z+=10
    cmp_s= int.from_bytes(data[ 8:12], byteorder='big')
    crc_o= int.from_bytes(data[12:14], byteorder='big')
    crc_i= int.from_bytes(data[14:16], byteorder='big')
    //# Get encoded/locked flags
    if mode==2:
        lock = True if data[z]&0x80 else False
        enc  = True if data[z]&0x40 else False
    else:
        lock = True if data[z]&1 else False
        enc  = True if data[z]&2 else False
    return {'cmp_sz':cmp_s, 'dec_sz':dec_s, 'crc_in':crc_i, 'crc_out':crc_o, 'chk_d':data[16], 'chk_n':data[17], 'h_sz':z, 'encoded':enc, 'locked':lock}
}

void indexed(data)
{
    dec_s= int.from_bytes(data[ 4: 8], byteorder='big')
    cmp_s= int.from_bytes(data[ 8:12], byteorder='big')
    bn   = int.from_bytes(data[12:14], byteorder='big')
    bs   = data[14] << 10   # num kb * 0x400
    z    = (bn<<1) + 18

    //# Copy out the filesize table.
    t = []
    c = dec_s
    s = bs
    for i in range(18, z, 2):
        //# Actual offsets are short-aligned.
        p = int.from_bytes(data[i:i+2], byteorder='big') + 1
        p&= (~1)
        s = c if c<bs else bs
        c-=bs
        t.append({'cmp_sz':p, 'dec_sz':s})

    //# Get encoded/locked flags
    lock = True if data[z]&1 else False
    enc  = True if data[z]&2 else False
    return {'cmp_sz':cmp_s, 'dec_sz':dec_s, 'blk_n':bn, 'blk_s':bs, 'h_sz':z, 'table':t, 'encoded':enc, 'locked':lock}
}
void arcs(data)
{
    z   = int.from_bytes(data[ 4: 6], byteorder='big')
    crc = int.from_bytes(data[ 6: 8], byteorder='big')
    //# Calculate the filetable's checksum.
    calc= RNC.crc(data[8:z])
    //# Strip out the filetable.
    t = []
    p = 8
    while p < z:
        //# Get the directory name.
        d = int.from_bytes(data[p:p+2], byteorder='big', signed=False)
        p+=2
        l=0
        while data[p+l]:
            l+=1
        pre = data[p:p+l].decode(encoding='ascii', errors='strict')
        p+= l+1
        //# Fetch filenames, offsets for each of that directory's files.
        while p<d:
            l=0
            while data[p+l]:
                l+=1
            n = data[p:p+l].decode(encoding='ascii', errors='replace')
            p+= l+1
            //# Run until either a NULL filename or end of directory.
            if not n:
                break
            l = int.from_bytes(data[p:p+4], byteorder='big')
            t.append({'name':pre+n, 'pos':l})
            p+=4
    return {'h_sz':z, 'crc_ft':crc, 'crc_calc':calc, 'filetable':t}
}

def dec0(data, size=None, key=None)
{
    """Uncompressed data within wrapper."""
    if not out:
        out = bytearray()
    if not size:
        size = len(data)
    out.extend(data[0:size])
    return out
}

void _grab(itr, bits=0, mode='read')
{
	//"""Returns a value equal to the next num bits in data stream,
	//accounting for the fool-stupid way they pull values from a bitstream.
	//
	//Iterates stream data using either 'big' or 'little' endian order.
	//Two possible mode:
		//'read', which returns a value and advances bitstream
		//'peek' which just masks against current value
	
	i, c, b = 0, 0, 0
	while True:
		v = next(itr,0)
		v|= next(itr,0)<<8
		v<<=c
		b|=v     # bitfield | new bits<<count
		c+=16    # bitcount+=16
		i+=2
		while c>=bits:
			m = (1<<bits)-1 # mask
			v = b&m         # value = bitfield & mask
			if mode!='peek':
				c-= bits        # count-= #bits
				b>>=bits        # bitfield without said bits
			bits, mode = yield v  # yield the value, retrieving next #bits
}

void dec1(data, size, key=0, index=None)
{
	//"""Huffman + LZ77 scheme
	//Accepts an iterable for the bitstream,
		//a dictionary for the header,
		//and output to this point if applicable."""

	

	//# Initialize the stream and throw away the first two bits.
	d = RNC._stream(data)
	k = RNC._updatekey(key)
	itr = _grab(d, bits=2)
	next(itr)
	out = bytearray()
	if index != None:
		idx_n = 0

	while size:
		b = RNC.huf_in(itr, 5, 4)
		if b:   raws = b
		b = RNC.huf_in(itr, 5, 4)
		if b:   dist = b
		b = RNC.huf_in(itr, 5, 4)
		if b:   lens = b
		cnt = itr.send((16,'read'))

		while True:
			l = RNC.huf_rd(raws, itr)
			if l<0:
				break
			if l:
				size -= l
				key = next(k)
				if index!= None:
					index.extend([idx_n for i in range(l)])
					idx_n +=1
					idx_n%= 16
				while l:
					l-=1
					# should really just be a byte out; presumes magically no masking required
					out.append(next(d)^key)
			cnt-=1
			if not cnt:
				break
			p = RNC.huf_rd(dist, itr) + 1
			l = RNC.huf_rd(lens, itr) + 2
			for i in range(l):
				v = out[len(out)-p]
				out.append(v)
			# If keeping a copy index, do the same here.
			if index!= None:
				for i in range(l):
					v = index[len(index)-p]
					index.append(v)
			size-=l
	return out
}

void dec2(data, size, key=0, index=None)
{
    //"""LZ77 scheme alone.
    //Accepts an iterable for the bitstream,
        //and output to this point if applicable."""
    def _fetch(itr, bits=0, mode='read'):
        c, b = 0, 0
        while True:
            m = (1<<c)-1
            b&=m
            b<<=8
            b|= next(itr)
            c+=8
            while c>=bits:
                #m = 1<<(bits-1)
                v = b>>(c-bits)
                #v&=m
                v = RNC._mirror(v,bits)
                if mode!='peek':
                    c-= bits        # count-= #bits
                bits, mode = yield v

    //# initialize the stream; first two bits are discarded
    d = RNC._stream(data)
    b = _fetch(d, 2)
    k = RNC._updatekey(key)
    next(b)
    out = bytearray()
    if index != None:
        idx_n = 0

    while size:
        if b.send((1, 'read')):
            back, num = 0, 0
            if b.send((1, 'read')):
                if b.send((1, 'read')):
                    if b.send((1, 'read')):
                        //# 1.111.*L.-B-.*D   if L: copy L+8 bytes from D+1 in bank B
                        num = next(d) + 8
                        if num==8:
                            if b.send((1, 'read')): continue
                            else:                   break
                    else:
                        //# 1.110.-B-.*D  copy 3 bytes from D+1 in bank B
                        num = 3
                else:
                    //# 1.10.*D   copy 2 bytes from D+1
                    back, num = 1, 2
            else:
                //# fetch length value
                num = b.send((2, 'read'))
                if num==2:
                    num+=b.send((1, 'read'))
                elif num==3:
                    if b.send((1, 'read')):
                        //# 1.0.111.nnnn  write next (n+3) words
                        num+= RNC._mirror(b.send((4, 'read')),4)
                        num<<=2
                        key = next(k)
                        if index!= None:
                            index.extend([idx_n for i in range(num)])
                            idx_n +=1
                            idx_n%= 16
                        for i in range(num):
                            out.append(next(d)^key)
                        size-=num
                        continue
                    //# 1.0.110   length of 8
                    num+=1
                //# 1.0.-L-.-B-.*D    copy length L from D+1 in bank B
                num+=4
            //# fetch bank
            if not back:
                if b.send((1, 'read')):
                    back = b.send((2, 'read'))
                    if back==0:
                        back = 2 + b.send((1, 'read'))
                    elif back>1:
                        if b.send((2, 'peek')) & 2:
                            back<<=1
                            back|= (b.send((2, 'read')) & 1)
                        else:
                            back<<=2
                            b.send((3, 'peek'))
                            v=b.send((1, 'read'))<<1
                            b.send((1, 'read'))
                            v|=b.send((1, 'read'))
                            back+=v
                    back<<=8
                back+=1
            //# Copy num bytes from byte+offset
            back+= next(d)
            for i in range(num):
                v = out[len(out)-back]
                out.append(v)
                size-=1
            //# If keeping an index, update it as well.
            if index!= None:
                for i in range(num):
                    v = index[len(index)-back]
                    index.append(v)
        else:
            //# push single byte
            if index!= None:
                index.append(idx_n)
                idx_n +=1
                idx_n%= 16
            out.append(next(d) ^ next(k))
            size-=1
    return out
}

void dec_file(void *input, void *output, unsigned short key=0, int num=1)
{
    //"""Convenience, reading a header and calling the decompressor
    //until the entire RNC thread is exhausted.
	//
    //First two bits of compressed files indicate special features:
    //    bit 1: Locked (can't decompress with official tools)
    //    bit 2: Encoded
    //"""

	int inputPosition = 0;
	int outputPosition = 0;

    cmd = [RNC.dec0, RNC.dec1, RNC.dec2]

    h = RNC.header(data)
    if h['unsupported'] or h['cmp_type']<0:
        //# Add an error message
        app.writeToLog("\tError: {:02X} is an unrecognized format.\n".format(data[3]),('warning'))
        return None
    elif h.get('archive'):
        //# Should run as an archive to pull properly.
        RNCA.dec_all(data, None, h)
        return None

    //# Indexed types use a filesize table.
    if h.get('indexed'):
        t = h['table']
    else:
        //# Nonindexed use only one file.
        t = [{'cmp_sz':h['cmp_sz'], 'dec_sz':h['dec_sz']}]

    //# Spit out a crc check for the heck of it when able.
    if h.get('crc_in'):
        c = RNC.crc(data[h['h_sz']:h['h_sz'] + h['cmp_sz']])
        //# Temporary!
        //app.writeToLog("Compressed CRC: {:04X} vs. {:04X} (calulated)\n".format(h['crc_in'], c),('highlight') if h['crc_in']==c else ('warning'))

    //# Start from after the header and work onward through list.
    p = h['h_sz']
    e = h['h_sz'] + h['cmp_sz']
    c = h['cmp_type']
    //# Ignore the lock on the file.
    if h.get('locked'):
        app.writeToLog("\tIgnoring lock on file ;*)\n")

    //# This works because type 0 can't be encoded and archives are handled seperately.
    if h.get('encoded'):
        if key:
            output = cmd[c](data[p:p+t[0]['cmp_sz']], t[0]['dec_sz'], key)
            if t[0]['crc_out'] != RNC.crc(output):
                app.writeToLog("\tProvided key {:04X} did not work.\n".format(key))
                key = 0
        if not key:
            app.writeToLog("\tCracking key for encoded file.\n")
            idx = []
            output = cmd[c](data[p:p+t[0]['cmp_sz']], t[0]['dec_sz'], 0, idx)
            k = RNC.keyfinder(h['crc_out'], output, idx, num=num)
            //# If not found returns None.
            if not k:
                app.writeToLog("\tSome error occured in testing.\n",('warning'))
                return
            //# In the event multiples are found, select one.
            if len(k)>1:
                k = ListBoxChoice(app, "Possible Key Values", "Select one key value", k).returnValue()
                if not k:
                    return
            key = k[0]
            app.writeToLog("\tThe key for this file is {:d} (0x{:04X}).\n".format(key, key))
            output = RNC.applykey(output, idx, key)
    //# Extract and append all segments of the file.
    else:
        for i in t:
            output.extend(cmd[c](data[p:p+i['cmp_sz']], i['dec_sz'], key))
            p+=i['cmp_sz']
            if (p>=e) or (len(output)>=h['dec_sz']):
                break

        if h.get('crc_out'):
            c = RNC.crc(output)
            //# Temporary!
            //app.writeToLog("Decompressed CRC: {:04X} vs. {:04X} (calulated)\n".format(h['crc_out'], c),('highlight') if h['crc_out']==c else ('warning'))

    return output
}*/