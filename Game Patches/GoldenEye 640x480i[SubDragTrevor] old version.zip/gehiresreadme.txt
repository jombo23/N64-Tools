Ever dreamed of seeing a Hi Res mode on GoldenEye, similar to Hi Res in PD?  Your dream is finally a reality.  

Only possible thanks to Zoinkity's brilliant 7 meg RAM extension, this patch allows for quadruple the size framebuffers, to accomodate the two 640 x 480 frame buffers (double buffered).   The frame buffers were moved to upper RAM to accomodate the size, and all of the related assembly code in GoldenEye and VI settings has been adjusted accordingly.  At the expense of some lag, you do get a much sharper image. 

There are two patches:
640 x 240p (Menus normal)
640 x 480i (Menus 640 x 480i)

Apply xDelta to GoldenEye US ROM.

Credits:
Hi Res Mode - SubDrag
640 x 480i Help - Trevor
7 Meg Patch - Zoinkity
Testing - Trevor